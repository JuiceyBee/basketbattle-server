// screens/ShopScreen.js
import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView, FlatList,
  StyleSheet, ActivityIndicator, Image, Alert, Keyboard, Modal,
  KeyboardAvoidingView, Platform, Dimensions,
} from 'react-native';
const { searchColes, searchWoolworths, fetchColesSpecials, fetchWoolworthsSpecials } = require('../services/storeService');
const { getBattles, saveBattles } = require('../services/api');
const { addItemsToCart } = require('./CartScreen');

const C = {
  red: '#d32f2f', green: '#2e7d32', gold: '#f59e0b',
  bg: '#0f1117', card: '#1a1d27', card2: '#20232f',
  border: '#2a2d3a', text: '#f0f0f0', muted: '#6b7280', sub: '#a0a8b8',
};

// ── Product card ─────────────────────────────────────────────────────────────
function ProductCard({ item, store, isStaged, onToggleStage, onAddToCart }) {
  const storeColor = store === 'coles' ? C.red : C.green;
  const isUnavail = item.unavailable || !item.price || item.price <= 0;

  return (
    <TouchableOpacity
      style={[styles.card, isStaged && styles.cardStaged, isUnavail && styles.cardUnavail]}
      onPress={() => !isUnavail && onToggleStage(item, store)}
      activeOpacity={0.75}
      disabled={isUnavail}
    >
      {/* Top row: image + info */}
      <View style={styles.cardTop}>
        {item.imgUrl
          ? <Image source={{ uri: item.imgUrl }} style={styles.pimg} resizeMode="contain" />
          : <View style={styles.pph}><Text style={{ fontSize: 22 }}>🛒</Text></View>
        }
        <View style={styles.pinfo}>
          <Text style={styles.pn} numberOfLines={4}>
            {item.name}
            {isUnavail ? <Text style={styles.unavailTag}> UNAVAIL</Text> : null}
          </Text>
          {!!item.brand && <Text style={styles.pbr} numberOfLines={1}>{item.brand}</Text>}
          {!!item.unit && <Text style={styles.punit}>{item.unit}</Text>}
          <View style={styles.ppl}>
            <Text style={[styles.price, { color: storeColor }]}>
              {isUnavail ? 'N/A' : '$' + (item.price || 0).toFixed(2)}
            </Text>
            {!!item.multiBuy
              ? <View style={styles.multiTag}><Text style={styles.multiTagText}>{item.multiBuy.qty} for ${item.multiBuy.price.toFixed(2)}</Text></View>
              : !!item.wasPrice ? <Text style={styles.was}>${item.wasPrice.toFixed(2)}</Text> : null
            }
            {!!item.isOnSpecial && !item.multiBuy && <View style={styles.stag}><Text style={styles.stagText}>SALE</Text></View>}
          </View>
          {!!item.unitPrice && <Text style={styles.cup}>{item.unitPrice}</Text>}
          {!!item.multiBuy && <Text style={styles.multiSub}>${item.multiBuy.priceEa.toFixed(2)} ea · single ${item.price.toFixed(2)}</Text>}
        </View>
      </View>
      {/* Single action — add to cart */}
      <TouchableOpacity
        style={[styles.cartBtn, isUnavail && { opacity: 0.35 }]}
        onPress={(e) => { e.stopPropagation?.(); !isUnavail && onAddToCart(item, store); }}
        disabled={isUnavail}
      >
        <Text style={styles.cartBtnText}>🛒 Add to Cart</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

// ── Store column — independent scroll with auto-load-more ────────────────────
function StoreColumn({ store, items, loading, done, staged, onToggleStage, onLoadMore, onAddToCart }) {
  const color = store === 'coles' ? C.red : C.green;
  const label = store === 'coles' ? '🔴 Coles' : '🟢 Woolworths';
  const loadingRef = useRef(loading);
  const doneRef = useRef(done);
  loadingRef.current = loading;
  doneRef.current = done;

  // Trigger load more when scrolled within 600px of the bottom
  function handleScroll(e) {
    if (loadingRef.current || doneRef.current) return;
    const { layoutMeasurement, contentOffset, contentSize } = e.nativeEvent;
    const distanceFromBottom = contentSize.height - layoutMeasurement.height - contentOffset.y;
    if (distanceFromBottom < 600) {
      onLoadMore();
    }
  }

  const header = (
    <Text style={[styles.colHead, { color }]}>{label}</Text>
  );

  const footer = (
    <View style={{ alignItems: 'center', padding: 12, minHeight: 44 }}>
      {loading
        ? <ActivityIndicator size="small" color={C.gold} />
        : done && items.length > 0
          ? <Text style={styles.endText}>— end —</Text>
          : null
      }
    </View>
  );

  const empty = !loading && items.length === 0
    ? <Text style={styles.noResults}>No results</Text>
    : null;

  const skeletons = loading && items.length === 0
    ? [0, 1, 2].map(i => <View key={i} style={styles.skeleton} />)
    : null;

  return (
    <ScrollView
      style={styles.col}
      contentContainerStyle={{ padding: 4 }}
      showsVerticalScrollIndicator={false}
      onScroll={handleScroll}
      scrollEventThrottle={200}
    >
      {header}
      {skeletons}
      {empty}
      {items.map((item, i) => (
        <ProductCard
          key={item.id + '-' + i}
          item={item}
          store={store}
          isStaged={staged.some(s => s.item.id === item.id && s.store === store)}
          onToggleStage={onToggleStage}
          onAddToCart={onAddToCart}
        />
      ))}
      {footer}
    </ScrollView>
  );
}

// ── Staging bar ──────────────────────────────────────────────────────────────
function StagingBar({ staged, onRemove, onClear, onCommit, name, onNameChange }) {
  if (!staged.length) return null;
  return (
    <View style={styles.stage}>
      <View style={styles.stageHeader}>
        <Text style={styles.stageTitle}>⚔️ Battle Staging</Text>
        <Text style={styles.stageCount}>{staged.length} item{staged.length !== 1 ? 's' : ''} selected</Text>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 8 }}>
        {staged.map((s, i) => (
          <View key={i} style={styles.chip}>
            <View style={[styles.chipDot, { backgroundColor: s.store === 'coles' ? C.red : C.green }]} />
            <Text style={styles.chipName} numberOfLines={1}>
              {s.item.name.length > 18 ? s.item.name.slice(0, 16) + '…' : s.item.name}
            </Text>
            <TouchableOpacity onPress={() => onRemove(i)}>
              <Text style={styles.chipX}>✕</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
      <View style={styles.stageFooter}>
        <TextInput
          style={styles.nameInput}
          placeholder="Battle name…"
          placeholderTextColor={C.muted}
          value={name}
          onChangeText={onNameChange}
        />
        <TouchableOpacity style={styles.clearBtn} onPress={onClear}>
          <Text style={styles.clearBtnText}>✕</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.goBtn, staged.length < 2 && styles.goBtnDisabled]}
          onPress={onCommit}
          disabled={staged.length < 2}
        >
          <Text style={styles.goBtnText}>⚔️ Battle</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ── Main screen ──────────────────────────────────────────────────────────────
export default function ShopScreen() {
  const [query, setQuery]           = useState('');
  const [mode, setMode]             = useState('specials');
  const [colesItems, setColesItems] = useState([]);
  const [wowItems, setWowItems]     = useState([]);
  const [colesLoading, setColesLoading] = useState(true);
  const [wowLoading, setWowLoading]     = useState(true);
  const [colesDone, setColesDone]   = useState(false);
  const [wowDone, setWowDone]       = useState(false);
  const colesPageRef = useRef(2);
  const wowPageRef   = useRef(2);
  const colesLoadingRef = useRef(true);
  const wowLoadingRef   = useRef(true);
  const colesDoneRef    = useRef(false);
  const wowDoneRef      = useRef(false);
  const modeRef         = useRef('specials');
  const queryRef        = useRef('');
  const [staged, setStaged]         = useState([]);
  const [battleName, setBattleName] = useState('');
  const [battles, setBattles]       = useState([]);
  const [battleModal, setBattleModal] = useState(null); // { item, store } | null
  const [inNewBattle, setInNewBattle] = useState(false); // once "New Battle" picked, skip modal
  const [toast, setToast]           = useState(''); // fleeting message
  const [debugLog, setDebugLog]       = useState([]);
  const [showDebug, setShowDebug]     = useState(false);
  const toastTimerRef               = useRef(null);

  // Keep refs in sync
  colesLoadingRef.current = colesLoading;
  wowLoadingRef.current   = wowLoading;
  colesDoneRef.current    = colesDone;
  wowDoneRef.current      = wowDone;
  modeRef.current         = mode;
  queryRef.current        = query;

  useEffect(() => { startSpecials(); }, []);

  // Load existing battles so user can add to them
  useEffect(() => {
    getBattles().then(b => setBattles(Array.isArray(b) ? b : [])).catch(() => {});
  }, []);


  function startSpecials() {
    setMode('specials');
    modeRef.current = 'specials';
    setColesItems([]); setWowItems([]);
    setColesLoading(true); setWowLoading(true);
    setColesDone(false); setWowDone(false);
    colesPageRef.current = 2; wowPageRef.current = 2;

    fetchColesSpecials(1)
      .then(items => { dbg('Coles specials OK: ' + items.length + ' items'); setColesItems(items); if (!items.length) setColesDone(true); })
      .catch(e => { dbg('Coles specials ERR: ' + e.message); setColesDone(true); })
      .finally(() => setColesLoading(false));

    fetchWoolworthsSpecials(1)
      .then(items => { setWowItems(items); if (!items.length) setWowDone(true); })
      .catch(() => setWowDone(true))
      .finally(() => setWowLoading(false));
  }

  async function doSearch() {
    const q = query.trim();
    if (!q) { startSpecials(); return; }
    Keyboard.dismiss();
    setMode('search');
    modeRef.current = 'search';
    queryRef.current = q;
    setColesItems([]); setWowItems([]);
    setColesLoading(true); setWowLoading(true);
    setColesDone(false); setWowDone(false);
    colesPageRef.current = 2; wowPageRef.current = 2;

    searchColes(q, 1)
      .then(items => { setColesItems(items); if (!items.length) setColesDone(true); })
      .catch(() => setColesDone(true))
      .finally(() => setColesLoading(false));

    searchWoolworths(q, 1)
      .then(items => { setWowItems(items); if (!items.length) setWowDone(true); })
      .catch(() => setWowDone(true))
      .finally(() => setWowLoading(false));
  }

  // loadMore functions use refs so scroll handler doesn't capture stale state
  const loadMoreColes = useCallback(async () => {
    if (colesLoadingRef.current || colesDoneRef.current) return;
    setColesLoading(true);
    const page = colesPageRef.current;
    try {
      const items = modeRef.current === 'specials'
        ? await fetchColesSpecials(page)
        : await searchColes(queryRef.current, page);
      if (!items.length) { setColesDone(true); }
      else { setColesItems(prev => [...prev, ...items]); colesPageRef.current = page + 1; }
    } catch {}
    setColesLoading(false);
  }, []);

  const loadMoreWow = useCallback(async () => {
    if (wowLoadingRef.current || wowDoneRef.current) return;
    setWowLoading(true);
    const page = wowPageRef.current;
    try {
      const items = modeRef.current === 'specials'
        ? await fetchWoolworthsSpecials(page)
        : await searchWoolworths(queryRef.current, page);
      if (!items.length) { setWowDone(true); }
      else { setWowItems(prev => [...prev, ...items]); wowPageRef.current = page + 1; }
    } catch {}
    setWowLoading(false);
  }, []);

  function toggleStage(item, store) {
    const alreadyStaged = staged.some(s => s.item.id === item.id && s.store === store);
    if (alreadyStaged) {
      setStaged(prev => prev.filter(s => !(s.item.id === item.id && s.store === store)));
      return;
    }
    // If already building a new battle, add directly — no modal
    if (inNewBattle) {
      addToStaging(item, store);
      return;
    }
    // Otherwise show modal
    setBattleModal({ item, store });
  }

  function addToStaging(item, store) {
    setInNewBattle(true);
    setStaged(prev => {
      const next = [...prev, { item, store }];
      if (!battleName && next.length === 1) {
        setBattleName(item.name.split(' ').slice(0, 3).join(' '));
      }
      return next;
    });
    setBattleModal(null);
  }

  async function addToExistingBattle(battle, item, store) {
    setBattleModal(null);
    try {
      const fresh = await getBattles();
      const all = Array.isArray(fresh) ? fresh : [];
      let alreadyExists = false;
      const updated = all.map(b => {
        if (b.name !== battle.name) return b;
        const exists = (b.items || []).some(i => i.id === item.id && i.store === store);
        if (exists) { alreadyExists = true; return b; }
        return { ...b, items: [...(b.items || []), { ...item, store }] };
      });
      if (alreadyExists) {
        showToast('Already in "' + battle.name + '"');
        return;
      }
      await saveBattles(updated);
      setBattles(updated);
      showToast('⚔️ Added to "' + battle.name + '"');
    } catch (e) {
      Alert.alert('Error', e.message);
    }
  }

  function removeStaged(idx) { setStaged(prev => prev.filter((_, i) => i !== idx)); }
  function clearStaging() { setStaged([]); setBattleName(''); setInNewBattle(false); }

  function showToast(msg) {
    setToast(msg);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setToast(''), 2200);
  }

  function dbg(msg) {
    const line = new Date().toLocaleTimeString('en-AU') + '  ' + msg;
    console.log('[DBG]', msg);
    setDebugLog(prev => [line, ...prev].slice(0, 30));
  }

  // Intercept console.log so storeService [Coles] logs show in overlay too
  React.useEffect(() => {
    const orig = console.log;
    console.log = (...args) => {
      orig(...args);
      const msg = args.join(' ');
      if (msg.includes('[Coles]') || msg.includes('[DBG]') || msg.includes('[WOW]')) {
        const line = new Date().toLocaleTimeString('en-AU') + '  ' + msg;
        setDebugLog(prev => [line, ...prev].slice(0, 30));
      }
    };
    return () => { console.log = orig; };
  }, []);

  async function handleAddToCart(item, store) {
    dbg('handleAddToCart: ' + item.name.slice(0,20) + ' / ' + store);
    try {
      const { addItemsToCart: addFn } = require('./CartScreen');
      const result = await addFn([{ ...item, store, qty: 1 }]);
      if (result && result.appOk) {
        showToast('🛒 Added: ' + item.name.split(' ').slice(0, 4).join(' '));
      } else {
        showToast('Failed to add to cart');
      }
    } catch (e) {
      showToast('Error: ' + e.message);
    }
  }

  async function commitBattle() {
    if (staged.length < 2) return;
    const name = battleName.trim() || ('Battle ' + Date.now());
    try {
      const rawBattles = await getBattles();
      const existing = Array.isArray(rawBattles) ? rawBattles : [];
      // Block duplicate names
      if (existing.some(b => b.name.toLowerCase() === name.toLowerCase())) {
        Alert.alert('Name already used', 'A battle called "' + name + '" already exists. Please choose a different name.');
        return;
      }
      const newGroup = { name, groupTag: '', items: staged.map(s => ({ ...s.item, store: s.store })), lastRefreshed: Date.now() };
      const updated = [newGroup].concat(existing);
      await saveBattles(updated);
      setBattles(updated);  // keep local state in sync so new battle appears in modal immediately
      clearStaging();
      showToast('⚔️ Battle created: "' + name + '"');
    } catch (e) {
      Alert.alert('Error saving battle', e.message);
    }
  }

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>

      {/* Battle picker modal */}
      <Modal
        visible={!!battleModal}
        transparent
        animationType="slide"
        onRequestClose={() => setBattleModal(null)}
      >
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setBattleModal(null)}>
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>⚔️ Add to Battle</Text>
            <Text style={styles.modalSub} numberOfLines={2}>
              {battleModal ? battleModal.item.name : ''}
            </Text>

            {/* New battle option */}
            <TouchableOpacity
              style={styles.modalOpt}
              onPress={() => battleModal && addToStaging(battleModal.item, battleModal.store)}
            >
              <Text style={styles.modalOptIcon}>✨</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.modalOptTitle}>New Battle</Text>
                <Text style={styles.modalOptSub}>Stage this item and create a new battle</Text>
              </View>
            </TouchableOpacity>

            {/* Existing battles */}
            {battles.length > 0 && (
              <>
                <Text style={styles.modalSectionLabel}>Add to existing battle</Text>
                {battles.map(battle => (
                  <TouchableOpacity
                    key={battle.name}
                    style={styles.modalOpt}
                    onPress={() => battleModal && addToExistingBattle(battle, battleModal.item, battleModal.store)}
                  >
                    <Text style={styles.modalOptIcon}>⚔️</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.modalOptTitle}>{battle.name}</Text>
                      <Text style={styles.modalOptSub}>{(battle.items || []).length} items</Text>
                    </View>
                  </TouchableOpacity>
                ))}
              </>
            )}

            <TouchableOpacity style={styles.modalCancel} onPress={() => setBattleModal(null)}>
              <Text style={styles.modalCancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      {/* Search bar */}
      <View style={styles.sbar}>
        <TouchableOpacity
          onPress={() => setShowDebug(v => !v)}
          style={{ paddingHorizontal: 8, justifyContent: 'center' }}
        >
          <Text style={{ color: debugLog.length > 0 && debugLog[0].includes('ERR') ? '#f87171' : C.muted, fontSize: 11, fontWeight: '700' }}>
            {showDebug ? '✕ DBG' : '⚙ DBG'}
          </Text>
        </TouchableOpacity>
        <TextInput
          style={styles.sinput}
          placeholder="Search products…"
          placeholderTextColor={C.muted}
          value={query}
          onChangeText={setQuery}
          onSubmitEditing={doSearch}
          returnKeyType="search"
          autoCorrect={false}
          autoCapitalize="none"
        />
        <TouchableOpacity style={styles.sbtn} onPress={doSearch}>
          <Text style={styles.sbtnText}>{query.trim() ? 'Go' : '🏷️'}</Text>
        </TouchableOpacity>
      </View>

      {/* Staging bar */}
      <StagingBar
        staged={staged}
        onRemove={removeStaged}
        onClear={clearStaging}
        onCommit={commitBattle}
        name={battleName}
        onNameChange={setBattleName}

      />

      {/* Mode label */}
      <View style={styles.modeRow}>
        {mode === 'specials'
          ? <Text style={styles.modeLabel}>🏷️ This week's specials</Text>
          : <TouchableOpacity onPress={() => { setQuery(''); startSpecials(); }}>
              <Text style={styles.backLink}>← Back to specials</Text>
            </TouchableOpacity>
        }
      </View>

      {/* Two columns — each with independent scroll */}
      <View style={styles.cols}>
        <StoreColumn
          store="coles"
          items={colesItems}
          loading={colesLoading}
          done={colesDone}
          staged={staged}
          onToggleStage={toggleStage}
          onLoadMore={loadMoreColes}
          onAddToCart={handleAddToCart}
        />
        <View style={styles.colDivider} />
        <StoreColumn
          store="woolworths"
          items={wowItems}
          loading={wowLoading}
          done={wowDone}
          staged={staged}
          onToggleStage={toggleStage}
          onLoadMore={loadMoreWow}
          onAddToCart={handleAddToCart}
        />
      </View>
      {/* Debug overlay */}
      {showDebug && (
        <View style={{ position: 'absolute', bottom: 60, left: 8, right: 8, backgroundColor: '#0a0a0f', borderWidth: 1, borderColor: C.border, borderRadius: 10, padding: 10, maxHeight: 280, zIndex: 999 }}>
          <Text style={{ color: C.gold, fontWeight: '700', fontSize: 12, marginBottom: 6 }}>🐛 Debug Log</Text>
          <ScrollView style={{ maxHeight: 230 }}>
            {debugLog.length === 0
              ? <Text style={{ color: C.muted, fontSize: 11 }}>No logs yet</Text>
              : debugLog.map((line, i) => (
                  <Text key={i} style={{ color: line.includes('ERR') ? '#f87171' : '#86efac', fontSize: 10, fontFamily: 'monospace', marginBottom: 2 }}>{line}</Text>
                ))
            }
          </ScrollView>
          <TouchableOpacity onPress={() => setDebugLog([])} style={{ marginTop: 6 }}>
            <Text style={{ color: C.muted, fontSize: 11 }}>Clear</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Toast notification */}
      {!!toast && (
        <View style={styles.toast} pointerEvents="none">
          <Text style={styles.toastText}>{toast}</Text>
        </View>
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  sbar:      { flexDirection: 'row', padding: 12, paddingTop: 56, paddingBottom: 8, gap: 8 },
  sinput:    { flex: 1, backgroundColor: C.card, borderWidth: 1.5, borderColor: C.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 11, color: C.text, fontSize: 15 },
  sbtn:      { backgroundColor: C.gold, borderRadius: 12, paddingHorizontal: 18, justifyContent: 'center' },
  sbtnText:  { color: '#1a1100', fontWeight: '700', fontSize: 14 },

  stage:        { backgroundColor: '#181710', borderWidth: 1.5, borderColor: C.gold, borderRadius: 12, margin: 10, marginTop: 0, padding: 10 },
  stageHeader:  { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  stageTitle:   { color: C.gold, fontWeight: '700', fontSize: 13 },
  stageCount:   { color: C.muted, fontSize: 12 },
  chip:         { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: C.card2, borderWidth: 1, borderColor: C.border, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4, marginRight: 6 },
  chipDot:      { width: 6, height: 6, borderRadius: 3 },
  chipName:     { color: C.text, fontSize: 12, maxWidth: 110 },
  chipX:        { color: C.muted, fontSize: 14, paddingLeft: 2 },
  stageFooter:  { flexDirection: 'row', gap: 6, alignItems: 'center' },
  nameInput:    { flex: 1, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6, color: C.text, fontSize: 13 },
  clearBtn:     { paddingHorizontal: 10, paddingVertical: 7, borderWidth: 1, borderColor: C.border, borderRadius: 8 },
  clearBtnText: { color: C.muted, fontSize: 13 },
  goBtn:        { backgroundColor: C.gold, borderRadius: 8, paddingHorizontal: 14, paddingVertical: 7 },
  goBtnDisabled:{ opacity: 0.4 },
  goBtnText:    { color: '#1a1100', fontWeight: '700', fontSize: 13 },

  modeRow:   { paddingHorizontal: 12, paddingBottom: 4 },
  modeLabel: { color: C.gold, fontWeight: '700', fontSize: 12 },
  backLink:  { color: C.gold, fontSize: 13, fontWeight: '600' },

  // Columns fill all remaining height — independent scroll
  cols:      { flex: 1, flexDirection: 'row' },
  col:       { flex: 1 },
  colDivider:{ width: 1, backgroundColor: C.border },
  colHead:   { fontWeight: '700', fontSize: 13, paddingHorizontal: 4, paddingBottom: 8, paddingTop: 2 },
  noResults: { color: C.muted, fontSize: 12, padding: 8 },
  skeleton:  { backgroundColor: C.card, height: 200, borderRadius: 12, marginBottom: 8 },
  endText:   { color: C.muted, fontSize: 11 },

  // Product card
  card:         { backgroundColor: C.card, borderWidth: 1.5, borderColor: C.border, borderRadius: 12, padding: 8, marginBottom: 8 },
  cardStaged:   { borderColor: C.gold, backgroundColor: '#1e1d14' },
  cardUnavail:  { opacity: 0.45 },
  cardTop:      { flexDirection: 'row', gap: 8, marginBottom: 8 },
  pimg:         { width: 70, height: 70, borderRadius: 8, backgroundColor: '#22253a', flexShrink: 0 },
  pph:          { width: 70, height: 70, borderRadius: 8, backgroundColor: '#22253a', flexShrink: 0, alignItems: 'center', justifyContent: 'center' },
  pinfo:        { flex: 1, justifyContent: 'flex-start' },
  pn:           { fontSize: 12, fontWeight: '600', color: C.text, lineHeight: 17, marginBottom: 2 },
  punit:        { fontSize: 11, color: C.muted, marginBottom: 2 },
  unavailTag:   { color: '#f87171', fontSize: 10, fontWeight: '700' },
  pbr:          { fontSize: 11, color: C.sub, marginBottom: 3 },
  ppl:          { flexDirection: 'row', alignItems: 'baseline', gap: 4, flexWrap: 'wrap', marginBottom: 1, marginTop: 2 },
  price:        { fontWeight: '800', fontSize: 15 },
  was:          { fontSize: 11, color: C.muted, textDecorationLine: 'line-through' },
  stag:         { backgroundColor: '#4a1d96', borderRadius: 4, paddingHorizontal: 4, paddingVertical: 1 },
  stagText:     { color: '#ddd6fe', fontSize: 9, fontWeight: '700' },
  cup:          { fontSize: 10, color: C.muted },
  cartBtn:     { width: '100%', paddingVertical: 8, backgroundColor: '#163020', borderWidth: 1, borderColor: C.green, borderRadius: 7, alignItems: 'center', marginTop: 2 },
  cartBtnText: { fontSize: 12, fontWeight: '700', color: C.green },

  // Battle picker modal
  modalOverlay:      { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  modalSheet:        { backgroundColor: '#1a1d27', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, paddingBottom: 36 },
  modalTitle:        { color: '#f0f0f0', fontWeight: '800', fontSize: 17, marginBottom: 4 },
  modalSub:          { color: '#6b7280', fontSize: 13, marginBottom: 16 },
  modalSectionLabel: { color: '#6b7280', fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.8, marginTop: 8, marginBottom: 4 },
  modalOpt:          { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#20232f', borderRadius: 12, padding: 14, marginBottom: 8 },
  modalOptIcon:      { fontSize: 22 },
  modalOptTitle:     { color: '#f0f0f0', fontWeight: '700', fontSize: 14 },
  modalOptSub:       { color: '#6b7280', fontSize: 12, marginTop: 1 },
  modalCancel:       { alignItems: 'center', padding: 14, marginTop: 4 },
  modalCancelText:   { color: '#6b7280', fontWeight: '600', fontSize: 15 },

  toast: { position: 'absolute', bottom: 28, left: 24, right: 24, backgroundColor: '#1e2230', borderWidth: 1.5, borderColor: C.gold, borderRadius: 14, paddingVertical: 11, paddingHorizontal: 18, alignItems: 'center', shadowColor: '#000', shadowOpacity: 0.4, shadowRadius: 8, elevation: 10 },
  toastText: { color: C.gold, fontWeight: '700', fontSize: 14 },
});
