// screens/AccessScreen.js
// Invite-code flow:
//   1. User enters a single-use invite code
//   2. Server burns the code and returns a permanent token
//   3. Token saved to SecureStore — used as x-bb-access on all future requests
//   4. Screen never shown again unless token is revoked

import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ActivityIndicator, KeyboardAvoidingView, Platform, Image,
} from 'react-native';
import * as SecureStore from 'expo-secure-store';

const SERVER  = 'https://basketbattle-server.onrender.com';
const TOKEN_KEY = 'bb_access_token_v2';

export const ACCESS_TOKEN_KEY = TOKEN_KEY;

export async function loadAccessToken() {
  try { return await SecureStore.getItemAsync(TOKEN_KEY); }
  catch { return null; }
}

export async function clearAccessToken() {
  try { await SecureStore.deleteItemAsync(TOKEN_KEY); } catch {}
}

export default function AccessScreen({ onSuccess }) {
  const [code, setCode]     = useState('');
  const [status, setStatus] = useState('idle'); // idle | checking | error
  const [errMsg, setErrMsg] = useState('');
  const inputRef = useRef(null);

  async function handleSubmit() {
    const trimmed = code.trim().toUpperCase();
    if (!trimmed) return;
    setStatus('checking');
    setErrMsg('');

    try {
      const res = await fetch(`${SERVER}/redeem-invite`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: trimmed }),
      });
      const data = await res.json().catch(() => ({}));

      if (res.ok && data.ok && data.token) {
        await SecureStore.setItemAsync(TOKEN_KEY, data.token);
        setStatus('idle');
        onSuccess(data.token);
      } else {
        setStatus('error');
        const msg = data.error || '';
        if (msg.includes('already used')) {
          setErrMsg('That invite code has already been used. Ask for a new one.');
        } else if (msg.includes('Invalid')) {
          setErrMsg('Invalid code. Double-check and try again.');
        } else {
          setErrMsg('Could not verify — check your connection and try again.');
        }
      }
    } catch (e) {
      setStatus('error');
      setErrMsg('Could not reach server. Check your internet and try again.');
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={styles.inner}>
        <Image
          source={require('../assets/icon.png')}
          style={styles.logo}
          resizeMode="contain"
        />
        <Text style={styles.title}>BasketBattle</Text>
        <Text style={styles.sub}>Private — invite only</Text>

        <View style={styles.card}>
          <Text style={styles.label}>Enter your invite code</Text>
          <TextInput
            ref={inputRef}
            style={[styles.input, status === 'error' && styles.inputErr]}
            value={code}
            onChangeText={t => { setCode(t.toUpperCase()); setStatus('idle'); setErrMsg(''); }}
            placeholder="e.g. XKVB3R2A"
            placeholderTextColor="#4a5168"
            autoCapitalize="characters"
            autoCorrect={false}
            returnKeyType="go"
            onSubmitEditing={handleSubmit}
            editable={status !== 'checking'}
          />

          {!!errMsg && <Text style={styles.errMsg}>{errMsg}</Text>}

          <TouchableOpacity
            style={[styles.btn, (status === 'checking' || !code.trim()) && styles.btnDim]}
            onPress={handleSubmit}
            disabled={status === 'checking' || !code.trim()}
            activeOpacity={0.8}
          >
            {status === 'checking'
              ? <ActivityIndicator size="small" color="#1a1100" />
              : <Text style={styles.btnText}>Join →</Text>
            }
          </TouchableOpacity>
        </View>

        <Text style={styles.hint}>
          Each invite code is single-use.{'\n'}Ask someone already using BasketBattle.
        </Text>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f1117' },
  inner: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32 },
  logo:  { width: 100, height: 100, marginBottom: 16, borderRadius: 22 },
  title: { fontSize: 26, fontWeight: '800', color: '#f0f0f0', letterSpacing: 0.5, marginBottom: 4 },
  sub:   { fontSize: 13, color: '#6b7280', marginBottom: 36 },
  card:  {
    width: '100%', backgroundColor: '#1a1d27',
    borderRadius: 16, borderWidth: 1, borderColor: '#2a2d3a',
    padding: 22, marginBottom: 20,
  },
  label: { color: '#a0a8b8', fontSize: 12, fontWeight: '600', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.8 },
  input: {
    backgroundColor: '#12151f', borderWidth: 1.5, borderColor: '#2a2d3a',
    borderRadius: 10, padding: 14, fontSize: 19, color: '#f0f0f0',
    letterSpacing: 4, textAlign: 'center', marginBottom: 14,
    fontWeight: '700',
  },
  inputErr: { borderColor: '#d32f2f' },
  errMsg:   { color: '#ef5350', fontSize: 12, marginBottom: 12, lineHeight: 17 },
  btn:      { backgroundColor: '#f59e0b', borderRadius: 10, paddingVertical: 14, alignItems: 'center' },
  btnDim:   { opacity: 0.5 },
  btnText:  { color: '#1a1100', fontWeight: '800', fontSize: 15 },
  hint:     { color: '#4a5168', fontSize: 12, textAlign: 'center', lineHeight: 19 },
});
