// screens/SplashScreen.js
// Animated splash screen that pings the server and shows progress.
// Designed to mask the ~30s Koyeb cold start.

import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, Animated, Easing, Dimensions,
} from 'react-native';

const { width, height } = Dimensions.get('window');
const SERVER_URL = 'https://basketbattle-server.onrender.com';

const TIPS = [
  '💡 Tip: Tap ⚔️ on any product to add it to a battle',
  '💡 Tip: Long press an item in your list to remove it',
  '💡 Tip: Share your household code to sync with family',
  '💡 Tip: Gold crown = cheapest per unit price',
  '💡 Tip: Cart auto-saves to history after 3 days',
  '💡 Tip: Search both stores at once from the Search tab',
  '💡 Tip: Tap a battle item to add it straight to your list',
];

export default function SplashScreen({ onReady }) {
  const [status, setStatus]     = useState('Waking up server…');
  const [tipIdx, setTipIdx]     = useState(0);
  const [dots, setDots]         = useState('');

  // Animations
  const logoScale   = useRef(new Animated.Value(0)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const barWidth    = useRef(new Animated.Value(0)).current;
  const tipOpacity  = useRef(new Animated.Value(0)).current;
  const pulse       = useRef(new Animated.Value(1)).current;
  const cartBounce  = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Logo entrance
    Animated.parallel([
      Animated.spring(logoScale, {
        toValue: 1, tension: 50, friction: 7, useNativeDriver: true,
      }),
      Animated.timing(logoOpacity, {
        toValue: 1, duration: 600, useNativeDriver: true,
      }),
    ]).start();

    // Cart bounce loop
    Animated.loop(
      Animated.sequence([
        Animated.timing(cartBounce, { toValue: -12, duration: 400, easing: Easing.out(Easing.quad), useNativeDriver: true }),
        Animated.timing(cartBounce, { toValue: 0,   duration: 400, easing: Easing.in(Easing.quad),  useNativeDriver: true }),
        Animated.delay(800),
      ])
    ).start();

    // Pulse glow
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.08, duration: 1000, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 1,    duration: 1000, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ])
    ).start();

    // Rotating tips every 4 seconds
    const tipTimer = setInterval(() => {
      Animated.timing(tipOpacity, { toValue: 0, duration: 300, useNativeDriver: true }).start(() => {
        setTipIdx(i => (i + 1) % TIPS.length);
        Animated.timing(tipOpacity, { toValue: 1, duration: 300, useNativeDriver: true }).start();
      });
    }, 4000);
    Animated.timing(tipOpacity, { toValue: 1, duration: 600, delay: 1000, useNativeDriver: true }).start();

    // Animated dots
    const dotTimer = setInterval(() => {
      setDots(d => d.length >= 3 ? '' : d + '.');
    }, 500);

    // Progress bar — animate to 85% over 25s, then wait for server
    Animated.timing(barWidth, {
      toValue: 85, duration: 25000, easing: Easing.out(Easing.exp), useNativeDriver: false,
    }).start();

    // Poll the server
    let attempts = 0;
    const messages = [
      'Waking up server…',
      'Connecting to BasketBattle…',
      'Almost there…',
      'Just a moment…',
      'Server is warming up…',
    ];

    async function ping() {
      attempts++;
      setStatus(messages[Math.min(attempts - 1, messages.length - 1)]);
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 8000);
        const res = await fetch(SERVER_URL + '/ping', { signal: controller.signal });
        clearTimeout(timer);
        if (res.ok) {
          // Server is up — complete the bar and finish
          setStatus('Ready!');
          Animated.timing(barWidth, {
            toValue: 100, duration: 500, easing: Easing.out(Easing.quad), useNativeDriver: false,
          }).start(() => {
            setTimeout(onReady, 400);
          });
          clearInterval(tipTimer);
          clearInterval(dotTimer);
          return;
        }
      } catch {}
      // Try again in 3 seconds
      setTimeout(ping, 3000);
    }

    // Start pinging after logo animation settles
    setTimeout(ping, 800);

    return () => {
      clearInterval(tipTimer);
      clearInterval(dotTimer);
    };
  }, []);

  const barWidthPct = barWidth.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%'],
  });

  const isReady = status === 'Ready!';

  return (
    <View style={styles.container}>
      {/* Background gradient circles */}
      <View style={styles.bgCircle1} />
      <View style={styles.bgCircle2} />

      {/* Logo area */}
      <Animated.View style={[styles.logoWrap, { opacity: logoOpacity, transform: [{ scale: logoScale }] }]}>
        <Animated.View style={[styles.logoGlow, { transform: [{ scale: pulse }] }]} />
        <Animated.Text style={[styles.cartEmoji, { transform: [{ translateY: cartBounce }] }]}>
          🛒
        </Animated.Text>
        <Text style={styles.appName}>BasketBattle</Text>
        <Text style={styles.tagline}>Compare. Save. Shop smarter.</Text>
      </Animated.View>

      {/* Store badges */}
      <Animated.View style={[styles.badges, { opacity: logoOpacity }]}>
        <View style={[styles.badge, { borderColor: '#d32f2f22' }]}>
          <View style={[styles.badgeDot, { backgroundColor: '#d32f2f' }]} />
          <Text style={styles.badgeText}>Coles</Text>
        </View>
        <Text style={styles.badgeVs}>vs</Text>
        <View style={[styles.badge, { borderColor: '#2e7d3222' }]}>
          <View style={[styles.badgeDot, { backgroundColor: '#2e7d32' }]} />
          <Text style={styles.badgeText}>Woolworths</Text>
        </View>
      </Animated.View>

      {/* Loading section */}
      <View style={styles.loadingWrap}>
        {/* Progress bar */}
        <View style={styles.barTrack}>
          <Animated.View style={[styles.barFill, { width: barWidthPct }, isReady && styles.barFillDone]} />
        </View>

        {/* Status */}
        <Text style={styles.status}>
          {isReady ? '✅ Ready!' : status + dots}
        </Text>

        {/* Tip */}
        <Animated.Text style={[styles.tip, { opacity: tipOpacity }]}>
          {TIPS[tipIdx]}
        </Animated.Text>
      </View>

      {/* Footer */}
      <Text style={styles.footer}>Made for Australian households 🇦🇺</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f1117',
    alignItems: 'center',
    justifyContent: 'center',
  },

  // Background decoration
  bgCircle1: {
    position: 'absolute', top: -80, right: -80,
    width: 280, height: 280, borderRadius: 140,
    backgroundColor: 'rgba(245,158,11,0.06)',
  },
  bgCircle2: {
    position: 'absolute', bottom: -60, left: -60,
    width: 220, height: 220, borderRadius: 110,
    backgroundColor: 'rgba(245,158,11,0.04)',
  },

  // Logo
  logoWrap: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoGlow: {
    position: 'absolute',
    width: 120, height: 120, borderRadius: 60,
    backgroundColor: 'rgba(245,158,11,0.12)',
    top: -10,
  },
  cartEmoji: {
    fontSize: 72,
    marginBottom: 16,
  },
  appName: {
    fontSize: 36,
    fontWeight: '900',
    color: '#f0f0f0',
    letterSpacing: -1,
    marginBottom: 8,
  },
  tagline: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '500',
    letterSpacing: 0.5,
  },

  // Store badges
  badges: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 50,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: '#1a1d27',
  },
  badgeDot: {
    width: 7, height: 7, borderRadius: 4,
  },
  badgeText: {
    color: '#a0a8b8',
    fontSize: 13,
    fontWeight: '600',
  },
  badgeVs: {
    color: '#f59e0b',
    fontWeight: '800',
    fontSize: 14,
  },

  // Loading
  loadingWrap: {
    width: width * 0.75,
    alignItems: 'center',
  },
  barTrack: {
    width: '100%',
    height: 4,
    backgroundColor: '#1a1d27',
    borderRadius: 2,
    overflow: 'hidden',
    marginBottom: 12,
  },
  barFill: {
    height: '100%',
    backgroundColor: '#f59e0b',
    borderRadius: 2,
  },
  barFillDone: {
    backgroundColor: '#4caf50',
  },
  status: {
    color: '#a0a8b8',
    fontSize: 13,
    fontWeight: '500',
    marginBottom: 20,
  },
  tip: {
    color: '#4a5568',
    fontSize: 12,
    textAlign: 'center',
    lineHeight: 18,
    paddingHorizontal: 10,
  },

  footer: {
    position: 'absolute',
    bottom: 40,
    color: '#374151',
    fontSize: 12,
  },
});
