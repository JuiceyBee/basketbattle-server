// screens/BattlesScreen.js
//
// Structure:
//   Top level = "folders" (groupTags) — e.g. "Weekly Staples", "Dinners"
//   Inside each folder = individual battle groups
//   Each battle item has a qty that is saved back to server
//   "Add to Cart" on a battle adds the cheapest item (× qty) to the app cart
//   "Add All to Cart" on a folder adds the cheapest item from every battle inside it
//
// Backward compat: battles are still stored as a flat array on the server.
// Grouping is handled by a `groupTag` field on each battle (default: "Ungrouped").

import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Animated, PanResponder,
  ActivityIndicator, Image, ScrollView, Modal, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getBattles, saveBattles, addHistoryEntry } from '../services/api';
import { searchColes, searchWoolworths } from '../services/storeService';
import { addItemsToCart, addItemsToCartWithMultibuyPrompt, calcItemPrice } from './CartScreen';

const C = {
  red: '#d32f2f', green: '#2e7d32', gold: '#f59e0b',
  bg: '#0f1117', card: '#1a1d27', card2: '#20232f',
  border: '#2a2d3a', text: '#f0f0f0', muted: '#6b7280', sub: '#a0a8b8',
};

const DEFAULT_GROUP = 'Ungrouped';

// ── Helpers ───────────────────────────────────────────────────────────────────

function parseUnitPrice(str) {
  if (!str) return Infinity;
  const m = str.match(/^\$?([\d.]+)\s*c\b|^\$?([\d.]+)/i);
  if (!m) return Infinity;
  const price = m[1] ? parseFloat(m[1]) / 100 : parseFloat(m[2]);
  if (isNaN(price)) return Infinity;
  const u = str.match(/[\/per]+\s*([\d.]+)?\s*(kg|g|l|ml|each|ea|pk)\b/i);
  if (!u) return price;
  const qty = u[1] ? parseFloat(u[1]) : 1;
  const unit = u[2].toLowerCase();
  if (unit === 'kg') return price / (qty * 1000) * 100;
  if (unit === 'g')  return price / qty * 100;
  if (unit === 'l')  return price / (qty * 1000) * 100;
  if (unit === 'ml') return price / qty * 100;
  return price / qty;
}

// Normalize any unit price string to a common base: $ per 100g (or per 100ml)
// Returns Infinity if unparseable
function normalizeUnitPrice(unitPriceStr, packagePrice, packageUnit) {
  // First try to parse the unitPrice string directly (e.g. "$1.23 / 100g")
  if (unitPriceStr) {
    const m = unitPriceStr.match(/\$?([\d.]+)\s*(?:c)?\s*[\/per]+\s*([\d.]+)?\s*(kg|g|l|ml|L)/i);
    if (m) {
      const price = parseFloat(m[1]);
      const qty   = m[2] ? parseFloat(m[2]) : 1;
      const unit  = m[3].toLowerCase();
      if (!isNaN(price) && qty > 0) {
        // Normalise to per-100g or per-100ml
        if (unit === 'kg') return price / (qty * 10);      // $/kg → $/100g
        if (unit === 'g')  return price * 100 / qty;       // $/Xg → $/100g
        if (unit === 'l')  return price / (qty * 10);      // $/L → $/100ml
        if (unit === 'ml') return price * 100 / qty;       // $/Xml → $/100ml
      }
    }
    // Cents per unit e.g. "43c / 100g"
    const cm = unitPriceStr.match(/([\d.]+)\s*c\s*[\/per]+\s*([\d.]+)?\s*(kg|g|l|ml)/i);
    if (cm) {
      const price = parseFloat(cm[1]) / 100;
      const qty   = cm[2] ? parseFloat(cm[2]) : 1;
      const unit  = cm[3].toLowerCase();
      if (!isNaN(price) && qty > 0) {
        if (unit === 'kg') return price / (qty * 10);
        if (unit === 'g')  return price * 100 / qty;
        if (unit === 'l')  return price / (qty * 10);
        if (unit === 'ml') return price * 100 / qty;
      }
    }
  }
  // Fallback: derive from package price + unit string e.g. "500g", "1.5kg", "2L"
  if (packagePrice && packageUnit) {
    const um = packageUnit.match(/([\d.]+)\s*(kg|g|l|ml|L)/i);
    if (um) {
      const qty  = parseFloat(um[1]);
      const unit = um[2].toLowerCase();
      if (!isNaN(qty) && qty > 0) {
        if (unit === 'kg') return packagePrice / (qty * 10);
        if (unit === 'g')  return packagePrice * 100 / qty;
        if (unit === 'l')  return packagePrice / (qty * 10);
        if (unit === 'ml') return packagePrice * 100 / qty;
      }
    }
  }
  return Infinity;
}

// Sort items by either total price or normalised unit price
function sortItems(items, mode) {
  return [...items].sort((a, b) => {
    if (mode === 'unit') {
      const ua = normalizeUnitPrice(a.unitPrice, a.price, a.unit);
      const ub = normalizeUnitPrice(b.unitPrice, b.price, b.unit);
      if (isFinite(ua) && isFinite(ub) && Math.abs(ua - ub) > 0.0001) return ua - ub;
      // Fall through to price if unit prices equal or unavailable
    }
    return (a.price || 99) - (b.price || 99);
  });
}

function groupSaving(battle) {
  const c = (battle.items || []).filter(i => i.store === 'coles');
  const w = (battle.items || []).filter(i => i.store === 'woolworths');
  if (!c.length || !w.length) return null;
  const ct = c.reduce((s, i) => s + (i.price || 0) * (i.qty || 1), 0);
  const wt = w.reduce((s, i) => s + (i.price || 0) * (i.qty || 1), 0);
  const diff = ct - wt;
  return { colesTot: ct, wowTot: wt, winner: diff > 0.005 ? 'woolworths' : diff < -0.005 ? 'coles' : 'tie', saving: Math.abs(diff) };
}

// Returns the cheapest item in a battle
function cheapestItem(battle, sortMode = 'price') {
  return sortItems(battle.items || [], sortMode)[0] || null;
}


// ── Swipeable row — swipe right to reveal red delete button ──────────────────
// SwipeableRow: swipe right → delete, swipe left → cart (optional)
function SwipeableRow({ onDelete, onCart, children, containerStyle }) {
  const translateX = useRef(new Animated.Value(0)).current;
  const DELETE_WIDTH = 80;
  const CART_WIDTH   = onCart ? 80 : 0;

  const panResponder = useRef(PanResponder.create({
    onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dx) > 8 && Math.abs(g.dx) > Math.abs(g.dy),
    onPanResponderMove: (_, g) => {
      if (g.dx > 0) {
        translateX.setValue(Math.min(g.dx, DELETE_WIDTH));
      } else if (CART_WIDTH > 0 && g.dx < 0) {
        translateX.setValue(Math.max(g.dx, -CART_WIDTH));
      }
    },
    onPanResponderRelease: (_, g) => {
      if (g.dx > DELETE_WIDTH * 0.5) {
        Animated.spring(translateX, { toValue: DELETE_WIDTH, useNativeDriver: true }).start();
      } else if (CART_WIDTH > 0 && g.dx < -CART_WIDTH * 0.5) {
        Animated.spring(translateX, { toValue: -CART_WIDTH, useNativeDriver: true }).start();
      } else {
        Animated.spring(translateX, { toValue: 0, useNativeDriver: true }).start();
      }
    },
  })).current;

  function close() {
    Animated.spring(translateX, { toValue: 0, useNativeDriver: true }).start();
  }

  // Buttons are absolutely positioned behind the item.
  // The item (full width, solid background) slides over them on swipe.
  return (
    <View style={[swipeStyles.container, containerStyle]}>
      {/* Delete button fixed on left edge */}
      <TouchableOpacity
        style={swipeStyles.deleteBtn}
        onPress={() => { close(); onDelete(); }}
        activeOpacity={0.85}
      >
        <Text style={swipeStyles.deleteBtnText}>Delete</Text>
      </TouchableOpacity>

      {/* Cart button fixed on right edge */}
      {onCart && (
        <TouchableOpacity
          style={swipeStyles.cartBtn}
          onPress={() => { close(); onCart(); }}
          activeOpacity={0.85}
        >
          <Text style={swipeStyles.cartBtnText}>🛒 Add</Text>
        </TouchableOpacity>
      )}

      {/* Item slides left/right over the buttons */}
      <Animated.View
        style={[swipeStyles.item, { transform: [{ translateX }] }]}
        {...panResponder.panHandlers}
      >
        {children}
      </Animated.View>
    </View>
  );
}

const swipeStyles = StyleSheet.create({
  container:     { position: 'relative', overflow: 'hidden' },
  deleteBtn:     { position: 'absolute', top: 0, bottom: 0, left: 0, width: 80, backgroundColor: '#c0392b', justifyContent: 'center', alignItems: 'center', borderRadius: 10 },
  deleteBtnText: { color: '#fff', fontWeight: '800', fontSize: 13 },
  cartBtn:       { position: 'absolute', top: 0, bottom: 0, right: 0, width: 80, backgroundColor: '#2e7d32', justifyContent: 'center', alignItems: 'center', borderRadius: 10 },
  cartBtnText:   { color: '#fff', fontWeight: '800', fontSize: 13 },
  item:          { backgroundColor: 'transparent' },
});

// ── QtyControl ────────────────────────────────────────────────────────────────
function QtyControl({ qty, onChange }) {
  return (
    <View style={styles.qty}>
      <TouchableOpacity style={styles.qtyBtn} onPress={() => onChange(Math.max(1, qty - 1))}>
        <Text style={styles.qtyBtnText}>−</Text>
      </TouchableOpacity>
      <Text style={styles.qtyVal}>{qty}</Text>
      <TouchableOpacity style={styles.qtyBtn} onPress={() => onChange(qty + 1)}>
        <Text style={styles.qtyBtnText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

// ── BattleItem row ────────────────────────────────────────────────────────────
function BattleItem({ item, rank, isCheapest, isMultibuyCheapest, qty, onQtyChange }) {
  const color = item.store === 'coles' ? C.red : C.green;
  const totalPrice = calcItemPrice(item, qty);
  const priceEa    = qty > 0 ? totalPrice / qty : (item.price || 0);
  return (
    <View style={[styles.bitem, isCheapest && styles.bitemCheapest]}>
      {isMultibuyCheapest && !isCheapest && (
        <View style={[styles.crown, { backgroundColor: C.gold + '22', borderColor: C.gold }]}>
          <Text style={[styles.crownText, { color: C.gold }]}>Multibuy 👑</Text>
        </View>
      )}
      {isCheapest && !isMultibuyCheapest && (
        <View style={styles.crown}><Text style={styles.crownText}>👑 cheapest</Text></View>
      )}
      {isCheapest && isMultibuyCheapest && (
        <View style={styles.crown}><Text style={styles.crownText}>👑 cheapest</Text></View>
      )}
      <Text style={[styles.brank, isCheapest && styles.brankGold]}>{rank}</Text>

      {item.imgUrl
        ? <Image source={{ uri: item.imgUrl }} style={styles.bimg} resizeMode="contain" />
        : <View style={styles.bimgPh}><Text style={{ fontSize: 16 }}>🛒</Text></View>
      }

      <View style={styles.bbody}>
        <Text style={styles.bname} numberOfLines={2}>{item.name}</Text>
        <View style={styles.bsub}>
          <View style={[styles.bdot, { backgroundColor: color }]} />
          <Text style={[styles.bsubText, { color }]}>{item.store === 'coles' ? 'Coles' : 'Woolworths'}</Text>
          {!!item.unit && <Text style={styles.bsubText}> · {item.unit}</Text>}
          {!!item.isOnSpecial && !item.multiBuy && <View style={styles.bsale}><Text style={styles.bsaleText}>SALE</Text></View>}
          {!!item.multiBuy && (
            <View style={[styles.bsale, { backgroundColor: '#14532d' }]}>
              <Text style={[styles.bsaleText, { color: '#4ade80' }]}>
                {item.multiBuy.qty} for ${item.multiBuy.price.toFixed(2)}
              </Text>
            </View>
          )}
        </View>
        {!!item.unitPrice && <Text style={styles.bcup}>{item.unitPrice}</Text>}
      </View>

      <View style={styles.bright}>
        <Text style={[styles.bprice, { color }]}>${totalPrice.toFixed(2)}</Text>
        <Text style={styles.bpriceEa}>${priceEa.toFixed(2)} ea</Text>
        <QtyControl qty={qty} onChange={onQtyChange} />
      </View>
    </View>
  );
}

// ── BattleCard ────────────────────────────────────────────────────────────────
function BattleCard({ battle, allBattles, allGroupNames, onUpdate, onDelete, onCartAdd }) {
  const [open, setOpen]         = useState(battle.open !== false);
  const [renaming, setRenaming] = useState(false);
  const [newName, setNewName]   = useState(battle.name);
  const [moving, setMoving]     = useState(false);
  const [addedOk, setAddedOk]   = useState(false);
  const [sortMode, setSortMode] = useState('price'); // 'price' | 'unit'
  const saving = groupSaving(battle);
  const ranked = sortItems(battle.items || [], sortMode);

  // Check if any item has parseable unit price data
  const hasUnitPrices = (battle.items || []).some(i =>
    normalizeUnitPrice(i.unitPrice, i.price, i.unit) < Infinity
  );

  function updateItemQty(item, newQty) {
    const updated = {
      ...battle,
      items: (battle.items || []).map(i =>
        i.id === item.id && i.store === item.store ? { ...i, qty: newQty } : i
      ),
    };
    onUpdate(updated);
  }

  function removeItem(item) {
    const updated = { ...battle, items: (battle.items || []).filter(i => !(i.id === item.id && i.store === item.store)) };
    onUpdate(updated);
  }

  async function confirmRename() {
    const trimmed = newName.trim();
    if (!trimmed || trimmed === battle.name) { setRenaming(false); setNewName(battle.name); return; }
    if ((allBattles || []).some(g => g.name !== battle.name && g.name.toLowerCase() === trimmed.toLowerCase())) {
      Alert.alert('Name already used', '"' + trimmed + '" already exists.');
      return;
    }
    await onUpdate({ ...battle, name: trimmed }, battle.name);
    setRenaming(false);
  }

  function handleAddToCart() {
    const cheap = cheapestItem(battle, sortMode);
    if (!cheap) return;
    const qty = cheap.qty || 1;
    setAddedOk(true);
    setTimeout(() => setAddedOk(false), 2500);
    onCartAdd([{ ...cheap, qty }]);
  }

  const winnerColor = saving
    ? (saving.winner === 'coles' ? C.red : saving.winner === 'woolworths' ? C.green : C.muted)
    : C.muted;

  return (
    <View style={styles.bcard}>
      {/* Header — swipeable: right=delete, no cart here */}
      <SwipeableRow onDelete={onDelete} containerStyle={{ borderRadius: 12 }}>
        <View style={styles.bcardHeader}>
          {renaming ? (
            <TextInput
              style={styles.renameInput}
              value={newName}
              onChangeText={setNewName}
              onBlur={confirmRename}
              onSubmitEditing={confirmRename}
              autoFocus selectTextOnFocus returnKeyType="done"
            />
          ) : (
            <TouchableOpacity onLongPress={() => { setRenaming(true); setNewName(battle.name); }} onPress={() => !renaming && setOpen(o => !o)} style={{ flex: 1 }}>
              <Text style={styles.bcardTitle}>{battle.name}</Text>
            </TouchableOpacity>
          )}
          <Text style={styles.bcardMeta}>{(battle.items || []).length} items</Text>

          {/* Move to group button */}
          <TouchableOpacity onPress={() => setMoving(true)} style={styles.moveBtn}>
            <Text style={styles.moveBtnText}>📁</Text>
          </TouchableOpacity>

          {hasUnitPrices && (
            <TouchableOpacity
              onPress={(e) => { e.stopPropagation?.(); setSortMode(m => m === 'price' ? 'unit' : 'price'); }}
              style={[styles.sortToggle, sortMode === 'unit' && styles.sortToggleActive]}
            >
              <Text style={[styles.sortToggleText, sortMode === 'unit' && styles.sortToggleTextActive]}>
                {sortMode === 'unit' ? '$/unit' : '$/total'}
              </Text>
            </TouchableOpacity>
          )}
          <Text style={[styles.bcardToggle, open && styles.bcardToggleOpen]}>▾</Text>
        </View>
      </SwipeableRow>

      {/* Items */}
      {open && (
        <View style={styles.bcardItems}>
          {ranked.map((item, i) => {
            // isMultibuyCheapest: buying at multibuy qty gives cheaper priceEa than current winner
            const cheapestPriceEa = ranked[0] ? (ranked[0].price || 0) : Infinity;
            const isMultibuyCheapest = !!(
              item.multiBuy &&
              item.multiBuy.priceEa < cheapestPriceEa &&
              i !== 0
            );
            return (
            <SwipeableRow
              key={item.id + '-' + item.store}
              onDelete={() => removeItem(item)}
              onCart={() => onCartAdd([{ ...item, qty: item.qty || 1 }])}
              containerStyle={{ marginBottom: 5, borderRadius: 10 }}
            >
              <BattleItem
                item={item}
                rank={i + 1}
                isCheapest={i === 0}
                isMultibuyCheapest={isMultibuyCheapest}
                qty={item.qty || 1}
                onQtyChange={qty => updateItemQty(item, qty)}
              />
            </SwipeableRow>
            );
          })}
        </View>
      )}

      {/* Footer: saving banner + Add to Cart */}
      <View style={styles.bcardFooter}>
        {saving && saving.winner !== 'tie' ? (
          <Text style={[styles.savingText, { color: winnerColor }]}>
            {saving.winner === 'woolworths' ? '🟢' : '🔴'} saves ${saving.saving.toFixed(2)}
            <Text style={styles.savingDetail}>  (${saving.colesTot.toFixed(2)} vs ${saving.wowTot.toFixed(2)})</Text>
          </Text>
        ) : saving ? (
          <Text style={styles.savingTie}>Same price</Text>
        ) : (
          <Text style={styles.savingNone}>
            {(() => {
              const c = cheapestItem(battle, sortMode);
              if (!c) return '';
              if (sortMode === 'unit') {
                const up = normalizeUnitPrice(c.unitPrice, c.price, c.unit);
                return `Cheapest/100: ${c.store === 'coles' ? '🔴' : '🟢'} ${isFinite(up) ? '$' + up.toFixed(2) : '$' + (c.price||0).toFixed(2)}`;
              }
              return `Cheapest: ${c.store === 'coles' ? '🔴' : '🟢'} $${(c.price||0).toFixed(2)}`;
            })()}
          </Text>
        )}

        <TouchableOpacity
          style={[styles.cartBtn, addedOk && styles.cartBtnOk]}
          onPress={handleAddToCart}
          disabled={addedOk || !(battle.items || []).length}
        >
          <Text style={styles.cartBtnText}>
            {addedOk ? '✅ Added' : '🛒 Add cheapest to cart'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Move to group modal */}
      <Modal visible={moving} transparent animationType="slide" onRequestClose={() => setMoving(false)}>
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setMoving(false)}>
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>Move "{battle.name}" to…</Text>
            {/* No folder option */}
            <TouchableOpacity
              style={[styles.modalOpt, (!battle.groupTag || battle.groupTag === DEFAULT_GROUP) && styles.modalOptActive]}
              onPress={() => {
                onUpdate({ ...battle, groupTag: '' }, battle.name);
                setMoving(false);
              }}
            >
              <Text style={styles.modalOptText}>
                {(!battle.groupTag || battle.groupTag === DEFAULT_GROUP) ? '✓ ' : ''}📋 No folder (top level)
              </Text>
            </TouchableOpacity>
            {allGroupNames.map(gName => (
              <TouchableOpacity
                key={gName}
                style={[styles.modalOpt, battle.groupTag === gName && styles.modalOptActive]}
                onPress={() => {
                  onUpdate({ ...battle, groupTag: gName }, battle.name);
                  setMoving(false);
                }}
              >
                <Text style={styles.modalOptText}>
                  {battle.groupTag === gName ? '✓ ' : ''}📁 {gName}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

// ── FolderSection ─────────────────────────────────────────────────────────────
function FolderSection({ name, battles, allBattles, allGroupNames, onUpdate, onDelete, onCartAdd, onRenameFolder, onDeleteFolder }) {
  const [open, setOpen] = useState(false);
  const [renamingFolder, setRenamingFolder] = useState(false);
  const [folderName, setFolderName] = useState(name);
  const [addingAll, setAddingAll] = useState(false);
  const [allAddedOk, setAllAddedOk] = useState(false);

  async function handleAddAllToCart() {
    if (addingAll || allAddedOk) return;
    setAddingAll(true);
    const items = battles.map(b => {
      const cheap = cheapestItem(b);
      return cheap ? { ...cheap, qty: cheap.qty || 1 } : null;
    }).filter(Boolean);
    if (items.length) await onCartAdd(items);
    setAddingAll(false);
    setAllAddedOk(true);
    setTimeout(() => setAllAddedOk(false), 2500);
  }

  function confirmFolderRename() {
    const trimmed = folderName.trim();
    if (!trimmed || trimmed === name) { setRenamingFolder(false); setFolderName(name); return; }
    onRenameFolder(name, trimmed);
    setRenamingFolder(false);
  }

  const isDefault = name === DEFAULT_GROUP;

  return (
    <View style={styles.folder}>
      {/* Folder header — swipeable: right=delete */}
      <SwipeableRow onDelete={() => onDeleteFolder(name)} containerStyle={{ marginBottom: 6, borderRadius: 12 }}>
        <View style={styles.folderHeader}>
          <TouchableOpacity onPress={() => setOpen(o => !o)} style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Text style={styles.folderIcon}>{open ? '📂' : '📁'}</Text>
            {renamingFolder ? (
              <TextInput
                style={styles.folderRenameInput}
                value={folderName}
                onChangeText={setFolderName}
                onBlur={confirmFolderRename}
                onSubmitEditing={confirmFolderRename}
                autoFocus selectTextOnFocus returnKeyType="done"
              />
            ) : (
              <TouchableOpacity
                onPress={() => setOpen(o => !o)}
                onLongPress={() => !isDefault && setRenamingFolder(true)}
                style={{ flex: 1 }}
              >
                <Text style={styles.folderName}>{name}</Text>
              </TouchableOpacity>
            )}
            <Text style={styles.folderCount}>{battles.length} battle{battles.length !== 1 ? 's' : ''}</Text>
          </TouchableOpacity>

          {/* Add all to cart */}
          <TouchableOpacity
            style={[styles.folderCartBtn, allAddedOk && styles.folderCartBtnOk]}
            onPress={handleAddAllToCart}
            disabled={addingAll || allAddedOk || !battles.length}
          >
            <Text style={styles.folderCartBtnText}>
              {addingAll ? '…' : allAddedOk ? '✅' : '🛒 All'}
            </Text>
          </TouchableOpacity>
        </View>
      </SwipeableRow>

      {open && (
        <View style={styles.folderBody}>
          {battles.length === 0 ? (
            <Text style={styles.folderEmpty}>No battles in this group</Text>
          ) : (
            battles.map(battle => (
              <BattleCard
                key={battle.name}
                battle={battle}
                allBattles={allBattles}
                allGroupNames={allGroupNames}
                onUpdate={onUpdate}
                onDelete={() => onDelete(battle)}
                onCartAdd={onCartAdd}
              />
            ))
          )}
        </View>
      )}
    </View>
  );
}

// ── Main screen ───────────────────────────────────────────────────────────────

// ── Simple toast notification ─────────────────────────────────────────────────
function Toast({ message, visible }) {
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.sequence([
        Animated.timing(opacity, { toValue: 1, duration: 200, useNativeDriver: true }),
        Animated.delay(2000),
        Animated.timing(opacity, { toValue: 0, duration: 400, useNativeDriver: true }),
      ]).start();
    }
  }, [visible, message]);

  if (!message) return null;
  return (
    <Animated.View style={[toastStyles.wrap, { opacity }]} pointerEvents="none">
      <Text style={toastStyles.text}>{message}</Text>
    </Animated.View>
  );
}

const toastStyles = StyleSheet.create({
  wrap: {
    position: 'absolute', bottom: 90, left: 20, right: 20,
    backgroundColor: 'rgba(30,34,48,0.95)', borderRadius: 12,
    paddingVertical: 12, paddingHorizontal: 16,
    alignItems: 'center', zIndex: 999,
    borderWidth: 1, borderColor: '#2a2d3a',
  },
  text: { color: '#fff', fontSize: 13, fontWeight: '600', textAlign: 'center' },
});

export default function BattlesScreen() {
  const [battles, setBattles]     = useState([]);
  const [loading, setLoading]     = useState(true);
  const [newFolderModal, setNewFolderModal] = useState(false);
  const [newFolderName, setNewFolderName]   = useState('');
  const [toast, setToast]         = useState({ message: '', visible: false });
  const [refreshing, setRefreshing] = useState(false);
  const saveTimerRef = useRef(null);
  const toastTimer   = useRef(null);

  function showToast(message) {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ message, visible: true });
    toastTimer.current = setTimeout(() => setToast(t => ({ ...t, visible: false })), 2500);
  }

  // Refresh live prices for all battle items on focus
  async function refreshPrices(battles) {
    if (!battles || !battles.length) return battles;
    setRefreshing(true);
    try {
      // Collect unique items per store
      const colesItems = [];
      const wowItems = [];
      battles.forEach(b => {
        (b.items || []).forEach(item => {
          if (item.store === 'coles' && !colesItems.find(i => i.id === item.id))
            colesItems.push(item);
          if (item.store === 'woolworths' && !wowItems.find(i => i.id === item.id))
            wowItems.push(item);
        });
      });

      // Fetch fresh prices — search by name, match by id
      const priceMap = {}; // "store:id" -> fresh price + wasPrice

      await Promise.allSettled([
        // Coles — search each unique item name
        ...colesItems.map(async item => {
          try {
            const results = await searchColes(item.name, 1);
            const match = results.find(r => r.id === item.id);
            if (match) priceMap[`coles:${item.id}`] = { price: match.price, wasPrice: match.wasPrice, isOnSpecial: match.isOnSpecial };
          } catch {}
        }),
        // Woolworths — search each unique item name
        ...wowItems.map(async item => {
          try {
            const results = await searchWoolworths(item.name, 1);
            const match = results.find(r => r.id === item.id);
            if (match) priceMap[`woolworths:${item.id}`] = { price: match.price, wasPrice: match.wasPrice, isOnSpecial: match.isOnSpecial };
          } catch {}
        }),
      ]);

      // Apply updated prices to battles
      const updated = battles.map(b => ({
        ...b,
        items: (b.items || []).map(item => {
          const fresh = priceMap[`${item.store}:${item.id}`];
          return fresh ? { ...item, ...fresh } : item;
        }),
      }));

      // Save if any prices changed
      const changed = JSON.stringify(updated) !== JSON.stringify(battles);
      if (changed) {
        setBattles(updated);
        await saveBattles(updated).catch(() => {});
      }
      return updated;
    } catch (e) {
      console.warn('[PriceRefresh]', e.message);
      return battles;
    } finally {
      setRefreshing(false);
    }
  }

  useFocusEffect(useCallback(() => {
    setLoading(true);
    getBattles()
      .then(data => {
        const battles = Array.isArray(data) ? data : [];
        setBattles(battles);
        // Refresh prices in background after battles load
        refreshPrices(battles);
      })
      .catch(() => setBattles([]))
      .finally(() => setLoading(false));
  }, []));

  // Debounced save — waits 800ms after last change before hitting server
  // This means qty changes don't spam the server on every tap
  function schedSave(updated) {
    setBattles(updated);
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(async () => {
      try { await saveBattles(updated); }
      catch (e) { Alert.alert('Sync error', e.message); }
    }, 800);
  }

  async function updateBattle(updated, oldName) {
    const matchName = oldName || updated.name;
    const next = battles.map(b => b.name === matchName ? updated : b);
    schedSave(next);
  }

  async function deleteBattle(battle) {
    const updated = battles.filter(b => b.name !== battle.name);
    schedSave(updated);
    showToast('"' + battle.name + '" deleted');
  }

  async function handleCartAdd(items) {
    try {
      const result = await new Promise((resolve) => addItemsToCartWithMultibuyPrompt(items, resolve));
      if (result && result.syncEnabled && result.storeResults) {
        const lines = [];
        for (const store of ['coles', 'woolworths']) {
          const r = result.storeResults[store];
          if (!r) continue;
          const ok = r.filter(x => x.ok).length;
          const bad = r.filter(x => !x.ok);
          const label = store === 'coles' ? '🔴 Coles' : '🟢 Woolworths';
          lines.push(bad.length === 0 ? `${label}: ${ok} added ✓` : `${label}: ${ok} added, ${bad.length} failed`);
        }
        if (lines.length) showToast(lines.join('\n'));
      }
    } catch (e) {
      Alert.alert('Cart error', e.message);
    }
  }

  function renameFolder(oldName, newName) {
    const next = battles.map(b => b.groupTag === oldName ? { ...b, groupTag: newName } : b);
    schedSave(next);
  }

  function deleteFolder(folderName) {
    const next = battles.map(b => b.groupTag === folderName ? { ...b, groupTag: DEFAULT_GROUP } : b);
    schedSave(next);
    showToast('"' + folderName + '" folder deleted');
  }

  function createFolder() {
    const name = newFolderName.trim();
    if (!name) return;
    if (allGroupNames.includes(name)) {
      Alert.alert('Already exists', 'A folder called "' + name + '" already exists.');
      return;
    }
    // Create folder by adding a placeholder that we immediately remove — 
    // actually just store the folder name by moving the first ungrouped battle into it
    // Easier: we track folder names separately in a dummy battle with no items... 
    // Simplest: just note that a folder exists if any battle has that groupTag.
    // So to "create" an empty folder we temporarily add a marker battle then let the
    // user move battles into it. Let's just save a "folder marker" battle with no items.
    const next = [...battles, { name: '__folder__' + name, groupTag: name, items: [], _isFolderMarker: true }];
    schedSave(next);
    setNewFolderName('');
    setNewFolderModal(false);
  }

  // Build folder structure — battles with no groupTag sit at top level (ungrouped)
  const realBattles = battles.filter(b => !b._isFolderMarker);
  const ungroupedBattles = realBattles.filter(b => !b.groupTag || b.groupTag === DEFAULT_GROUP);
  const folderNames = [
    ...battles
      .map(b => b.groupTag || '')
      .filter(g => g && g !== DEFAULT_GROUP)
      .filter((g, i, a) => a.indexOf(g) === i),
  ];
  const allGroupNames = folderNames; // for move-to-folder modal

  const byGroup = {};
  folderNames.forEach(g => { byGroup[g] = []; });
  realBattles.forEach(b => {
    if (b.groupTag && b.groupTag !== DEFAULT_GROUP) {
      if (!byGroup[b.groupTag]) byGroup[b.groupTag] = [];
      byGroup[b.groupTag].push(b);
    }
  });

  if (loading) {
    return <View style={styles.centered}><ActivityIndicator size="large" color={C.gold} /></View>;
  }

  return (
    <View style={styles.container}>
      {/* Title row */}
      <View style={styles.titleRow}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Text style={styles.pageTitle}>⚔️ Battles</Text>
          {refreshing && <ActivityIndicator size="small" color={C.gold} />}
        </View>
        <TouchableOpacity style={styles.newFolderBtn} onPress={() => { setNewFolderName(''); setNewFolderModal(true); }}>
          <Text style={styles.newFolderBtnText}>+ Folder</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={{ padding: 12, paddingBottom: 100 }}>
        {realBattles.length === 0 ? (
          <View style={styles.empty}>
            <Text style={styles.emptyIco}>⚔️</Text>
            <Text style={styles.emptyTitle}>No battles yet</Text>
            <Text style={styles.emptySub}>
              Tap ⚔️ on any product in Search, pick items from both stores, then tap ⚔️ Battle.
            </Text>
          </View>
        ) : (
          <>
            {/* Ungrouped battles — shown directly at top level */}
            {ungroupedBattles.map(battle => (
              <BattleCard
                key={battle.name}
                battle={battle}
                allBattles={realBattles}
                allGroupNames={allGroupNames}
                onUpdate={updateBattle}
                onDelete={() => deleteBattle(battle)}
                onCartAdd={handleCartAdd}
              />
            ))}
            {/* Folder sections */}
            {folderNames.map(groupName => (
              <FolderSection
                key={groupName}
                name={groupName}
                battles={byGroup[groupName] || []}
                allBattles={realBattles}
                allGroupNames={allGroupNames}
                onUpdate={updateBattle}
                onDelete={deleteBattle}
                onCartAdd={handleCartAdd}
                onRenameFolder={renameFolder}
                onDeleteFolder={deleteFolder}
              />
            ))}
          </>
        )}
      </ScrollView>

      {/* New folder modal */}
      <Modal visible={newFolderModal} transparent animationType="fade" onRequestClose={() => setNewFolderModal(false)}>
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setNewFolderModal(false)}>
            <TouchableOpacity activeOpacity={1} onPress={() => {}}>
              <View style={[styles.modalSheet, { paddingBottom: 24 }]}>
                <Text style={styles.modalTitle}>New Folder</Text>
                <TextInput
                  style={styles.folderNameInput}
                  placeholder="Folder name (e.g. Weekly Staples)"
                  placeholderTextColor={C.muted}
                  value={newFolderName}
                  onChangeText={setNewFolderName}
                  autoFocus
                  returnKeyType="done"
                  onSubmitEditing={createFolder}
                />
                <TouchableOpacity style={styles.folderCreateBtn} onPress={createFolder}>
                  <Text style={styles.folderCreateBtnText}>Create Folder</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          </TouchableOpacity>
        </KeyboardAvoidingView>
      </Modal>
      <Toast message={toast.message} visible={toast.visible} />
    </View>
  );
}

const styles = StyleSheet.create({
  container:   { flex: 1, backgroundColor: C.bg },
  centered:    { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.bg },
  titleRow:    { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 56, paddingBottom: 8 },
  pageTitle:   { fontSize: 22, fontWeight: '800', color: C.text },
  newFolderBtn:     { backgroundColor: C.card2, borderWidth: 1, borderColor: C.border, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 7 },
  newFolderBtnText: { color: C.gold, fontWeight: '700', fontSize: 13 },

  empty:       { alignItems: 'center', paddingTop: 60, padding: 30 },
  emptyIco:    { fontSize: 40, marginBottom: 12 },
  emptyTitle:  { color: C.text, fontSize: 16, fontWeight: '700', marginBottom: 8 },
  emptySub:    { color: C.muted, fontSize: 13, textAlign: 'center', lineHeight: 19 },

  // Folder
  folder:       { marginBottom: 16 },
  folderHeader: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card2, borderWidth: 1.5, borderColor: C.border, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10 },
  folderIcon:   { fontSize: 18, marginRight: 2 },
  folderName:   { fontSize: 15, fontWeight: '800', color: C.text, flex: 1 },
  folderRenameInput: { flex: 1, color: C.text, fontWeight: '800', fontSize: 15, borderBottomWidth: 1.5, borderBottomColor: C.gold, paddingVertical: 2 },
  folderCount:  { fontSize: 11, color: C.muted, marginRight: 8 },
  folderBody:   { paddingLeft: 8 },
  folderEmpty:  { color: C.muted, fontSize: 12, paddingLeft: 12, paddingVertical: 8 },
  folderCartBtn:     { backgroundColor: C.gold, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5, marginLeft: 6 },
  folderCartBtnOk:   { backgroundColor: C.green },
  folderCartBtnText: { color: '#1a1100', fontWeight: '700', fontSize: 12 },

  // Battle card
  bcard:         { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 12, marginBottom: 10, overflow: 'hidden' },
  bcardHeader:   { flexDirection: 'row', alignItems: 'center', gap: 6, padding: 12, paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: C.border, backgroundColor: C.card },
  bcardTitle:    { fontWeight: '700', fontSize: 14, color: C.text, flex: 1 },
  bcardMeta:     { fontSize: 11, color: C.muted },
  bcardToggle:   { color: C.muted, fontSize: 14, marginLeft: 2 },
  bcardToggleOpen: { transform: [{ rotate: '180deg' }] },
  bcardItems:    { padding: 8 },
  bcardFooter:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 10, paddingHorizontal: 12, borderTopWidth: 1, borderTopColor: C.border },
  moveBtn:       { padding: 4 },
  moveBtnText:   { fontSize: 15 },

  savingText:   { fontSize: 12, fontWeight: '700', flex: 1 },
  savingDetail: { color: C.muted, fontWeight: '400', fontSize: 11 },
  savingTie:    { fontSize: 12, color: C.muted, flex: 1 },
  savingNone:   { fontSize: 12, color: C.muted, flex: 1 },
  cartBtn:      { backgroundColor: C.gold, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  cartBtnOk:    { backgroundColor: C.green },
  cartBtnText:  { color: '#1a1100', fontWeight: '700', fontSize: 12 },

  renameInput:  { flex: 1, color: C.text, fontWeight: '700', fontSize: 14, borderBottomWidth: 1.5, borderBottomColor: C.gold, paddingVertical: 2, paddingHorizontal: 4 },
  sortToggle:       { borderWidth: 1, borderColor: C.border, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 3, marginLeft: 2 },
  sortToggleActive: { borderColor: C.gold, backgroundColor: 'rgba(245,158,11,0.12)' },
  sortToggleText:   { color: C.muted, fontSize: 10, fontWeight: '700' },
  sortToggleTextActive: { color: C.gold },
  editHint:     { color: C.muted, fontSize: 11, fontWeight: '400' },

  // Battle item row
  bitem:         { flexDirection: 'row', alignItems: 'center', gap: 7, padding: 8, borderRadius: 10, borderWidth: 1.5, borderColor: 'transparent', backgroundColor: C.card },
  bitemCheapest: { borderColor: C.gold, backgroundColor: '#1f1e18' },
  crown:         { position: 'absolute', top: 0, left: '30%', backgroundColor: C.gold, borderBottomLeftRadius: 6, borderBottomRightRadius: 6, paddingHorizontal: 7, paddingVertical: 1 },
  crownText:     { color: '#1a1100', fontSize: 9, fontWeight: '700' },
  brank:         { color: C.muted, fontWeight: '800', fontSize: 12, width: 14, textAlign: 'center' },
  brankGold:     { color: C.gold },
  bimg:          { width: 42, height: 42, borderRadius: 7, backgroundColor: '#22253a' },
  bimgPh:        { width: 42, height: 42, borderRadius: 7, backgroundColor: '#22253a', alignItems: 'center', justifyContent: 'center' },
  bbody:         { flex: 1, minWidth: 0 },
  bname:         { fontSize: 12, fontWeight: '600', color: C.text, lineHeight: 16 },
  bsub:          { flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 2, flexWrap: 'wrap' },
  bdot:          { width: 5, height: 5, borderRadius: 3 },
  bsubText:      { fontSize: 10, color: C.muted },
  bsale:         { backgroundColor: '#4a1d96', borderRadius: 3, paddingHorizontal: 3, paddingVertical: 1 },
  bsaleText:     { color: '#ddd6fe', fontSize: 8, fontWeight: '700' },
  bcup:          { fontSize: 10, color: C.muted, marginTop: 1 },
  bright:        { alignItems: 'flex-end', gap: 2 },
  bprice:        { fontWeight: '800', fontSize: 14 },
  bpriceEa:      { fontSize: 9, color: C.muted },
  brmv:          { color: C.muted, fontSize: 10 },

  // Qty control
  qty:           { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: C.border, borderRadius: 6, overflow: 'hidden', marginTop: 2 },
  qtyBtn:        { backgroundColor: C.card2, width: 22, height: 22, alignItems: 'center', justifyContent: 'center' },
  qtyBtnText:    { color: C.text, fontSize: 14, lineHeight: 20 },
  qtyVal:        { minWidth: 22, textAlign: 'center', fontWeight: '700', fontSize: 12, color: C.text, backgroundColor: C.card },

  // Modals
  modalOverlay:  { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  modalSheet:    { backgroundColor: C.card, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, paddingBottom: 36 },
  modalTitle:    { color: C.text, fontWeight: '800', fontSize: 16, marginBottom: 16 },
  modalOpt:      { padding: 14, borderRadius: 10, marginBottom: 6, backgroundColor: C.card2, borderWidth: 1, borderColor: C.border },
  modalOptActive:{ borderColor: C.gold },
  modalOptText:  { color: C.text, fontWeight: '600', fontSize: 14 },
  folderNameInput:   { backgroundColor: C.card2, borderWidth: 1.5, borderColor: C.border, borderRadius: 10, padding: 12, color: C.text, fontSize: 15, marginBottom: 14 },
  folderCreateBtn:   { backgroundColor: C.gold, borderRadius: 10, padding: 14, alignItems: 'center' },
  folderCreateBtnText: { color: '#1a1100', fontWeight: '800', fontSize: 15 },
});
