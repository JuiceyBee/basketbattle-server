// screens/LoginWebViewScreen.js
//
// APPROACH: After the user logs in, we inject JS into the WebView to call the
// store's own API (from inside the WebView, where the HttpOnly cookies live).
// The WebView posts the response headers/cookies back via postMessage.
// We store those cookies in SecureStore for later use in RN fetch calls.
//
// Why: document.cookie can't read HttpOnly cookies. The RN fetch and WebView
// cookie jars are separate on Android. So we bridge them via injected JS.

import React, { useState, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { WebView } from 'react-native-webview';
import { STORES, saveCookies, loadCookies, mergeCookies } from '../services/storeAuth';

// Injected after every page load — grabs everything accessible + polls for changes
const COOKIE_HARVEST_JS = `
(function() {
  function harvest() {
    var data = {
      type: 'harvest',
      url: location.href,
      cookie: document.cookie || '',
      ls: {},
      ss: {},
    };
    // Grab localStorage tokens
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k) data.ls[k] = localStorage.getItem(k);
      }
    } catch(e) {}
    // Grab sessionStorage tokens
    try {
      for (var j = 0; j < sessionStorage.length; j++) {
        var k2 = sessionStorage.key(j);
        if (k2) data.ss[k2] = sessionStorage.getItem(k2);
      }
    } catch(e) {}
    window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify(data));
  }

  harvest();
  setTimeout(harvest, 800);
  setTimeout(harvest, 2500);
  setTimeout(harvest, 5000);

  // Also watch URL changes (SPA navigation)
  var _lastUrl = location.href;
  setInterval(function() {
    if (location.href !== _lastUrl) {
      _lastUrl = location.href;
      setTimeout(harvest, 400);
      setTimeout(harvest, 1500);
    }
  }, 600);
})();
true;
`;

// Called after user confirms login — does an authenticated fetch INSIDE the WebView
// to a lightweight store endpoint, then posts the response cookies/headers back
function buildApiFetchJS(store) {
  if (store === 'woolworths') {
    return `
(function() {
  fetch('https://www.woolworths.com.au/apis/ui/v2/page/my-account', {
    credentials: 'include',
    headers: { 'Accept': 'application/json' }
  })
  .then(function(r) {
    return r.json().then(function(body) {
      window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({
        type: 'apifetch',
        store: 'woolworths',
        status: r.status,
        cookie: document.cookie || '',
        body: JSON.stringify(body).slice(0, 500),
      }));
    });
  })
  .catch(function(e) {
    window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({
      type: 'apifetch',
      store: 'woolworths',
      status: 0,
      cookie: document.cookie || '',
      error: e.toString(),
    }));
  });
})();
true;
    `;
  } else {
    // Coles — call a lightweight auth-check endpoint
    return `
(function() {
  fetch('https://www.coles.com.au/api/bff/navigation/v1/header', {
    credentials: 'include',
    headers: { 'Accept': 'application/json' }
  })
  .then(function(r) {
    return r.json().then(function(body) {
      window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({
        type: 'apifetch',
        store: 'coles',
        status: r.status,
        cookie: document.cookie || '',
        body: JSON.stringify(body).slice(0, 500),
      }));
    });
  })
  .catch(function(e) {
    window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({
      type: 'apifetch',
      store: 'coles',
      status: 0,
      cookie: document.cookie || '',
      error: e.toString(),
    }));
  });
})();
true;
    `;
  }
}

export default function LoginWebViewScreen({ route, navigation }) {
  const { store } = route.params;
  const info = STORES[store];

  const [status, setStatus] = useState('loading'); // loading | idle | checking | success | error
  const [errorMsg, setErrorMsg] = useState('');
  const [debugLog, setDebugLog] = useState([]); // shown to user for transparency

  const webviewRef      = useRef(null);
  const harvestedRef    = useRef({ cookie: '', ls: {}, ss: {} });
  const doneRef         = useRef(false);

  function addLog(msg) {
    setDebugLog(prev => [...prev.slice(-4), msg]); // keep last 5 lines
    console.log('[LoginWebView]', msg);
  }

  // Called every page load — accumulate everything visible
  function onMessage(event) {
    try {
      const msg = JSON.parse(event.nativeEvent.data);

      if (msg.type === 'harvest') {
        // Merge cookie string
        if (msg.cookie) {
          harvestedRef.current.cookie = mergeCookies(harvestedRef.current.cookie, msg.cookie);
        }
        // Merge localStorage/sessionStorage
        Object.assign(harvestedRef.current.ls, msg.ls || {});
        Object.assign(harvestedRef.current.ss, msg.ss || {});

        const totalKeys = Object.keys(harvestedRef.current.ls).length + Object.keys(harvestedRef.current.ss).length;
        addLog(`Page: ${(msg.url||'').split('/').slice(0,4).join('/')} | cookie: ${harvestedRef.current.cookie.length}ch | storage: ${totalKeys} keys`);
      }

      if (msg.type === 'authCheck') {
        addLog(`Auth check: cookie=${msg.hasCookie} token=${msg.hasToken} url=${(msg.url||'').split('/').slice(0,4).join('/')}`);
        if (msg.hasCookie || msg.hasToken) {
          // Confirmed auth — now do the API fetch to get full cookies
          webviewRef.current?.injectJavaScript(buildApiFetchJS(store));
        } else {
          addLog('Auth cookies not present yet — still in login flow');
          // Don't trigger success — user may still be on OTP step
        }
      }

      if (msg.type === 'apifetch') {
        addLog(`API fetch → status ${msg.status}${msg.error ? ' ERROR:' + msg.error : ''}`);
        if (msg.cookie) {
          harvestedRef.current.cookie = mergeCookies(harvestedRef.current.cookie, msg.cookie);
        }
        // Treat any non-401 response as "we have a session"
        if (msg.status >= 200 && msg.status < 400) {
          finaliseSave('API call confirmed login ✓');
        } else if (msg.status === 401 || msg.status === 403) {
          setStatus('error');
          setErrorMsg('Store says you\'re not logged in (401). Please sign in fully on the page, then try again.');
        } else {
          // Still save whatever we have — API might be blocked, but cookies may work
          finaliseSave('API check inconclusive — saving session anyway');
        }
      }
    } catch(e) {
      console.warn('[LoginWebView] onMessage parse error:', e.message);
    }
  }

  async function finaliseSave(reason) {
    if (doneRef.current) return;
    doneRef.current = true;

    // Build a combined cookie string from everything we found
    const h = harvestedRef.current;
    let combined = h.cookie || '';

    // Add token-like localStorage/sessionStorage entries as pseudo-cookies
    // Prioritise known auth/refresh token keys
    const TOKEN_KEYS = [
      'refresh_token', 'refreshToken', 'wow-refresh-token', 'wowRefreshToken',
      'access_token', 'accessToken', 'wow-auth-token', 'wowAuthToken',
      'id_token', 'wow_auth', 'auth_token',
    ];
    const allStorage = { ...h.ls, ...h.ss };
    // First pass: known token keys
    for (const k of TOKEN_KEYS) {
      const v = allStorage[k];
      if (v && v.length < 4000) {
        combined = mergeCookies(combined, `${k}=${v}`);
      }
    }
    // Second pass: anything else that looks token-like
    for (const [k, v] of Object.entries(allStorage)) {
      if (TOKEN_KEYS.includes(k)) continue; // already handled
      if (v && v.length < 2000 && (
        k.toLowerCase().includes('token') ||
        k.toLowerCase().includes('auth') ||
        k.toLowerCase().includes('refresh') ||
        k.toLowerCase().includes('session')
      )) {
        combined = mergeCookies(combined, `${k}=${v}`);
      }
    }

    addLog(`Saving: ${combined.length} chars (${reason})`);

    if (combined.length < 10) {
      setStatus('error');
      setErrorMsg('Nothing to save. Make sure you completed sign-in on the page before tapping the button.');
      doneRef.current = false;
      return;
    }

    const existing = await loadCookies(store);
    const merged = mergeCookies(existing || '', combined);
    await saveCookies(store, merged);
    addLog(`Saved ${merged.length} chars total`);
    setStatus('success');
    setTimeout(() => navigation.goBack(), 1800);
  }

  function onNavChange(navState) {
    const url = navState.url || '';
    if (!url || url === 'about:blank') return;

    const isLoginPage = url.includes('sign-in') || url.includes('securelogin')
      || url.includes('login') || url.includes('otp') || url.includes('verify')
      || url.includes('mfa') || url.includes('challenge') || url.includes('confirm');
    const isPostLogin = info.successUrl.test(url) && !isLoginPage;

    if (isPostLogin && !doneRef.current) {
      addLog('Navigated past login page — checking for auth cookies...');
      // For Woolworths, inject JS to check if wow-auth-token actually exists
      // before triggering success — avoids false positive during OTP flow
      setTimeout(() => {
        if (store === 'woolworths') {
          webviewRef.current?.injectJavaScript(`
(function() {
  var hasCookie = document.cookie.includes('wow-auth-token') || document.cookie.includes('WOWAuthToken');
  // Also check localStorage for token
  var hasToken = false;
  try {
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (k && (k.includes('auth') || k.includes('token') || k.includes('wow'))) {
        hasToken = true; break;
      }
    }
  } catch(e) {}
  window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({
    type: 'authCheck',
    store: 'woolworths',
    hasCookie: hasCookie,
    hasToken: hasToken,
    url: location.href,
  }));
})();
true;
          `);
        } else {
          // Coles — just do the API fetch as before
          webviewRef.current?.injectJavaScript(buildApiFetchJS(store));
        }
      }, 2000);
    }
  }

  async function handleManualConfirm() {
    if (doneRef.current) return;
    setStatus('checking');
    addLog('Manual confirm tapped — running API fetch...');
    // Re-harvest first
    webviewRef.current?.injectJavaScript(COOKIE_HARVEST_JS);
    // Then do the API fetch inside WebView
    setTimeout(() => {
      webviewRef.current?.injectJavaScript(buildApiFetchJS(store));
    }, 1000);
    // Fallback: if API fetch takes too long, just save what we have
    setTimeout(() => {
      if (!doneRef.current) {
        addLog('API fetch timed out — saving what we have');
        finaliseSave('timeout fallback');
      }
    }, 8000);
  }

  const storeColor = info.color;

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: storeColor }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.closeBtn}>
          <Text style={[styles.closeText, { color: storeColor }]}>✕ Cancel</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Sign in to {info.name}</Text>
        <View style={{ width: 80 }} />
      </View>

      {/* Instruction banner */}
      {(status === 'idle' || status === 'loading') && (
        <View style={[styles.instructBanner, { backgroundColor: storeColor + '22', borderBottomColor: storeColor + '44' }]}>
          <Text style={[styles.instructText, { color: storeColor }]}>
            Sign in normally below, then tap ✓ I've signed in
          </Text>
        </View>
      )}

      {/* Success overlay */}
      {status === 'success' && (
        <View style={styles.overlay}>
          <Text style={styles.successEmoji}>✅</Text>
          <Text style={styles.successText}>Signed in to {info.name}!</Text>
          <Text style={styles.successSub}>Session saved to this device.</Text>
        </View>
      )}

      {/* Error overlay */}
      {status === 'error' && (
        <View style={styles.overlay}>
          <Text style={styles.errorEmoji}>⚠️</Text>
          <Text style={styles.errorText}>{errorMsg}</Text>
          <TouchableOpacity
            style={[styles.retryBtn, { backgroundColor: storeColor }]}
            onPress={() => {
              doneRef.current = false;
              harvestedRef.current = { cookie: '', ls: {}, ss: {} };
              setDebugLog([]);
              setStatus('loading');
              webviewRef.current?.reload();
            }}
          >
            <Text style={styles.retryText}>Try again</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* WebView */}
      {status !== 'success' && status !== 'error' && (
        <WebView
          ref={webviewRef}
          source={{ uri: info.loginUrl }}
          style={styles.webview}
          injectedJavaScript={COOKIE_HARVEST_JS}
          injectedJavaScriptBeforeContentLoaded={COOKIE_HARVEST_JS}
          onMessage={onMessage}
          onNavigationStateChange={onNavChange}
          onLoadStart={() => { if (status !== 'checking') setStatus('loading'); }}
          onLoadEnd={() => { if (status === 'loading') setStatus('idle'); }}
          sharedCookiesEnabled={true}
          thirdPartyCookiesEnabled={true}
          domStorageEnabled={true}
          javaScriptEnabled={true}
          // Android Chrome UA — stores serve full JS app to this
          userAgent="Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
          cacheEnabled={false}
          incognito={false}
          allowsInlineMediaPlayback={true}
        />
      )}

      {/* Debug log — small text showing what's happening */}
      {debugLog.length > 0 && status !== 'success' && status !== 'error' && (
        <View style={styles.debugBox}>
          {debugLog.map((l, i) => (
            <Text key={i} style={styles.debugLine} numberOfLines={1}>{l}</Text>
          ))}
        </View>
      )}

      {/* Loading spinner */}
      {status === 'loading' && (
        <View style={styles.loadingBar}>
          <ActivityIndicator size="small" color={storeColor} />
        </View>
      )}

      {/* Checking indicator */}
      {status === 'checking' && (
        <View style={styles.checkingBar}>
          <ActivityIndicator size="small" color="#fff" />
          <Text style={styles.checkingText}>Saving session…</Text>
        </View>
      )}

      {/* Confirm button */}
      {(status === 'idle' || status === 'loading') && (
        <TouchableOpacity
          style={[styles.confirmBtn, { backgroundColor: storeColor }]}
          onPress={handleManualConfirm}
        >
          <Text style={styles.confirmText}>✓ I've signed in</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container:      { flex: 1, backgroundColor: '#fff' },
  header:         { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, backgroundColor: '#f9f9f9', borderBottomWidth: 2 },
  closeBtn:       { padding: 4, minWidth: 80 },
  closeText:      { fontWeight: '600', fontSize: 14 },
  title:          { fontWeight: '700', fontSize: 15, flex: 1, textAlign: 'center' },
  webview:        { flex: 1 },

  instructBanner: { paddingHorizontal: 16, paddingVertical: 8, borderBottomWidth: 1 },
  instructText:   { fontSize: 13, fontWeight: '600', textAlign: 'center' },

  overlay:        { ...StyleSheet.absoluteFillObject, backgroundColor: '#fff', zIndex: 10, alignItems: 'center', justifyContent: 'center', padding: 30 },
  successEmoji:   { fontSize: 64, marginBottom: 16 },
  successText:    { fontSize: 20, fontWeight: '700', color: '#2d6a4f', marginBottom: 8 },
  successSub:     { fontSize: 13, color: '#6b7280', textAlign: 'center' },
  errorEmoji:     { fontSize: 48, marginBottom: 16 },
  errorText:      { fontSize: 15, color: '#333', textAlign: 'center', marginBottom: 20, lineHeight: 22 },
  retryBtn:       { borderRadius: 10, paddingHorizontal: 24, paddingVertical: 12 },
  retryText:      { color: '#fff', fontWeight: '700', fontSize: 15 },

  loadingBar:     { position: 'absolute', top: 120, left: 0, right: 0, alignItems: 'center', padding: 6 },
  checkingBar:    { position: 'absolute', bottom: 60, left: 0, right: 0, backgroundColor: '#333', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 12, gap: 8 },
  checkingText:   { color: '#fff', fontWeight: '600' },
  confirmBtn:     { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 18, alignItems: 'center' },
  confirmText:    { color: '#fff', fontWeight: '700', fontSize: 16 },

  debugBox:       { position: 'absolute', bottom: 62, left: 0, right: 0, backgroundColor: 'rgba(0,0,0,0.75)', padding: 6 },
  debugLine:      { color: '#aaa', fontSize: 9, fontFamily: 'monospace', lineHeight: 13 },
});
