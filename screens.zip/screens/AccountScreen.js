// screens/AccountScreen.js
import React, { useState, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Alert,
  ScrollView, TextInput, Share, ActivityIndicator, Switch,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import * as SecureStore from 'expo-secure-store';
import { isLoggedIn, clearCookies } from '../services/storeAuth';
import {
  getHouseholdCode, joinHousehold, clearCredentials, autoInitHousehold,
} from '../services/api';

const C = {
  red: '#d32f2f', green: '#2e7d32', gold: '#f59e0b',
  bg: '#0f1117', card: '#1a1d27', card2: '#20232f',
  border: '#2a2d3a', text: '#f0f0f0', muted: '#6b7280',
};

const SYNC_CART_KEY = 'bb_sync_cart_to_stores';
const MULTIBUY_KEY  = 'bb_multibuy_auto';

export async function getSyncCartToStores() {
  try {
    const val = await SecureStore.getItemAsync(SYNC_CART_KEY);
    return val === 'true';
  } catch { return false; }
}

// Returns 'off' (prompt), 'add' (always add multibuy qty), 'skip' (always single)
export async function getMultibuyMode() {
  try {
    const val = await SecureStore.getItemAsync(MULTIBUY_KEY);
    return val || 'off';
  } catch { return 'off'; }
}

export default function AccountScreen({ navigation }) {
  const [wowAuth, setWowAuth]       = useState(false);
  const [colesAuth, setColesAuth]   = useState(false);
  const [code, setCode]             = useState('');
  const [joinInput, setJoinInput]   = useState('');
  const [joining, setJoining]       = useState(false);
  const [syncCart, setSyncCart]       = useState(false);
  const [multibuyMode, setMultibuyMode] = useState('off');

  useFocusEffect(useCallback(() => {
    Promise.all([
      isLoggedIn('woolworths'),
      isLoggedIn('coles'),
      getSyncCartToStores(),
      getMultibuyMode(),
    ]).then(([w, c, sync, mb]) => {
      setWowAuth(w);
      setColesAuth(c);
      setSyncCart(sync);
      setMultibuyMode(mb);
    }).catch(() => {});
    setCode(getHouseholdCode() || '');
  }, []));

  async function handleSyncToggle(val) {
    setSyncCart(val);
    await SecureStore.setItemAsync(SYNC_CART_KEY, val ? 'true' : 'false');
    if (val && !wowAuth && !colesAuth) {
      Alert.alert(
        'Sign in to stores first',
        'You need to be signed in to Woolworths or Coles to push your cart to them.',
        [{ text: 'OK' }]
      );
    }
  }

  async function handleMultibuyToggle(val) {
    const newMode = val ? 'add' : 'off';
    setMultibuyMode(newMode);
    await SecureStore.setItemAsync(MULTIBUY_KEY, newMode);
  }

  async function handleMultibuyModeChange(mode) {
    setMultibuyMode(mode);
    await SecureStore.setItemAsync(MULTIBUY_KEY, mode);
  }

  async function handleSignIn(store) {
    navigation.navigate('LoginWebView', { store });
  }

  async function handleSignOut(store) {
    const name = store === 'coles' ? 'Coles' : 'Woolworths';
    Alert.alert('Sign out of ' + name + '?', '', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign Out', style: 'destructive', onPress: async () => {
        await clearCookies(store);
        if (store === 'woolworths') setWowAuth(false);
        else setColesAuth(false);
      }},
    ]);
  }

  async function handleShare() {
    if (!code) return;
    try {
      await Share.share({
        message:
          'Join my BasketBattle household!\n\n' +
          'Household code: ' + code + '\n\n' +
          'Open BasketBattle → Account → Join Household, enter the code above.',
      });
    } catch {}
  }

  async function handleJoin() {
    const trimmed = joinInput.trim().toUpperCase();
    if (!trimmed) { Alert.alert('Enter a code', 'Type the household code first.'); return; }
    setJoining(true);
    try {
      await joinHousehold(trimmed);
      setCode(trimmed);
      setJoinInput('');
      Alert.alert('✅ Joined!', 'You are now on household "' + trimmed + '".');
    } catch (e) {
      Alert.alert('Could not join', e.message);
    } finally {
      setJoining(false);
    }
  }

  async function handleLeave() {
    Alert.alert('Leave household?', 'You will get a new private household code.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Leave', style: 'destructive', onPress: async () => {
        await clearCredentials();
        const newCode = await autoInitHousehold();
        setCode(newCode || '');
        Alert.alert('Done', 'You have a new household code.');
      }},
    ]);
  }

  function StoreRow({ store, loggedIn }) {
    const name  = store === 'coles' ? 'Coles' : 'Woolworths';
    const emoji = store === 'coles' ? '🔴' : '🟢';
    const color = store === 'coles' ? C.red : C.green;
    return (
      <View style={styles.storeRow}>
        <Text style={styles.storeLabel}>{emoji} {name}</Text>
        <View style={[styles.statusDot, { backgroundColor: loggedIn ? '#4caf50' : C.muted }]} />
        <Text style={[styles.statusText, { color: loggedIn ? '#4caf50' : C.muted }]}>
          {loggedIn ? 'Signed in' : 'Not signed in'}
        </Text>
        <TouchableOpacity
          style={[styles.storeBtn, { borderColor: color }]}
          onPress={() => loggedIn ? handleSignOut(store) : handleSignIn(store)}
        >
          <Text style={[styles.storeBtnText, { color }]}>
            {loggedIn ? 'Sign out' : 'Sign in'}
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 60 }}>
      <Text style={styles.pageTitle}>👤 Account</Text>

      {/* Store sign-in */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Store accounts</Text>
        <Text style={styles.sectionSub}>
          Sign in to your store accounts to enable syncing your cart directly to Coles and Woolworths.
        </Text>
        <StoreRow store="coles"      loggedIn={colesAuth} />
        <StoreRow store="woolworths" loggedIn={wowAuth}   />
      </View>

      {/* Cart sync toggle */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Cart sync</Text>
        <Text style={styles.sectionSub}>
          When enabled, adding items to your cart will also push them to your Coles and Woolworths online carts.
          Requires being signed in above.
        </Text>
        <View style={styles.toggleRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.toggleLabel}>Push cart to stores</Text>
            <Text style={styles.toggleSub}>
              {syncCart
                ? (wowAuth || colesAuth ? '✅ Active — items will sync to store carts' : '⚠️ Sign in to a store first')
                : 'Off — cart stays in app only'}
            </Text>
          </View>
          <Switch
            value={syncCart}
            onValueChange={handleSyncToggle}
            trackColor={{ false: C.border, true: C.gold + 'aa' }}
            thumbColor={syncCart ? C.gold : C.muted}
          />
        </View>
      </View>

      {/* Multibuy settings */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Multibuy deals</Text>
        <Text style={styles.sectionSub}>
          When stores offer deals like "2 for $5", BasketBattle can handle them automatically
          so you always get the best price without having to think about it.
        </Text>

        <View style={styles.toggleRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.toggleLabel}>Automatic multibuys</Text>
            <Text style={styles.toggleSub}>
              {multibuyMode === 'off'
                ? 'Off — you will be asked each time a multibuy deal is available'
                : multibuyMode === 'add'
                  ? 'On — automatically adds the multibuy qty for the best deal'
                  : 'On — always adds single items, ignoring multibuy deals'}
            </Text>
          </View>
          <Switch
            value={multibuyMode !== 'off'}
            onValueChange={handleMultibuyToggle}
            trackColor={{ false: C.border, true: C.gold + 'aa' }}
            thumbColor={multibuyMode !== 'off' ? C.gold : C.muted}
          />
        </View>

        {multibuyMode !== 'off' && (
          <View style={styles.subToggleGroup}>
            <Text style={styles.subToggleLabel}>When a multibuy deal is available:</Text>

            <TouchableOpacity
              style={[styles.subToggleOption, multibuyMode === 'add' && styles.subToggleOptionActive]}
              onPress={() => handleMultibuyModeChange('add')}
            >
              <View style={styles.subToggleRadio}>
                {multibuyMode === 'add' && <View style={styles.subToggleRadioDot} />}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.subToggleTitle, multibuyMode === 'add' && { color: C.gold }]}>
                  Add multibuy qty
                </Text>
                <Text style={styles.subToggleSub}>
                  e.g. "2 for $5" automatically adds 2. Saves money per item with no prompts.
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.subToggleOption, multibuyMode === 'skip' && styles.subToggleOptionActive]}
              onPress={() => handleMultibuyModeChange('skip')}
            >
              <View style={styles.subToggleRadio}>
                {multibuyMode === 'skip' && <View style={styles.subToggleRadioDot} />}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.subToggleTitle, multibuyMode === 'skip' && { color: C.gold }]}>
                  Don't add multibuy
                </Text>
                <Text style={styles.subToggleSub}>
                  Always adds 1 item. Deal info still shows on cards but is ignored at checkout.
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Household */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Household</Text>
        <Text style={styles.sectionSub}>
          Share a code with anyone in your household to sync battles and your list across devices.
        </Text>

        <View style={styles.codeBox}>
          <Text style={styles.codeLabel}>Your household code</Text>
          <Text style={styles.codeValue}>{code || '…'}</Text>
          <TouchableOpacity style={styles.shareBtn} onPress={handleShare}>
            <Text style={styles.shareBtnText}>Share code</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.joinLabel}>Join a different household</Text>
        <View style={styles.joinRow}>
          <TextInput
            style={styles.joinInput}
            placeholder="Enter code (e.g. ABC123)"
            placeholderTextColor={C.muted}
            value={joinInput}
            onChangeText={t => setJoinInput(t.toUpperCase())}
            autoCapitalize="characters"
            autoCorrect={false}
            maxLength={12}
          />
          <TouchableOpacity
            style={[styles.joinBtn, joining && { opacity: 0.5 }]}
            onPress={handleJoin}
            disabled={joining}
          >
            {joining
              ? <ActivityIndicator size="small" color="#1a1100" />
              : <Text style={styles.joinBtnText}>Join</Text>
            }
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.leaveBtn} onPress={handleLeave}>
          <Text style={styles.leaveBtnText}>Leave current household</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:     { flex: 1, backgroundColor: C.bg },
  pageTitle:     { fontSize: 22, fontWeight: '800', color: C.text, padding: 16, paddingTop: 56 },

  section:       { backgroundColor: C.card, borderTopWidth: 1, borderBottomWidth: 1, borderColor: C.border, padding: 16, marginBottom: 12 },
  sectionTitle:  { color: C.text, fontWeight: '700', fontSize: 15, marginBottom: 4 },
  sectionSub:    { color: C.muted, fontSize: 12, lineHeight: 17, marginBottom: 14 },

  storeRow:      { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderTopWidth: 1, borderTopColor: C.border },
  storeLabel:    { color: C.text, fontWeight: '600', fontSize: 14, flex: 1 },
  statusDot:     { width: 7, height: 7, borderRadius: 4, marginRight: 5 },
  statusText:    { fontSize: 12, marginRight: 10 },
  storeBtn:      { borderWidth: 1.5, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  storeBtnText:  { fontWeight: '700', fontSize: 13 },

  toggleRow:     { flexDirection: 'row', alignItems: 'center', paddingTop: 4 },
  toggleLabel:   { color: C.text, fontWeight: '600', fontSize: 14, marginBottom: 3 },
  toggleSub:     { color: C.muted, fontSize: 12, lineHeight: 16 },

  codeBox:       { backgroundColor: C.card2, borderWidth: 1, borderColor: C.border, borderRadius: 12, padding: 14, alignItems: 'center', marginBottom: 16 },
  codeLabel:     { color: C.muted, fontSize: 12, marginBottom: 6 },
  codeValue:     { color: C.gold, fontWeight: '800', fontSize: 28, letterSpacing: 4, marginBottom: 12 },
  shareBtn:      { backgroundColor: C.gold, borderRadius: 10, paddingHorizontal: 20, paddingVertical: 9 },
  shareBtnText:  { color: '#1a1100', fontWeight: '700', fontSize: 14 },

  joinLabel:     { color: C.muted, fontSize: 12, marginBottom: 8 },
  joinRow:       { flexDirection: 'row', gap: 8, marginBottom: 12 },
  joinInput:     { flex: 1, backgroundColor: C.card2, borderWidth: 1.5, borderColor: C.border, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 10, color: C.text, fontSize: 15, fontWeight: '700', letterSpacing: 2 },
  joinBtn:       { backgroundColor: C.gold, borderRadius: 10, paddingHorizontal: 18, justifyContent: 'center', minWidth: 60, alignItems: 'center' },
  joinBtnText:   { color: '#1a1100', fontWeight: '700', fontSize: 14 },
  leaveBtn:      { alignItems: 'center', padding: 10 },
  leaveBtnText:  { color: C.muted, fontSize: 13 },

  subToggleGroup:        { marginTop: 12, borderTopWidth: 1, borderTopColor: C.border, paddingTop: 12, gap: 8 },
  subToggleLabel:        { color: C.muted, fontSize: 12, marginBottom: 4 },
  subToggleOption:       { flexDirection: 'row', alignItems: 'flex-start', gap: 10, padding: 10, borderRadius: 10, borderWidth: 1.5, borderColor: C.border },
  subToggleOptionActive: { borderColor: C.gold },
  subToggleRadio:        { width: 18, height: 18, borderRadius: 9, borderWidth: 2, borderColor: C.muted, alignItems: 'center', justifyContent: 'center', marginTop: 2 },
  subToggleRadioDot:     { width: 8, height: 8, borderRadius: 4, backgroundColor: C.gold },
  subToggleTitle:        { color: C.text, fontWeight: '600', fontSize: 13, marginBottom: 2 },
  subToggleSub:          { color: C.muted, fontSize: 11, lineHeight: 15 },
});
