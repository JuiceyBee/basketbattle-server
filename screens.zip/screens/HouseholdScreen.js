// screens/HouseholdScreen.js
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ActivityIndicator, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { createHousehold, joinHousehold } from '../services/api';

export default function HouseholdScreen({ onJoined, initialToken }) {
  const [tab, setTab] = useState(initialToken ? 'join' : 'create');
  const [pin, setPin] = useState('');
  const [token, setToken] = useState(initialToken || '');
  const [loading, setLoading] = useState(false);

  async function handleCreate() {
    if (pin.length < 4) { Alert.alert('PIN too short', 'Choose at least 4 characters.'); return; }
    setLoading(true);
    try {
      await createHousehold(pin);
      onJoined();
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally { setLoading(false); }
  }

  async function handleJoin() {
    if (!token) { Alert.alert('Missing token', 'Enter the invite token.'); return; }
    if (pin.length < 4) { Alert.alert('PIN too short', 'Enter the household PIN.'); return; }
    setLoading(true);
    try {
      await joinHousehold(token.trim(), pin);
      onJoined();
    } catch (e) {
      Alert.alert('Could not join', 'Check the token and PIN are correct.');
    } finally { setLoading(false); }
  }

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Text style={styles.logo}>🛒</Text>
      <Text style={styles.title}>BasketBattle</Text>
      <Text style={styles.subtitle}>Compare prices across Woolworths & Coles</Text>

      <View style={styles.tabs}>
        <TouchableOpacity style={[styles.tab, tab === 'create' && styles.tabActive]} onPress={() => setTab('create')}>
          <Text style={[styles.tabText, tab === 'create' && styles.tabTextActive]}>New Household</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, tab === 'join' && styles.tabActive]} onPress={() => setTab('join')}>
          <Text style={[styles.tabText, tab === 'join' && styles.tabTextActive]}>Join Existing</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.card}>
        {tab === 'join' && (
          <>
            <Text style={styles.label}>Invite Token</Text>
            <TextInput
              style={styles.input}
              placeholder="Paste token from invite link"
              value={token}
              onChangeText={setToken}
              autoCapitalize="none"
            />
          </>
        )}
        <Text style={styles.label}>{tab === 'create' ? 'Choose a PIN' : 'Household PIN'}</Text>
        <TextInput
          style={styles.input}
          placeholder={tab === 'create' ? 'At least 4 characters' : 'Enter the shared PIN'}
          value={pin}
          onChangeText={setPin}
          secureTextEntry
        />
        {tab === 'create' && (
          <Text style={styles.hint}>Write this PIN down — you'll share it when inviting others.</Text>
        )}
        <TouchableOpacity style={styles.button} onPress={tab === 'create' ? handleCreate : handleJoin} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : (
            <Text style={styles.buttonText}>{tab === 'create' ? 'Create Household' : 'Join Household'}</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5', alignItems: 'center', justifyContent: 'center', padding: 24 },
  logo: { fontSize: 64 },
  title: { fontSize: 32, fontWeight: '800', color: '#1a1a1a', marginTop: 8 },
  subtitle: { fontSize: 14, color: '#666', marginTop: 4, marginBottom: 32, textAlign: 'center' },
  tabs: { flexDirection: 'row', backgroundColor: '#e0e0e0', borderRadius: 12, marginBottom: 20, padding: 4 },
  tab: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: 'center' },
  tabActive: { backgroundColor: '#fff' },
  tabText: { color: '#888', fontWeight: '600' },
  tabTextActive: { color: '#1a1a1a' },
  card: { backgroundColor: '#fff', borderRadius: 16, padding: 24, width: '100%', shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 12, elevation: 3 },
  label: { fontSize: 13, fontWeight: '600', color: '#444', marginBottom: 6 },
  input: { backgroundColor: '#f5f5f5', borderRadius: 10, padding: 14, fontSize: 16, marginBottom: 16 },
  hint: { fontSize: 12, color: '#888', marginBottom: 16, lineHeight: 18 },
  button: { backgroundColor: '#2d6a4f', borderRadius: 12, padding: 16, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
