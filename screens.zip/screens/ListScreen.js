// screens/ListScreen.js
import React, { useState, useCallback } from 'react';
import {
  View, Text, Image, TouchableOpacity, StyleSheet, Alert,
  ActivityIndicator, ScrollView,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getList, saveList } from '../services/api';
import { addItemsToCart } from './CartScreen';

const C = {
  red: '#d32f2f', green: '#2e7d32', gold: '#f59e0b',
  bg: '#0f1117', card: '#1a1d27', card2: '#20232f',
  border: '#2a2d3a', text: '#f0f0f0', muted: '#6b7280', sub: '#a0a8b8',
};

export default function ListScreen({ navigation }) {
  const [items, setItems]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding]   = useState(false);
  const [addedOk, setAddedOk] = useState(false);

  useFocusEffect(useCallback(() => {
    setLoading(true);
    getList()
      .then(data => setItems(Array.isArray(data) ? data : []))
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  }, []));

  async function removeItem(item) {
    const updated = items.filter(i => !(i.id === item.id && i.store === item.store));
    setItems(updated);
    await saveList(updated);
  }

  async function changeQty(item, delta) {
    const updated = items.map(i => {
      if (i.id !== item.id || i.store !== item.store) return i;
      return { ...i, qty: Math.max(1, (i.qty || 1) + delta) };
    });
    setItems(updated);
    saveList(updated);
  }

  async function clearStore(store) {
    Alert.alert('Clear ' + (store === 'coles' ? 'Coles' : 'Woolworths') + ' list?', '', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear', style: 'destructive', onPress: async () => {
        const updated = items.filter(i => i.store !== store);
        setItems(updated);
        await saveList(updated);
      }},
    ]);
  }

  async function clearAll() {
    Alert.alert('Clear everything?', '', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear All', style: 'destructive', onPress: async () => {
        setItems([]); await saveList([]);
      }},
    ]);
  }

  async function handleAddBothToCart() {
    if (!items.length || adding || addedOk) return;
    setAdding(true);
    try {
      const result = await addItemsToCart(items);
      if (!result || result.appOk === false) {
        Alert.alert('Error', 'Could not add to cart.');
        return;
      }

      setAddedOk(true);
      setTimeout(() => setAddedOk(false), 3000);

      // If store sync was enabled, show a brief summary of what happened
      if (result.syncEnabled) {
        const lines = [];
        for (const store of ['coles', 'woolworths']) {
          const r = result.storeResults && result.storeResults[store];
          if (!r) continue;
          const ok  = r.filter(x => x.ok).length;
          const bad = r.filter(x => !x.ok);
          const label = store === 'coles' ? '🔴 Coles' : '🟢 Woolworths';
          if (bad.length === 0) {
            lines.push(`${label}: ${ok} item${ok !== 1 ? 's' : ''} added ✓`);
          } else {
            lines.push(`${label}: ${ok} added, ${bad.length} failed`);
            bad.slice(0, 2).forEach(b => lines.push(`  • ${b.name || 'item'}: ${b.error || 'failed'}`));
          }
        }
        if (lines.length) {
          Alert.alert('Store cart sync', lines.join('
'));
        }
      }
    } catch (e) {
      Alert.alert('Error', 'Could not add to cart: ' + e.message);
    } finally {
      setAdding(false);
    }
  }

  const colesItems = items.filter(i => i.store === 'coles');
  const wowItems   = items.filter(i => i.store === 'woolworths');

  if (loading) {
    return <View style={styles.centered}><ActivityIndicator size="large" color={C.gold} /></View>;
  }

  function renderItem(item) {
    const color = item.store === 'coles' ? C.red : C.green;
    return (
      <View key={item.id + '-' + item.store} style={styles.li}>
        {/* Image */}
        {item.imgUrl
          ? <Image source={{ uri: item.imgUrl }} style={styles.limg} resizeMode="contain" />
          : <View style={styles.limgPh}><Text style={{ fontSize: 18 }}>🛒</Text></View>
        }
        {/* Info block */}
        <View style={styles.lib}>
          <Text style={styles.lin} numberOfLines={3}>{item.name}</Text>
          {!!item.brand && <Text style={styles.lbrand} numberOfLines={1}>{item.brand}</Text>}
          {!!item.unit && <Text style={styles.liu}>{item.unit}</Text>}
          {!!item.unitPrice && <Text style={styles.liu}>{item.unitPrice}</Text>}
          {/* Price + qty controls on same row */}
          <View style={styles.lfoot}>
            <Text style={[styles.lip, { color }]}>
              ${((item.price || 0) * (item.qty || 1)).toFixed(2)}
            </Text>
            <View style={styles.qty}>
              <TouchableOpacity style={styles.qtyBtn} onPress={() => changeQty(item, -1)}>
                <Text style={styles.qtyBtnText}>−</Text>
              </TouchableOpacity>
              <Text style={styles.qtyVal}>{item.qty || 1}</Text>
              <TouchableOpacity style={styles.qtyBtn} onPress={() => changeQty(item, 1)}>
                <Text style={styles.qtyBtnText}>+</Text>
              </TouchableOpacity>
            </View>
            <TouchableOpacity onPress={() => removeItem(item)} hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}>
              <Text style={styles.rmv}>✕</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.pageTitle}>📋 My List</Text>

      {/* Action bar */}
      <View style={styles.actionBar}>
        <TouchableOpacity
          style={[
            styles.cartBtn,
            (!items.length || adding || addedOk) && styles.cartBtnDisabled,
            addedOk && styles.cartBtnSuccess,
          ]}
          disabled={!items.length || adding || addedOk}
          onPress={handleAddBothToCart}
        >
          <Text style={styles.cartBtnText}>
            {adding ? 'Adding…' : addedOk ? '✅ Added to Cart' : '🛒 Add Both to Cart'}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.clearAllBtn} onPress={clearAll}>
          <Text style={styles.clearAllText}>Clear All</Text>
        </TouchableOpacity>
      </View>

      {items.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyIco}>📋</Text>
          <Text style={styles.emptyTitle}>Your list is empty</Text>
          <Text style={styles.emptySub}>Tap + List on any product in Search or Battles</Text>
        </View>
      ) : (
        <View style={styles.cols}>
          {/* Coles */}
          <View style={styles.col}>
            <View style={styles.colHead}>
              <Text style={[styles.colLabel, { color: C.red }]}>🔴 Coles</Text>
              {colesItems.length > 0 && (
                <TouchableOpacity onPress={() => clearStore('coles')}>
                  <Text style={styles.colClear}>Clear</Text>
                </TouchableOpacity>
              )}
            </View>
            <ScrollView style={styles.colScroll} showsVerticalScrollIndicator={false}>
              {colesItems.length === 0
                ? <Text style={styles.colEmpty}>No Coles items</Text>
                : colesItems.map(renderItem)
              }
            </ScrollView>
          </View>
          <View style={styles.divider} />
          {/* Woolworths */}
          <View style={styles.col}>
            <View style={styles.colHead}>
              <Text style={[styles.colLabel, { color: C.green }]}>🟢 Woolies</Text>
              {wowItems.length > 0 && (
                <TouchableOpacity onPress={() => clearStore('woolworths')}>
                  <Text style={styles.colClear}>Clear</Text>
                </TouchableOpacity>
              )}
            </View>
            <ScrollView style={styles.colScroll} showsVerticalScrollIndicator={false}>
              {wowItems.length === 0
                ? <Text style={styles.colEmpty}>No Woolworths items</Text>
                : wowItems.map(renderItem)
              }
            </ScrollView>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container:      { flex: 1, backgroundColor: C.bg },
  centered:       { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.bg },
  pageTitle:      { fontSize: 22, fontWeight: '800', color: C.text, padding: 16, paddingTop: 56, paddingBottom: 8 },
  actionBar:      { flexDirection: 'row', gap: 8, paddingHorizontal: 12, paddingBottom: 8 },
  cartBtn:        { flex: 1, backgroundColor: C.gold, borderRadius: 10, padding: 11, alignItems: 'center' },
  cartBtnDisabled:{ opacity: 0.35 },
  cartBtnSuccess: { backgroundColor: C.green, opacity: 1 },
  cartBtnText:    { color: '#1a1100', fontWeight: '700', fontSize: 14 },
  clearAllBtn:    { borderWidth: 1, borderColor: C.border, borderRadius: 10, paddingHorizontal: 12, justifyContent: 'center' },
  clearAllText:   { color: C.muted, fontSize: 13 },
  empty:          { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 40 },
  emptyIco:       { fontSize: 40, marginBottom: 12 },
  emptyTitle:     { color: C.text, fontSize: 16, fontWeight: '700', marginBottom: 6 },
  emptySub:       { color: C.muted, fontSize: 13, textAlign: 'center' },
  cols:           { flex: 1, flexDirection: 'row', borderTopWidth: 1, borderTopColor: C.border },
  col:            { flex: 1, overflow: 'hidden' },
  colHead:        { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 8, paddingHorizontal: 10, borderBottomWidth: 1, borderBottomColor: C.border },
  colLabel:       { fontWeight: '700', fontSize: 13 },
  colClear:       { color: C.muted, fontSize: 12 },
  colScroll:      { flex: 1, padding: 6 },
  colEmpty:       { color: C.muted, fontSize: 12, textAlign: 'center', marginTop: 20 },
  divider:        { width: 1, backgroundColor: C.border },
  li:             { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 10, marginBottom: 7, overflow: 'hidden' },
  limg:           { width: '100%', height: 90, backgroundColor: '#22253a' },
  limgPh:         { width: '100%', height: 70, backgroundColor: '#22253a', alignItems: 'center', justifyContent: 'center' },
  lib:            { padding: 7 },
  lin:            { fontSize: 12, fontWeight: '600', color: C.text, lineHeight: 17, marginBottom: 2 },
  lbrand:         { fontSize: 11, color: C.sub, marginBottom: 2 },
  liu:            { fontSize: 10, color: C.muted, marginBottom: 1 },
  lfoot:          { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 5 },
  lip:            { fontWeight: '800', fontSize: 14, color: C.text },
  rmv:            { color: C.muted, fontSize: 15, paddingLeft: 4 },
  qty:            { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: C.border, borderRadius: 5, overflow: 'hidden' },
  qtyBtn:         { backgroundColor: C.card2, width: 22, height: 22, alignItems: 'center', justifyContent: 'center' },
  qtyBtnText:     { color: C.text, fontSize: 14, lineHeight: 20 },
  qtyVal:         { minWidth: 20, textAlign: 'center', fontWeight: '700', fontSize: 12, color: C.text, backgroundColor: C.card },
});
