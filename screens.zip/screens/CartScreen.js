// screens/CartScreen.js
// Active cart (current shop) + past shops history.
// Auto-archives to history if cart is > 3 days old.

import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Alert,
  ActivityIndicator, ScrollView, Image, Animated, PanResponder,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getHouseholdCode, getHistory, addHistoryEntry, deleteHistoryEntry } from '../services/api';
import * as SecureStore from 'expo-secure-store';
import { getSyncCartToStores, getMultibuyMode } from './AccountScreen';
import { addToColesCart, addToWoolworthsCart, updateColesCartItem, updateWoolworthsCartItem, isLoggedIn } from '../services/storeAuth';

const C = {
  red: '#d32f2f', green: '#2e7d32', gold: '#f59e0b',
  bg: '#0f1117', card: '#1a1d27', card2: '#20232f',
  border: '#2a2d3a', text: '#f0f0f0', muted: '#6b7280', sub: '#a0a8b8',
};

const THREE_DAYS = 3 * 24 * 60 * 60 * 1000;
const CART_KEY   = 'bb_cart_v1';

// ── Persist cart locally ─────────────────────────────────────────────────────
async function loadCart() {
  try {
    const raw = await SecureStore.getItemAsync(CART_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}
async function persistCart(cart) {
  try { await SecureStore.setItemAsync(CART_KEY, JSON.stringify(cart)); } catch {}
}
async function clearCart() {
  try { await SecureStore.deleteItemAsync(CART_KEY); } catch {}
}

// ── Helpers ──────────────────────────────────────────────────────────────────
// Push a single item qty change to the store.
// Woolworths UpdateItem is absolute (send new total, 0 = remove).
// Coles POST is incremental — send delta (+1/-1). To remove, send negative of current qty.
async function syncItemToStore(item, newQty) {
  try {
    const syncEnabled = await getSyncCartToStores();
    if (!syncEnabled) return null;
    if (item.store === 'woolworths' && await isLoggedIn('woolworths')) {
      const res = await updateWoolworthsCartItem(item, newQty);
      return { store: 'woolworths', ok: !!(res && res.ok) };
    } else if (item.store === 'coles' && await isLoggedIn('coles')) {
      // Always send absolute qty — PATCH handles add/update/remove
      const res = await updateColesCartItem(item, newQty);
      return { store: 'coles', ok: !!(res && res.ok) };
    }
  } catch (e) {
    console.warn('[CartSync]', e.message);
  }
  return null;
}

// Push all items in a list as removes (qty=0) to their stores
async function syncAllRemovedToStore(items) {
  for (const item of items) {
    await syncItemToStore(item, 0);
  }
}

function totalFor(items) {
  return (items || []).reduce((s, i) => s + (i.price || 0) * (i.qty || 1), 0);
}
function dateStr(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('en-AU', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })
    + ' ' + d.toLocaleTimeString('en-AU', { hour: '2-digit', minute: '2-digit' });
}

// ── Swipeable row — swipe right to reveal red delete button ──────────────────
function SwipeableRow({ onDelete, children, containerStyle }) {
  const translateX = useRef(new Animated.Value(0)).current;
  const DELETE_WIDTH = 80;

  const panResponder = useRef(PanResponder.create({
    onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dx) > 8 && Math.abs(g.dx) > Math.abs(g.dy),
    onPanResponderMove: (_, g) => {
      if (g.dx > 0) translateX.setValue(Math.min(g.dx, DELETE_WIDTH));
    },
    onPanResponderRelease: (_, g) => {
      if (g.dx > DELETE_WIDTH * 0.5) {
        Animated.spring(translateX, { toValue: DELETE_WIDTH, useNativeDriver: true }).start();
      } else {
        Animated.spring(translateX, { toValue: 0, useNativeDriver: true }).start();
      }
    },
  })).current;

  function close() {
    Animated.spring(translateX, { toValue: 0, useNativeDriver: true }).start();
  }

  // Delete button is absolutely positioned on the left, hidden under the item.
  // Item slides right on swipe to reveal it — item always fills full width.
  return (
    <View style={[swipeStyles.container, containerStyle]}>
      <TouchableOpacity
        style={swipeStyles.deleteBtn}
        onPress={() => { close(); onDelete(); }}
        activeOpacity={0.85}
      >
        <Text style={swipeStyles.deleteBtnText}>Delete</Text>
      </TouchableOpacity>
      <Animated.View
        style={[swipeStyles.item, { transform: [{ translateX }] }]}
        {...panResponder.panHandlers}
      >
        {children}
      </Animated.View>
    </View>
  );
}

const swipeStyles = StyleSheet.create({
  container:     { position: 'relative', overflow: 'hidden' },
  deleteBtn:     { position: 'absolute', top: 0, bottom: 0, left: 0, width: 80, backgroundColor: '#c0392b', justifyContent: 'center', alignItems: 'center', borderRadius: 10 },
  deleteBtnText: { color: '#fff', fontWeight: '800', fontSize: 13 },
  item:          { backgroundColor: 'transparent' },
});

// ── Cart item row ─────────────────────────────────────────────────────────────
function CartItem({ item, onTick, onQtyChange }) {
  const color = item.store === 'coles' ? C.red : C.green;
  const qty = item.qty || 1;
  return (
    <TouchableOpacity
      style={styles.li}
      onPress={onTick}
      activeOpacity={1}
    >
      {/* Inner wrapper fades on tick — outer li keeps solid bg so delete button stays hidden */}
      <View style={[styles.liInner, item.ticked && styles.liInnerTicked]}>
        {item.imgUrl
          ? <Image source={{ uri: item.imgUrl }} style={styles.limg} resizeMode="contain" />
          : <View style={styles.limgPh}><Text style={{ fontSize: 14 }}>🛒</Text></View>
        }
        <View style={styles.lib}>
          <Text style={[styles.lin, item.ticked && styles.linTicked]} numberOfLines={2}>{item.name}</Text>
          {!!item.unit && <Text style={styles.liu}>{item.unit} · ${(item.price||0).toFixed(2)} ea</Text>}
          <View style={styles.lstore}>
            <View style={[styles.ldot, { backgroundColor: color }]} />
            <Text style={[styles.lstoreText, { color }]}>{item.store === 'coles' ? 'Coles' : 'Woolworths'}</Text>
          </View>
        </View>
        <View style={styles.lright}>
          <Text style={[styles.lprice, { color }]}>${((item.price || 0) * qty).toFixed(2)}</Text>
          <View style={styles.qtyRow}>
            <TouchableOpacity style={styles.qtyBtn} onPress={() => onQtyChange(-1)} hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}>
              <Text style={styles.qtyBtnText}>−</Text>
            </TouchableOpacity>
            <Text style={styles.qtyNum}>{qty}</Text>
            <TouchableOpacity style={styles.qtyBtn} onPress={() => onQtyChange(1)} hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}>
              <Text style={styles.qtyBtnText}>+</Text>
            </TouchableOpacity>
          </View>
          {item.ticked && <Text style={styles.lcheck}>✓</Text>}
        </View>
      </View>
    </TouchableOpacity>
  );
}

// ── History card ─────────────────────────────────────────────────────────────
function HistCard({ entry, onDelete }) {
  const [open, setOpen] = useState(false);
  const colesTotal = entry.coles ? entry.coles.total : 0;
  const wowTotal   = entry.woolworths ? entry.woolworths.total : 0;
  const grand      = colesTotal + wowTotal;
  const colesItems = entry.coles && entry.coles.items ? entry.coles.items.length : 0;
  const wowItems   = entry.woolworths && entry.woolworths.items ? entry.woolworths.items.length : 0;

  function renderItems(storeData, store) {
    if (!storeData || !storeData.items || !storeData.items.length) return null;
    const color = store === 'coles' ? C.red : C.green;
    const label = store === 'coles' ? '🔴 Coles' : '🟢 Woolworths';
    const checked = storeData.items.filter(i => i.checked).length;
    const skipped = storeData.items.length - checked;
    return (
      <View>
        <Text style={[styles.histStoreHead, { color }]}>
          {label} · ${storeData.total.toFixed(2)} · {checked} found{skipped ? `, ${skipped} skipped` : ''}
        </Text>
        {storeData.items.map((item, i) => (
          <View key={i} style={styles.histItem}>
            <Text style={[styles.histItemName, !item.checked && styles.histItemSkipped]} numberOfLines={1}>
              {!item.checked ? '✗ ' : ''}{item.name}{item.qty > 1 ? ` ×${item.qty}` : ''}
            </Text>
            <Text style={styles.histItemPrice}>${((item.price || 0) * (item.qty || 1)).toFixed(2)}</Text>
          </View>
        ))}
      </View>
    );
  }

  return (
    <SwipeableRow onDelete={onDelete} containerStyle={{ marginBottom: 10, borderRadius: 12 }}>
      <View style={styles.histCard}>
        <TouchableOpacity onPress={() => setOpen(!open)} activeOpacity={0.8}>
          <View style={styles.histHead}>
            <View style={{ flex: 1 }}>
              <Text style={styles.histDate}>{dateStr(entry.date)}</Text>
              <Text style={styles.histMeta}>
                {colesItems ? `Coles ${colesItems} items` : ''}
                {colesItems && wowItems ? ' · ' : ''}
                {wowItems ? `Woolies ${wowItems} items` : ''}
              </Text>
            </View>
            <Text style={styles.histTotal}>${grand.toFixed(2)}</Text>
            <Text style={[styles.histToggle, open && { transform: [{ rotate: '180deg' }] }]}>▾</Text>
          </View>
        </TouchableOpacity>
        {open && (
          <View style={styles.histBody}>
            {renderItems(entry.coles, 'coles')}
            {renderItems(entry.woolworths, 'woolworths')}
          </View>
        )}
      </View>
    </SwipeableRow>
  );
}

// ── Main CartScreen ───────────────────────────────────────────────────────────
export default function CartScreen() {
  const [cart, setCart]       = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab]         = useState('cart');
  const [toast, setToast]     = useState('');
  const toastTimer            = useRef(null);
  const syncDebounceRef       = useRef({}); // key: item idx, value: timeout id


  function showToast(msg) {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 2500);
  }

  useFocusEffect(useCallback(() => {
    init();
  }, []));

  async function init() {
    setLoading(true);
    try {
      let c = await loadCart();
      if (c && c.createdAt && Date.now() - c.createdAt > THREE_DAYS) {
        await archiveCart(c, true);
        c = null;
      }
      setCart(c);
      const h = await getHistory();
      setHistory(Array.isArray(h) ? h : []);
    } catch (e) {
      setCart(null);
      setHistory([]);
    }
    setLoading(false);
  }

  async function archiveCart(cartData, silent = false) {
    if (!cartData || !cartData.items || !cartData.items.length) return;
    const colesItems = cartData.items.filter(i => i.store === 'coles');
    const wowItems   = cartData.items.filter(i => i.store === 'woolworths');
    const entry = {
      id:   Date.now(),
      date: new Date().toISOString(),
      autoArchived: silent,
      coles: colesItems.length ? {
        total: totalFor(colesItems),
        items: colesItems.map(i => ({ name: i.name, price: i.price, qty: i.qty || 1, unit: i.unit || null, checked: !!i.ticked })),
      } : null,
      woolworths: wowItems.length ? {
        total: totalFor(wowItems),
        items: wowItems.map(i => ({ name: i.name, price: i.price, qty: i.qty || 1, unit: i.unit || null, checked: !!i.ticked })),
      } : null,
    };
    try { await addHistoryEntry(entry); } catch {}
    await clearCart();
  }

  async function tickItem(idx) {
    if (!cart) return;
    const items = cart.items.map((item, i) => i === idx ? { ...item, ticked: !item.ticked } : item);
    const updated = { ...cart, items };
    setCart(updated);
    await persistCart(updated);
  }

  async function removeItem(idx) {
    if (!cart) return;
    const removed = cart.items[idx];
    const items = cart.items.filter((_, i) => i !== idx);
    if (!items.length) {
      setCart(null);
      await clearCart();
    } else {
      const updated = { ...cart, items };
      setCart(updated);
      await persistCart(updated);
    }
    // Sync remove to store in background (qty=0)
    if (removed) syncItemToStore(removed, 0).then(r => {
      if (r) { const s = r.store === 'woolworths' ? 'Woolworths' : 'Coles'; showToast(r.ok ? `✓ Removed from ${s} cart` : `⚠️ ${s} cart sync failed`); }
    });
  }

  async function changeQty(idx, delta) {
    if (!cart) return;
    const item = cart.items[idx];
    const newQty = Math.max(1, (item.qty || 1) + delta);
    const items = cart.items.map((it, i) => i === idx ? { ...it, qty: newQty } : it);
    const updated = { ...cart, items };
    setCart(updated);
    await persistCart(updated);

    // Debounce: cancel any pending sync for this item, wait 800ms after last tap.
    // Track the qty BEFORE this burst started so we can compute the true net delta.
    if (syncDebounceRef.current[idx]) clearTimeout(syncDebounceRef.current[idx]);
    syncDebounceRef.current[idx] = setTimeout(async () => {
      delete syncDebounceRef.current[idx];
      // Read latest qty from storage so we always send the true final value
      const latestCart = await loadCart();
      const latestItem = latestCart && latestCart.items && latestCart.items[idx];
      if (!latestItem) return;
      const finalQty = latestItem.qty || 1;
      const r = await syncItemToStore(latestItem, finalQty);
      if (r) { const s = r.store === 'woolworths' ? 'Woolworths' : 'Coles'; showToast(r.ok ? `✓ ${s} cart updated` : `⚠️ ${s} cart sync failed`); }
    }, 800);
  }

  async function handleDeleteHistory(entry) {
    Alert.alert('Delete this shop?', dateStr(entry.date), [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        try {
          await deleteHistoryEntry(entry.id);
          setHistory(prev => prev.filter(e => e.id !== entry.id));
        } catch (e) {
          Alert.alert('Error', 'Could not delete: ' + e.message);
        }
      }},
    ]);
  }

  async function finishShop() {
    if (!cart || !cart.items.length) return;
    const total = totalFor(cart.items);
    const ticked = cart.items.filter(i => i.ticked).length;
    Alert.alert(
      '🛒 Finish shop?',
      `${ticked}/${cart.items.length} items checked off\nTotal: $${total.toFixed(2)}\n\nSave to history and clear cart?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Finish & Save', onPress: async () => {
          const itemsToRemove = [...cart.items];
          await archiveCart(cart);
          setCart(null);
          const h = await getHistory();
          setHistory(Array.isArray(h) ? h : []);
          setTab('history');
          // Sync all removes to stores in background
          syncAllRemovedToStore(itemsToRemove);
        }},
      ]
    );
  }

  async function clearCartNow() {
    Alert.alert('Clear cart?', 'This will remove all items without saving.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear', style: 'destructive', onPress: async () => {
        const itemsToRemove = cart ? [...cart.items] : [];
        setCart(null);
        await clearCart();
        // Sync all removes to stores in background
        syncAllRemovedToStore(itemsToRemove);
      }},
    ]);
  }

  const colesItems  = cart ? cart.items.filter(i => i.store === 'coles')      : [];
  const wowItems    = cart ? cart.items.filter(i => i.store === 'woolworths') : [];
  const colesTot    = totalFor(colesItems);
  const wowTot      = totalFor(wowItems);
  const grandTot    = colesTot + wowTot;
  const tickedCount = cart ? cart.items.filter(i => i.ticked).length : 0;
  const totalCount  = cart ? cart.items.length : 0;

  if (loading) {
    return <View style={styles.centered}><ActivityIndicator size="large" color={C.gold} /></View>;
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.pageTitle}>🛒 Cart</Text>
        <View style={styles.tabs}>
          <TouchableOpacity style={[styles.tabBtn, tab === 'cart' && styles.tabBtnActive]} onPress={() => setTab('cart')}>
            <Text style={[styles.tabText, tab === 'cart' && styles.tabTextActive]}>Current</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.tabBtn, tab === 'history' && styles.tabBtnActive]} onPress={() => setTab('history')}>
            <Text style={[styles.tabText, tab === 'history' && styles.tabTextActive]}>History</Text>
          </TouchableOpacity>
        </View>
      </View>

      {tab === 'cart' && (
        <View style={{ flex: 1 }}>
          {!cart || !cart.items.length ? (
            <View style={styles.empty}>
              <Text style={styles.emptyIco}>🛒</Text>
              <Text style={styles.emptyTitle}>Cart is empty</Text>
              <Text style={styles.emptySub}>Add items from your battles, then tap "Add to Cart"</Text>
            </View>
          ) : (
            <>
              <View style={styles.totals}>
                {colesItems.length > 0 && (
                  <View style={styles.totCard}>
                    <View style={[styles.totDot, { backgroundColor: C.red }]} />
                    <View>
                      <Text style={styles.totStore}>Coles</Text>
                      <Text style={[styles.totAmt, { color: C.red }]}>${colesTot.toFixed(2)}</Text>
                    </View>
                  </View>
                )}
                {wowItems.length > 0 && (
                  <View style={styles.totCard}>
                    <View style={[styles.totDot, { backgroundColor: C.green }]} />
                    <View>
                      <Text style={styles.totStore}>Woolworths</Text>
                      <Text style={[styles.totAmt, { color: C.green }]}>${wowTot.toFixed(2)}</Text>
                    </View>
                  </View>
                )}
                <View style={styles.totCard}>
                  <Text style={styles.totGrandLabel}>Total</Text>
                  <Text style={styles.totGrand}>${grandTot.toFixed(2)}</Text>
                </View>
              </View>

              <View style={styles.progress}>
                <View style={styles.progressBar}>
                  <View style={[styles.progressFill, { width: totalCount ? `${(tickedCount / totalCount) * 100}%` : '0%' }]} />
                </View>
                <Text style={styles.progressText}>{tickedCount}/{totalCount} checked off</Text>
              </View>

              <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 10, paddingBottom: 20 }}>
                {colesItems.length > 0 && (
                  <Text style={[styles.sectionHead, { color: C.red }]}>🔴 Coles</Text>
                )}
                {colesItems.map((item) => {
                  const idx = cart.items.indexOf(item);
                  return (
                    <SwipeableRow key={idx} onDelete={() => removeItem(idx)} containerStyle={{ marginBottom: 7, borderRadius: 10 }}>
                      <CartItem item={item} onTick={() => tickItem(idx)} onQtyChange={(d) => changeQty(idx, d)} />
                    </SwipeableRow>
                  );
                })}

                {wowItems.length > 0 && (
                  <Text style={[styles.sectionHead, { color: C.green, marginTop: 10 }]}>🟢 Woolworths</Text>
                )}
                {wowItems.map((item) => {
                  const idx = cart.items.indexOf(item);
                  return (
                    <SwipeableRow key={idx} onDelete={() => removeItem(idx)} containerStyle={{ marginBottom: 7, borderRadius: 10 }}>
                      <CartItem item={item} onTick={() => tickItem(idx)} onQtyChange={(d) => changeQty(idx, d)} />
                    </SwipeableRow>
                  );
                })}
              </ScrollView>

              <View style={styles.actions}>
                <TouchableOpacity style={styles.finishBtn} onPress={finishShop}>
                  <Text style={styles.finishBtnText}>✅ Finish Shop</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.clearBtn} onPress={clearCartNow}>
                  <Text style={styles.clearBtnText}>Clear</Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </View>
      )}

      {tab === 'history' && (
        <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 12, paddingBottom: 40 }}>
          {history.length === 0 ? (
            <View style={styles.empty}>
              <Text style={styles.emptyIco}>🧾</Text>
              <Text style={styles.emptyTitle}>No history yet</Text>
              <Text style={styles.emptySub}>Complete a shop to save it here</Text>
            </View>
          ) : (
            history.map((entry, i) => (
              <HistCard key={entry.id || i} entry={entry} onDelete={() => handleDeleteHistory(entry)} />
            ))
          )}
        </ScrollView>
      )}
      {!!toast && (
        <View style={styles.toast} pointerEvents="none">
          <Text style={styles.toastText}>{toast}</Text>
        </View>
      )}
    </View>
  );
}

// ── Exported helper: add items to cart (called from BattlesScreen) ────────────
// Calculate the correct price for a given qty considering multibuy deals
export function calcItemPrice(item, qty) {
  if (!item.multiBuy || !qty) return (item.price || 0) * (qty || 1);
  const { qty: dealQty, price: dealPrice, priceEa } = item.multiBuy;
  const fullDeals   = Math.floor(qty / dealQty);
  const remainder   = qty % dealQty;
  return (fullDeals * dealPrice) + (remainder * (item.price || 0));
}

// Prompt user about multibuy deal then add to cart.
// Respects the Automatic Multibuys setting:
//   'off'  = show Alert prompt every time
//   'add'  = silently upgrade to multibuy qty
//   'skip' = silently add single qty, ignore deal
export async function addItemsToCartWithMultibuyPrompt(items, onDone) {
  const multiItems = items.filter(i => i.multiBuy && (i.qty || 1) < i.multiBuy.qty);
  if (!multiItems.length) {
    addItemsToCart(items).then(onDone || (() => {}));
    return;
  }

  const mode = await getMultibuyMode();

  if (mode === 'add') {
    const upgraded = items.map(i =>
      i.multiBuy && (i.qty || 1) < i.multiBuy.qty ? { ...i, qty: i.multiBuy.qty } : i
    );
    addItemsToCart(upgraded).then(onDone || (() => {}));
    return;
  }

  if (mode === 'skip') {
    addItemsToCart(items).then(onDone || (() => {}));
    return;
  }

  // mode === 'off' — show prompt
  const item = multiItems[0];
  const mb = item.multiBuy;
  const saving = ((item.price || 0) - mb.priceEa).toFixed(2);
  const { Alert: RNAlert } = require('react-native');
  RNAlert.alert(
    `${mb.qty} for $${mb.price.toFixed(2)} deal`,
    `Buy ${mb.qty} and save $${saving} each ($${mb.priceEa.toFixed(2)} ea vs $${(item.price||0).toFixed(2)} ea).\n\nAdd ${mb.qty} instead of ${item.qty || 1}?`,
    [
      {
        text: `Add ${mb.qty}`,
        onPress: () => {
          const upgraded = items.map(i =>
            i.id === item.id && i.store === item.store ? { ...i, qty: mb.qty } : i
          );
          addItemsToCart(upgraded).then(onDone || (() => {}));
        },
      },
      {
        text: `Add ${item.qty || 1}`,
        style: 'cancel',
        onPress: () => addItemsToCart(items).then(onDone || (() => {})),
      },
    ]
  );
}

export async function addItemsToCart(items) {
  try {
    let cart = await loadCart();
    if (cart && cart.createdAt && Date.now() - cart.createdAt > THREE_DAYS) {
      const colesItems = cart.items.filter(i => i.store === 'coles');
      const wowItems   = cart.items.filter(i => i.store === 'woolworths');
      const entry = {
        id: Date.now(), date: new Date().toISOString(), autoArchived: true,
        coles: colesItems.length ? { total: totalFor(colesItems), items: colesItems.map(i => ({ name: i.name, price: i.price, qty: i.qty||1, unit: i.unit||null, checked: !!i.ticked })) } : null,
        woolworths: wowItems.length ? { total: totalFor(wowItems), items: wowItems.map(i => ({ name: i.name, price: i.price, qty: i.qty||1, unit: i.unit||null, checked: !!i.ticked })) } : null,
      };
      try { await addHistoryEntry(entry); } catch {}
      cart = null;
    }

    if (!cart) cart = { createdAt: Date.now(), items: [] };

    const storeItems = [];
    for (const item of items) {
      const existsIdx = cart.items.findIndex(i => i.id === item.id && i.store === item.store);
      if (existsIdx >= 0) {
        const deltaQty = item.qty || 1;
        cart.items[existsIdx] = {
          ...cart.items[existsIdx],
          qty: (cart.items[existsIdx].qty || 1) + deltaQty,
        };
        storeItems.push({ ...item, qty: deltaQty });
      } else {
        cart.items.push({ ...item, ticked: false, addedAt: Date.now() });
        storeItems.push(item);
      }
    }
    await persistCart(cart);

    const syncEnabled = await getSyncCartToStores();
    const storeResults = { coles: null, woolworths: null };

    if (syncEnabled && storeItems.length > 0) {
      const colesNew = storeItems.filter(i => i.store === 'coles');
      const wowNew   = storeItems.filter(i => i.store === 'woolworths');
      if (colesNew.length > 0 && await isLoggedIn('coles')) {
        try { storeResults.coles = await addToColesCart(colesNew); }
        catch (e) { storeResults.coles = [{ ok: false, error: e.message }]; }
      }
      if (wowNew.length > 0 && await isLoggedIn('woolworths')) {
        try { storeResults.woolworths = await addToWoolworthsCart(wowNew); }
        catch (e) { storeResults.woolworths = [{ ok: false, error: e.message }]; }
      }
    }

    return { appOk: true, syncEnabled, storeResults };
  } catch (e) {
    console.warn('[Cart] addItemsToCart error:', e.message);
    return { appOk: false };
  }
}

const styles = StyleSheet.create({
  toast:     { position: 'absolute', bottom: 28, left: 24, right: 24, backgroundColor: '#1e2230', borderWidth: 1.5, borderColor: C.gold, borderRadius: 14, paddingVertical: 11, paddingHorizontal: 18, alignItems: 'center', shadowColor: '#000', shadowOpacity: 0.4, shadowRadius: 8, elevation: 10 },
  toastText: { color: C.gold, fontSize: 14, fontWeight: '600' },
  container: { flex: 1, backgroundColor: C.bg },
  centered:  { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.bg },

  header:    { paddingTop: 52, paddingHorizontal: 16, paddingBottom: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  pageTitle: { fontSize: 22, fontWeight: '800', color: C.text },
  tabs:      { flexDirection: 'row', backgroundColor: C.card2, borderRadius: 10, padding: 3, borderWidth: 1, borderColor: C.border },
  tabBtn:    { paddingHorizontal: 14, paddingVertical: 5, borderRadius: 8 },
  tabBtnActive: { backgroundColor: C.gold },
  tabText:   { color: C.muted, fontWeight: '600', fontSize: 13 },
  tabTextActive: { color: '#1a1100' },

  empty:      { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 40, marginTop: 60 },
  emptyIco:   { fontSize: 40, marginBottom: 12 },
  emptyTitle: { color: C.text, fontSize: 16, fontWeight: '700', marginBottom: 6 },
  emptySub:   { color: C.muted, fontSize: 13, textAlign: 'center', lineHeight: 19 },

  totals:   { flexDirection: 'row', gap: 8, padding: 12, paddingBottom: 6 },
  totCard:  { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 10, padding: 8 },
  totDot:   { width: 8, height: 8, borderRadius: 4 },
  totStore: { fontSize: 10, color: C.muted },
  totAmt:   { fontWeight: '800', fontSize: 15 },
  totGrandLabel: { fontSize: 10, color: C.muted },
  totGrand: { fontWeight: '800', fontSize: 15, color: C.gold },

  progress:     { paddingHorizontal: 12, marginBottom: 6 },
  progressBar:  { height: 5, backgroundColor: C.card2, borderRadius: 3, overflow: 'hidden', marginBottom: 3 },
  progressFill: { height: '100%', backgroundColor: C.gold, borderRadius: 3 },
  progressText: { color: C.muted, fontSize: 11 },

  sectionHead: { fontWeight: '700', fontSize: 12, marginBottom: 6, marginTop: 2 },

  li:        { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 9, backgroundColor: C.card, borderWidth: 1.5, borderColor: C.border, borderRadius: 10 },
  liTicked:      { borderColor: C.green },
  liInner:       { flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 },
  liInnerTicked: { opacity: 0.4 },
  limg:      { width: 42, height: 42, borderRadius: 7, backgroundColor: '#22253a' },
  limgPh:    { width: 42, height: 42, borderRadius: 7, backgroundColor: '#22253a', alignItems: 'center', justifyContent: 'center' },
  lib:       { flex: 1, minWidth: 0 },
  lin:       { fontSize: 13, fontWeight: '500', color: C.text, lineHeight: 17 },
  linTicked: { textDecorationLine: 'line-through', color: C.muted },
  liu:       { fontSize: 11, color: C.muted, marginTop: 1 },
  lstore:    { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3 },
  ldot:      { width: 5, height: 5, borderRadius: 3 },
  lstoreText:{ fontSize: 10, fontWeight: '600' },
  lright:    { alignItems: 'flex-end', gap: 3 },
  lprice:    { fontWeight: '700', fontSize: 15 },
  lcheck:    { color: C.green, fontSize: 13, fontWeight: '700' },
  qtyRow:    { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 2 },
  qtyBtn:    { width: 24, height: 24, borderRadius: 6, backgroundColor: C.card2, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  qtyBtnText:{ color: C.text, fontSize: 15, fontWeight: '700', lineHeight: 20 },
  qtyNum:    { color: C.text, fontSize: 13, fontWeight: '700', minWidth: 18, textAlign: 'center' },

  actions:      { flexDirection: 'row', gap: 8, padding: 12, paddingBottom: 16, borderTopWidth: 1, borderTopColor: C.border },
  finishBtn:    { flex: 1, backgroundColor: C.green, borderRadius: 12, padding: 13, alignItems: 'center' },
  finishBtnText:{ color: '#fff', fontWeight: '700', fontSize: 15 },
  clearBtn:     { borderWidth: 1.5, borderColor: C.border, borderRadius: 12, paddingHorizontal: 16, justifyContent: 'center' },
  clearBtnText: { color: C.muted, fontSize: 13 },

  histCard:       { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 12, overflow: 'hidden' },
  histHead:       { flexDirection: 'row', alignItems: 'center', padding: 12 },
  histDate:       { color: C.text, fontWeight: '600', fontSize: 13 },
  histMeta:       { color: C.muted, fontSize: 11, marginTop: 2 },
  histTotal:      { color: C.gold, fontWeight: '800', fontSize: 18, marginRight: 6 },
  histToggle:     { color: C.muted, fontSize: 14 },
  histBody:       { borderTopWidth: 1, borderTopColor: C.border, padding: 12 },
  histStoreHead:  { fontWeight: '700', fontSize: 12, marginBottom: 6 },
  histItem:       { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 3 },
  histItemName:   { color: C.sub, fontSize: 12, flex: 1, marginRight: 8 },
  histItemSkipped:{ color: C.muted, textDecorationLine: 'line-through' },
  histItemPrice:  { color: C.text, fontSize: 12, fontWeight: '600' },
});
