// screens/SettingsScreen.js
import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Share, Alert, ScrollView } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { isLoggedIn, clearCookies, STORES } from '../services/storeAuth';
import { generateInvite, clearCredentials, SERVER_URL } from '../services/api';

export default function SettingsScreen({ navigation, onLeave }) {
  const [authStatus, setAuthStatus] = useState({ woolworths: false, coles: false });

  useFocusEffect(useCallback(() => {
    (async () => {
      const [w, c] = await Promise.all([isLoggedIn('woolworths'), isLoggedIn('coles')]);
      setAuthStatus({ woolworths: w, coles: c });
    })();
  }, []));

  async function handleSignIn(store) {
    navigation.navigate('LoginWebView', { store });
  }

  async function handleSignOut(store) {
    Alert.alert(`Sign out of ${STORES[store].name}?`, '', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign Out', style: 'destructive', onPress: async () => {
          await clearCookies(store);
          setAuthStatus(s => ({ ...s, [store]: false }));
        },
      },
    ]);
  }

  async function handleInvite() {
    try {
      const { token } = await generateInvite();
      await Share.share({
        message: `Join my BasketBattle household!\n\nTap this link: basketbattle://join/${token}\nOr enter token manually: ${token}\n\nThen enter the household PIN when asked.\n\nLink expires in 24 hours.`,
      });
    } catch (e) {
      Alert.alert('Error', 'Could not generate invite. Check your internet connection.');
    }
  }

  async function handleLeave() {
    Alert.alert('Leave Household?', 'You will need an invite to rejoin.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Leave', style: 'destructive', onPress: async () => {
          await clearCredentials();
          onLeave?.();
        },
      },
    ]);
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.sectionTitle}>Store Accounts</Text>
      <Text style={styles.sectionSubtitle}>Sign in so the app can fetch personalised specials and add items to your cart.</Text>

      {Object.entries(STORES).map(([key, info]) => (
        <View key={key} style={styles.storeCard}>
          <View style={styles.storeLeft}>
            <Text style={styles.storeEmoji}>{info.emoji}</Text>
            <View>
              <Text style={styles.storeName}>{info.name}</Text>
              <Text style={[styles.storeStatus, authStatus[key] && styles.storeStatusOn]}>
                {authStatus[key] ? '● Signed in' : '○ Not signed in'}
              </Text>
            </View>
          </View>
          <TouchableOpacity
            style={[styles.authBtn, authStatus[key] && styles.authBtnOut]}
            onPress={() => authStatus[key] ? handleSignOut(key) : handleSignIn(key)}
          >
            <Text style={[styles.authBtnText, authStatus[key] && styles.authBtnTextOut]}>
              {authStatus[key] ? 'Sign out' : 'Sign in'}
            </Text>
          </TouchableOpacity>
        </View>
      ))}

      <Text style={styles.sectionTitle} style={{ marginTop: 32 }}>Household</Text>

      <TouchableOpacity style={styles.actionBtn} onPress={handleInvite}>
        <Text style={styles.actionBtnText}>👥  Invite Someone</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.actionBtn, styles.dangerBtn]} onPress={handleLeave}>
        <Text style={[styles.actionBtnText, styles.dangerText]}>🚪  Leave Household</Text>
      </TouchableOpacity>

      <Text style={styles.serverNote}>Server: {SERVER_URL}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  content: { padding: 20, paddingTop: 60 },
  sectionTitle: { fontSize: 18, fontWeight: '700', color: '#1a1a1a', marginBottom: 4, marginTop: 8 },
  sectionSubtitle: { fontSize: 13, color: '#888', marginBottom: 16, lineHeight: 18 },
  storeCard: { backgroundColor: '#fff', borderRadius: 14, padding: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 8, elevation: 2 },
  storeLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  storeEmoji: { fontSize: 28 },
  storeName: { fontWeight: '700', fontSize: 16, color: '#1a1a1a' },
  storeStatus: { fontSize: 12, color: '#aaa', marginTop: 2 },
  storeStatusOn: { color: '#2d6a4f' },
  authBtn: { backgroundColor: '#2d6a4f', borderRadius: 8, paddingHorizontal: 16, paddingVertical: 8 },
  authBtnOut: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#e0e0e0' },
  authBtnText: { color: '#fff', fontWeight: '600', fontSize: 14 },
  authBtnTextOut: { color: '#e01a22' },
  actionBtn: { backgroundColor: '#fff', borderRadius: 14, padding: 18, marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 8, elevation: 2 },
  dangerBtn: { borderWidth: 1, borderColor: '#ffe0e0', backgroundColor: '#fff5f5' },
  actionBtnText: { fontSize: 16, fontWeight: '600', color: '#1a1a1a' },
  dangerText: { color: '#e01a22' },
  serverNote: { fontSize: 11, color: '#ccc', textAlign: 'center', marginTop: 24 },
});
