import React, { useState, useEffect, useRef, useCallback } from 'react';
import * as NativeSplash from 'expo-splash-screen';

// Keep native splash visible until we're ready
NativeSplash.preventAutoHideAsync().catch(() => {});
import { View, Text, ActivityIndicator, Alert } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

import { loadCredentials, autoInitHousehold, setAccessCode } from './services/api';
import AccessScreen, { loadAccessToken } from './screens/AccessScreen';
import { loadCookies, isLoggedIn, getColesCartJob, clearColesCartJob, buildColesCartJS } from './services/storeAuth';
import { setColesBuildId } from './services/storeService';
import { WebView } from 'react-native-webview';
import SplashScreen      from './screens/SplashScreen';
import ShopScreen        from './screens/ShopScreen';
import BattlesScreen     from './screens/BattlesScreen';
import CartScreen        from './screens/CartScreen';
import AccountScreen     from './screens/AccountScreen';
import LoginWebViewScreen from './screens/LoginWebViewScreen';

const Tab   = createBottomTabNavigator();
const Stack = createStackNavigator();

function TabIcon({ emoji }) {
  return <Text style={{ fontSize: 20 }}>{emoji}</Text>;
}

function MainTabs() {
  return (
    <Tab.Navigator screenOptions={{
      headerShown: false,
      tabBarActiveTintColor: '#f59e0b',
      tabBarInactiveTintColor: '#6b7280',
      tabBarStyle: { backgroundColor: '#12151f', borderTopColor: '#2a2d3a', paddingBottom: 4 },
      tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
    }}>
      <Tab.Screen name="Shop"    component={ShopScreen}    options={{ tabBarLabel: 'Search',  tabBarIcon: () => <TabIcon emoji="🔍" /> }} />
      <Tab.Screen name="Battles" component={BattlesScreen} options={{ tabBarLabel: 'Battles', tabBarIcon: () => <TabIcon emoji="⚔️" /> }} />
      <Tab.Screen name="Cart"    component={CartScreen}    options={{ tabBarLabel: 'Cart',    tabBarIcon: () => <TabIcon emoji="🛒" /> }} />
      <Tab.Screen name="Account" component={AccountScreen} options={{ tabBarLabel: 'Account', tabBarIcon: () => <TabIcon emoji="👤" /> }} />
    </Tab.Navigator>
  );
}


// ── Persistent Coles WebView for cart adds ───────────────────────────────────
function ColesCartWebView() {
  const webviewRef = useRef(null);
  const jobActiveRef = useRef(false);
  const readyRef = useRef(false);
  const subKeyCapturedRef = useRef(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const job = getColesCartJob();
      if (!job || jobActiveRef.current) return;
      if (!readyRef.current) {
        Alert.alert('Coles Cart', 'WebView not ready yet — waiting...');
        return;
      }
      jobActiveRef.current = true;
      Alert.alert('Coles Cart', 'Injecting cart JS for ' + job.items.length + ' item(s), subKey=' + (subKeyCapturedRef.current ? 'YES' : 'NO'));
      const js = buildColesCartJS(job.items, subKeyCapturedRef.current);
      const injected = webviewRef.current?.injectJavaScript(js);
      console.log('[ColesCart] injectJavaScript called, ref exists:', !!webviewRef.current);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const onLoad = useCallback(() => {
    readyRef.current = true;
    Alert.alert('Coles Cart WebView', 'WebView loaded coles.com.au/cart ✓');
    console.log('[ColesWebView] Loaded and ready');
  }, []);

  const onError = useCallback((e) => {
    Alert.alert('Coles WebView Error', e.nativeEvent?.description || 'Unknown error');
    console.warn('[ColesWebView] Error:', e.nativeEvent);
  }, []);

  const onMessage = useCallback((event) => {
    try {
      const msg = JSON.parse(event.nativeEvent.data);
      if (msg.type === 'colesSubKey') {
        console.log('[ColesCart] Captured sub key:', msg.key.slice(0,8) + '...');
        subKeyCapturedRef.current = msg.key;
      }
      if (msg.type === 'colesCartDebug') {
        console.log('[ColesCart]', msg.msg);
        Alert.alert('Coles Cart', msg.msg);
      }
      if (msg.type === 'colesBuildId') {
        console.log('[ColesCart] captured buildId:', msg.buildId.slice(0, 20) + '...');
        setColesBuildId(msg.buildId);
      }
      if (msg.type === 'colesCartDone') {
        const job = getColesCartJob();
        clearColesCartJob();
        jobActiveRef.current = false;
        if (job) job.resolve(msg.results);
      }
    } catch(e) {}
  }, []);

  // Injected before page loads — intercepts fetch to steal the subscription key
  const INTERCEPT_JS = `
(function() {
  var _capturedSubKey = null;
  var _origFetch = window.fetch;
  window.fetch = function(url, opts) {
    if (!_capturedSubKey && opts && opts.headers) {
      var h = opts.headers;
      var key = (typeof h.get === 'function' ? h.get('Ocp-Apim-Subscription-Key') : null)
             || h['Ocp-Apim-Subscription-Key']
             || h['ocp-apim-subscription-key'];
      if (key && key.length === 32) {
        _capturedSubKey = key;
        window._colesSubKey = key;
        window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({
          type: 'colesSubKey', key: key
        }));
      }
    }
    return _origFetch.apply(this, arguments);
  };
  // Also intercept XMLHttpRequest
  var _origOpen = XMLHttpRequest.prototype.open;
  var _origSetHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
    if (name && name.toLowerCase() === 'ocp-apim-subscription-key' && value && value.length === 32) {
      if (!_capturedSubKey) {
        _capturedSubKey = value;
        window._colesSubKey = value;
        window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({
          type: 'colesSubKey', key: value
        }));
      }
    }
    return _origSetHeader.apply(this, arguments);
  };
  // Extract buildId from __NEXT_DATA__ once DOM is ready
  document.addEventListener('DOMContentLoaded', function() {
    try {
      var el = document.getElementById('__NEXT_DATA__');
      if (el) {
        var data = JSON.parse(el.innerText);
        if (data && data.buildId) {
          window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({
            type: 'colesBuildId', buildId: data.buildId
          }));
        }
      }
    } catch(e) {}
  });
})();
true;
  `;

  return (
    <View style={{ position: 'absolute', top: -100, left: -100, width: 1, height: 1, overflow: 'hidden' }}>
      <WebView
        ref={webviewRef}
        source={{ uri: 'https://www.coles.com.au/cart' }}
        style={{ width: 1, height: 1 }}
        onLoad={onLoad}
        onError={onError}
        onMessage={onMessage}
        injectedJavaScriptBeforeContentLoaded={INTERCEPT_JS}
        sharedCookiesEnabled={true}
        thirdPartyCookiesEnabled={true}
        domStorageEnabled={true}
        javaScriptEnabled={true}
        userAgent="Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        cacheEnabled={false}
      />
    </View>
  );
}

export default function App() {
  const [phase, setPhase] = useState('splash'); // 'splash' | 'gate' | 'init' | 'ready'

  // When splash signals server is up, check access code first
  async function handleSplashDone() {
    const savedToken = await loadAccessToken();
    if (!savedToken) {
      setPhase('gate');
      return;
    }
    setAccessCode(savedToken);
    await doInit();
  }

  async function handleAccessGranted(code) {
    setAccessCode(code);
    await doInit();
  }

  async function doInit() {
    setPhase('init');
    try {
      await loadCredentials();
      await autoInitHousehold();
      await syncCookiesToServer();
    } catch (e) {
      console.warn('Init error:', e.message);
    }
    setPhase('ready');
  }

  async function syncCookiesToServer() {
    try {
      const SERVER_URL = 'https://basketbattle-server.onrender.com';
      const [colesCookies, wowCookies] = await Promise.all([
        loadCookies('coles'),
        loadCookies('woolworths'),
      ]);
      if (!colesCookies && !wowCookies) return;
      await fetch(SERVER_URL + '/auth/set-cookies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          coles:      colesCookies ? { cookies: colesCookies, loggedIn: true } : null,
          woolworths: wowCookies   ? { cookies: wowCookies,   loggedIn: true } : null,
        }),
      });
      console.log('[App] Synced stored cookies to server');
    } catch (e) {
      console.warn('[App] Could not sync cookies to server:', e.message);
    }
  }

  if (phase === 'splash') {
    // Hide the native splash now that JS is running
    NativeSplash.hideAsync().catch(() => {});
    return <SplashScreen onReady={handleSplashDone} />;
  }

  if (phase === 'gate') {
    NativeSplash.hideAsync().catch(() => {});
    return <AccessScreen onSuccess={handleAccessGranted} />;
  }

  if (phase === 'init') {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#0f1117' }}>
        <ActivityIndicator size="large" color="#f59e0b" />
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <ColesCartWebView />
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Main" component={MainTabs} />
          <Stack.Screen name="LoginWebView" component={LoginWebViewScreen} options={{ presentation: 'modal' }} />
        </Stack.Navigator>
      </NavigationContainer>
    </GestureHandlerRootView>
  );
}
