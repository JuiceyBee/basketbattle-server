// services/storeService.js
//
// COLES:      Proxied through our Render server (server fetches buildId + makes requests).
//             The device hits coles.com.au directly and gets Akamai-blocked.
// WOOLWORTHS: Called directly from the device — Woolworths doesn't block mobile IPs.

const { getCookieString } = require('./storeAuth');
const WOW_BASE   = 'https://www.woolworths.com.au';

const BASE_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1',
  'Accept-Language': 'en-AU,en;q=0.9',
  'Accept': 'application/json',
};

// ── Coles — direct from device, buildId scraped fresh from Coles homepage ────
const COLES_BASE = 'https://www.coles.com.au';
const COLES_HEADERS = {
  'Accept': 'application/json, text/plain, */*',
  'Accept-Language': 'en-AU,en;q=0.9',
  'User-Agent': 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'sec-fetch-site': 'same-origin',
  'sec-fetch-mode': 'cors',
  'sec-fetch-dest': 'empty',
};

const _colesBuild = { id: '', fetched: 0 };
// WebView-based buildId extraction — call this from a component that can render a hidden WebView
// Usage: import { extractBuildIdFromWebView } from './storeService';
// Then render: <WebViewBuildIdExtractor onSuccess={id => setColesBuildId(id)} />
export function setColesBuildId(id) {
  if (id && id !== _colesBuild.id) {
    console.log('[Coles] buildId set from WebView:', id.slice(0, 20) + '...');
    _colesBuild.id = id;
  }
}

async function getColesBuildId() {
  if (_colesBuild.id) {
    return _colesBuild.id; // cached until a 404 clears it
  }
  console.log('[Coles] fetching fresh buildId...');

  // Step 1: get the HTML page to find the webpack chunk URL
  const htmlHeaders = {
    'Accept': 'text/html,*/*',
    'Accept-Language': 'en-AU,en;q=0.9',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'sec-fetch-site': 'none',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-dest': 'document',
  };

  const pages = ['/browse/dairy-eggs-fridge', '/browse/pantry', '/on-special', '/'];
  for (var i = 0; i < pages.length; i++) {
    try {
      console.log('[Coles] HTML fetch:', pages[i]);
      const res = await fetch(COLES_BASE + pages[i], { headers: htmlHeaders });
      console.log('[Coles] HTML status:', res.status);
      if (!res.ok) continue;
      const html = await res.text();

      // Try direct buildId first
      const mb = html.match(/"buildId":"([^"]+)"/);
      if (mb) {
        _colesBuild.id = mb[1];
        console.log('[Coles] buildId direct:', _colesBuild.id.slice(0,20) + '...');
        return _colesBuild.id;
      }

      // Find webpack chunk URL in the HTML, then fetch that JS to get buildId
      const mw = html.match(/\/_next\/static\/chunks\/webpack-([a-f0-9]+)\.js/);
      if (mw) {
        const webpackUrl = COLES_BASE + '/_next/static/chunks/webpack-' + mw[1] + '.js';
        console.log('[Coles] fetching webpack chunk:', webpackUrl.slice(-30));
        const jsRes = await fetch(webpackUrl, {
          headers: {
            'Accept': '*/*',
            'User-Agent': htmlHeaders['User-Agent'],
            'Referer': COLES_BASE + '/',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'no-cors',
            'sec-fetch-dest': 'script',
          }
        });
        if (jsRes.ok) {
          const js = await jsRes.text();
          // buildId appears as a long date-prefixed string in webpack
          const mj = js.match(/"(20[0-9]{6}\.[0-9]+-[a-f0-9]{32,})"/);
          if (mj) {
            _colesBuild.id = mj[1];
            console.log('[Coles] buildId from webpack JS:', _colesBuild.id.slice(0,20) + '...');
            return _colesBuild.id;
          }
          console.log('[Coles] webpack JS len:', js.length, 'no buildId pattern found');
        }
      }

      // Also try _buildManifest reference in HTML
      const mm = html.match(/\/_next\/static\/([a-zA-Z0-9._-]+)\/_buildManifest/);
      if (mm) {
        _colesBuild.id = mm[1];
        console.log('[Coles] buildId from manifest ref:', _colesBuild.id.slice(0,20) + '...');
        return _colesBuild.id;
      }

      console.log('[Coles] no buildId found in', pages[i], 'html len:', html.length);
    } catch(e) {
      console.log('[Coles] error on', pages[i], ':', e.message);
    }
  }

  throw new Error('Could not get Coles buildId');
}

async function colesGet(path, referer) {
  // Fetch a Coles _next/data URL — auto-retries once with a fresh buildId on 404
  const buildId = await getColesBuildId();
  const url = COLES_BASE + '/_next/data/' + buildId + '/en/' + path;
  console.log('[Coles] GET:', path.split('?')[0]);
  const res = await fetch(url, { headers: { ...COLES_HEADERS, 'Referer': COLES_BASE + '/' + referer } });
  console.log('[Coles] status:', res.status);
  if (res.status === 404) {
    console.log('[Coles] stale buildId, fetching fresh and retrying...');
    _colesBuild.id = ''; // force getColesBuildId to re-scrape
    const freshBuildId = await getColesBuildId();
    const retryUrl = COLES_BASE + '/_next/data/' + freshBuildId + '/en/' + path;
    console.log('[Coles] retry with buildId:', freshBuildId.slice(0, 16) + '...');
    const retry = await fetch(retryUrl, { headers: { ...COLES_HEADERS, 'Referer': COLES_BASE + '/' + referer } });
    console.log('[Coles] retry status:', retry.status);
    if (!retry.ok) throw new Error('Coles HTTP ' + retry.status + ' after buildId refresh');
    return retry.json();
  }
  if (!res.ok) throw new Error('Coles HTTP ' + res.status);
  return res.json();
}

async function searchColes(query, page) {
  page = page || 1;
  const data = await colesGet(
    'search/products.json?q=' + encodeURIComponent(query) + '&page=' + page,
    'search/products?q=' + encodeURIComponent(query)
  );
  const results = extractColesProducts(data);
  console.log('[Coles] search results:', results.length);
  return results.map(p => parseColesProduct(p, false)).filter(p => !p.unavailable);
}

async function fetchColesSpecials(page) {
  page = page || 1;
  const data = await colesGet('on-special.json?page=' + page, 'on-special');
  // Log the top-level shape so we can see where products live
  const topKeys = Object.keys(data || {});
  console.log('[Coles] specials top keys:', topKeys.join(','));
  if (data && data.pageProps) {
    const ppKeys = Object.keys(data.pageProps);
    console.log('[Coles] specials pageProps keys:', ppKeys.join(','));
    // Log deeper for any key that might be an array
    for (const k of ppKeys) {
      const v = data.pageProps[k];
      if (Array.isArray(v)) console.log('[Coles] pageProps.' + k + ' is array len=' + v.length);
      else if (v && typeof v === 'object') console.log('[Coles] pageProps.' + k + ' is object, keys=' + Object.keys(v).join(','));
    }
  }
  const results = extractColesProducts(data);
  console.log('[Coles] specials results:', results.length);
  return results.map(p => parseColesProduct(p, true)).filter(p => !p.unavailable);
}

function extractColesProducts(data) {
  // _next/data response shape: { pageProps: { searchResults: { results: [...] } } }
  try {
    return data.pageProps.searchResults.results || [];
  } catch(e) {}
  try {
    return data.pageProps.results || [];
  } catch(e) {}
  // fallback — try any key that looks like an array of products
  if (data && data.results) return data.results;
  return [];
}

function parseColesProduct(p, forceSpecial) {
  const price  = p.pricing ? (p.pricing.now || 0) : (p.price || 0);
  const rawWas = p.pricing ? p.pricing.was : null;
  // Build image URL from product id — Coles CDN pattern:
  // https://cdn.productimages.coles.com.au/productimages/{first digit}/{id}.jpg
  let imgUrl = null;
  const pid = String(p.id || '');
  if (pid) {
    imgUrl = 'https://cdn.productimages.coles.com.au/productimages/' + pid[0] + '/' + pid + '.jpg';
  } else if (p.imageUris && p.imageUris[0]) {
    const uri = p.imageUris[0].uri || p.imageUris[0];
    imgUrl = uri.startsWith('http') ? uri : 'https://assets.coles.com.au' + uri;
  } else if (p.imageUrl) {
    imgUrl = p.imageUrl.startsWith('http') ? p.imageUrl : 'https://assets.coles.com.au' + p.imageUrl;
  }
  const multiBuy = p.pricing && p.pricing.multiBuyPromotion ? (() => {
    const qty    = p.pricing.multiBuyPromotion.minQuantity;
    const reward = p.pricing.multiBuyPromotion.reward;
    // reward is per-item price, so total = reward * qty
    return { qty, price: reward * qty, priceEa: reward };
  })() : null;
  return {
    id:          String(p.id),
    name:        p.name || '',
    brand:       p.brand || null,
    price,
    wasPrice:    (rawWas && rawWas > price) ? rawWas : null,
    isOnSpecial: forceSpecial || !!(p.pricing && (p.pricing.promotionType || p.pricing.was)),
    unitPrice:   p.pricing && p.pricing.comparable ? p.pricing.comparable : null,
    unit:        p.size || null,
    imgUrl,
    multiBuy,
    unavailable: !price || price <= 0,
    store:       'coles',
  };
}

// ── Woolworths — direct from device ──────────────────────────────────────────
const wowSession = { cookies: '', fetched: 0 };

async function getWowHeaders(referer) {
  if (Date.now() - wowSession.fetched > 5 * 60 * 1000) {
    try {
      const r = await fetch(WOW_BASE + '/', {
        headers: { ...BASE_HEADERS, Accept: 'text/html,*/*' },
      });
      const sc = r.headers.get('set-cookie') || '';
      if (sc) wowSession.cookies = sc.split(',').map(function(c) { return c.split(';')[0].trim(); }).join('; ');
    } catch {}
    wowSession.fetched = Date.now();
  }
  let authCookies = '';
  try { authCookies = (await getCookieString('woolworths')) || ''; } catch {}
  const merged = [authCookies, wowSession.cookies].filter(Boolean).join('; ');
  return {
    ...BASE_HEADERS,
    'Content-Type':   'application/json',
    Origin:           WOW_BASE,
    Referer:          referer || WOW_BASE + '/',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    ...(merged ? { Cookie: merged } : {}),
  };
}

// Parse Woolworths multibuy from Tags array e.g. "5 for $8.50 - $1.31/100G"
function parseWowMultiBuy(item) {
  // Try IncrementalMinimumQuantity first (some deals use this)
  if (item.IncrementalMinimumQuantity > 1 && item.IncrementalPrice) {
    const qty = item.IncrementalMinimumQuantity;
    const priceEa = item.IncrementalPrice;
    return { qty, price: priceEa * qty, priceEa };
  }
  // Try Tags array for "Buy More Save More" style deals
  // Tags[n].Content.Attributes.Text = "5 for $8.50 - $1.31/100G"
  const tags = item.Tags || [];
  for (var i = 0; i < tags.length; i++) {
    var text = tags[i] && tags[i].Content && tags[i].Content.Attributes && tags[i].Content.Attributes.Text;
    if (!text) continue;
    var m = text.match(/(\d+)\s+for\s+\$([0-9.]+)/i);
    if (m) {
      const qty   = parseInt(m[1], 10);
      const price = parseFloat(m[2]);
      return { qty, price, priceEa: price / qty };
    }
  }
  // Fallback: FooterTag MultibuyData
  if (item.FooterTag && item.FooterTag.MultibuyData) {
    const mb = item.FooterTag.MultibuyData;
    if (mb.Quantity && mb.Price) {
      return { qty: mb.Quantity, price: mb.Price, priceEa: mb.Price / mb.Quantity };
    }
  }
  return null;
}

function parseWoolworthsProduct(item) {
  let imgUrl = null;
  if (item.SmallImageFile) {
    imgUrl = item.SmallImageFile.replace('/small/', '/medium/').replace('http://', 'https://');
  }
  const price  = item.Price || 0;
  const rawWas = item.WasPrice || null;
  const isMarketplace = !!(
    item.IsMarketplaceProduct ||
    item.AdType === 'MARKETPLACE' ||
    (item.Vendor && item.Vendor !== 'Woolworths') ||
    (item.SoldBy && item.SoldBy !== 'Woolworths') ||
    item.IsEverydayMarket ||
    (item.UrlFriendlyName && item.UrlFriendlyName.includes('everyday-market'))
  );
  return {
    id:          String(item.Stockcode),
    name:        item.Name || item.DisplayName || '',
    brand:       item.Brand || null,
    price,
    wasPrice:    (rawWas && rawWas > price) ? rawWas : null,
    isOnSpecial: item.IsOnSpecial || false,
    unitPrice:   item.CupString  || null,
    unit:        item.PackageSize || null,
    imgUrl,
    stockcode:   item.Stockcode,
    multiBuy:    parseWowMultiBuy(item),
    unavailable: !item.Price || item.Price <= 0 || item.IsAvailable === false || isMarketplace,
    store:       'woolworths',
  };
}

async function searchWoolworths(query, page) {
  page = page || 1;
  const referer = WOW_BASE + '/shop/search/products?searchTerm=' + encodeURIComponent(query);
  const res = await fetch(WOW_BASE + '/apis/ui/Search/products', {
    method: 'POST',
    headers: await getWowHeaders(referer),
    body: JSON.stringify({
      Filters: [], IsSpecial: false,
      Location: '/shop/search/products?searchTerm=' + encodeURIComponent(query),
      PageNumber: page, PageSize: 24,
      SearchTerm: query, SortType: 'TraderRelevance',
      TimeZoneOffset: -660, enableGp: true,
    }),
  });
  if (!res.ok) throw new Error('Woolworths search HTTP ' + res.status);
  const data = await res.json();
  const rawProducts = (data && data.Products) || [];
  return rawProducts
    .flatMap(function(p) { return (p.Products || [p]).map(parseWoolworthsProduct); })
    .filter(function(i) { return !i.unavailable; });
}

// Woolworths specials — IsSpecial:true across common categories
const WOW_TERMS = [
  'milk', 'bread', 'cheese', 'yoghurt', 'chicken', 'beef', 'pasta', 'rice',
  'chips', 'chocolate', 'coffee', 'cereal', 'frozen', 'sauce', 'juice',
  'butter', 'eggs', 'snacks', 'biscuits', 'cleaning',
];

async function searchWowOnSpecial(query) {
  const referer = WOW_BASE + '/shop/search/products?searchTerm=' + encodeURIComponent(query);
  const res = await fetch(WOW_BASE + '/apis/ui/Search/products', {
    method: 'POST',
    headers: await getWowHeaders(referer),
    body: JSON.stringify({
      Filters: [], IsSpecial: true,
      Location: '/shop/search/products?searchTerm=' + encodeURIComponent(query),
      PageNumber: 1, PageSize: 24,
      SearchTerm: query, SortType: 'TraderRelevance',
      TimeZoneOffset: -660, enableGp: true,
    }),
  });
  if (!res.ok) throw new Error('WOW specials HTTP ' + res.status);
  const data = await res.json();
  return ((data && data.Products) || [])
    .flatMap(function(p) { return (p.Products || [p]).map(parseWoolworthsProduct); })
    .filter(function(i) { return (i.isOnSpecial || i.wasPrice) && !i.unavailable; })
    .map(function(i) { return Object.assign({}, i, { isOnSpecial: true }); });
}

async function fetchWoolworthsSpecials(page) {
  page = page || 1;
  const offset = ((page - 1) * 3) % WOW_TERMS.length;
  const batch = [
    WOW_TERMS[offset % WOW_TERMS.length],
    WOW_TERMS[(offset + 1) % WOW_TERMS.length],
    WOW_TERMS[(offset + 2) % WOW_TERMS.length],
  ];
  const results = [];
  for (var i = 0; i < batch.length; i++) {
    try { results.push(await searchWowOnSpecial(batch[i])); } catch { results.push([]); }
  }
  const seen = new Set();
  const merged = results.flat().filter(function(item) {
    const key = String(item.stockcode || item.id);
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
  for (var j = merged.length - 1; j > 0; j--) {
    const k = Math.floor(Math.random() * (j + 1));
    const tmp = merged[j]; merged[j] = merged[k]; merged[k] = tmp;
  }
  return merged;
}

module.exports = { searchColes, searchWoolworths, fetchColesSpecials, fetchWoolworthsSpecials };
