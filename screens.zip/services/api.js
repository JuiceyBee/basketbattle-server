// services/api.js
// Talks to the ORIGINAL server.js on Railway.
// All endpoints use ?code=HOUSEHOLDCODE query param — exactly as server.js expects.

import * as SecureStore from 'expo-secure-store';

const SERVER_URL = 'https://basketbattle-server.onrender.com';

let _householdCode = null; // e.g. "SMITH01"
let _accessCode    = null; // bb invite code — attached to every server request

export function setAccessCode(code) { _accessCode = code; }
export function getAccessCodeVal() { return _accessCode; }

// ── Credential persistence ───────────────────────────────────────────────────

export async function loadCredentials() {
  try {
    // Wipe old format (stored JSON with householdId+pin) — not compatible with this server
    const oldRaw = await SecureStore.getItemAsync('bb_household');
    if (oldRaw) {
      await SecureStore.deleteItemAsync('bb_household');
      console.log('[API] Cleared old credential format');
    }
    const code = await SecureStore.getItemAsync('bb_household_code');
    _householdCode = code || null;
  } catch {
    _householdCode = null;
  }
  return _householdCode;
}

async function saveCode(code) {
  _householdCode = code;
  await SecureStore.setItemAsync('bb_household_code', code);
}

export async function clearCredentials() {
  _householdCode = null;
  await SecureStore.deleteItemAsync('bb_household_code');
}

export function getHouseholdCode() { return _householdCode; }
export function isInHousehold()    { return !!_householdCode; }
// Legacy compat
export function getCredentials()   { return _householdCode ? { householdId: _householdCode } : null; }

// ── Auto-init: generate random code on first launch ─────────────────────────

export async function autoInitHousehold() {
  const existing = await loadCredentials();
  if (existing) return existing;
  // Generate a random 6-char code like the web app (e.g. "SMITH01")
  const code = Math.random().toString(36).slice(2, 8).toUpperCase();
  await saveCode(code);
  console.log('[Household] Auto-created code:', code);
  return code;
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function codeParam() {
  return _householdCode ? '?code=' + encodeURIComponent(_householdCode) : '';
}

async function serverGet(path) {
  const res = await fetch(SERVER_URL + path, {
    headers: {
      'Accept': 'application/json',
      ...(_accessCode ? { 'x-bb-access': _accessCode } : {}),
    },
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error('Server ' + res.status + (text ? ': ' + text : ''));
  }
  return res.json();
}

async function serverPost(path, body) {
  const res = await fetch(SERVER_URL + path, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      ...(_accessCode ? { 'x-bb-access': _accessCode } : {}),
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error('Server ' + res.status + (text ? ': ' + text : ''));
  }
  // Server may return "ok" text or JSON
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) return res.json();
  return { ok: true };
}

// ── Invite / join (for Account tab) ─────────────────────────────────────────

export async function generateInvite() {
  // Returns the current household code so the other person can type it in
  return { code: _householdCode };
}

export async function joinHousehold(code) {
  if (!code) throw new Error('No code provided');
  const trimmed = code.trim().toUpperCase();
  // Verify the code exists on the server by fetching battles
  const data = await serverGet('/battles?code=' + encodeURIComponent(trimmed));
  // data.groups will be [] for a new code — that's fine
  await saveCode(trimmed);
  return trimmed;
}

// ── List ─────────────────────────────────────────────────────────────────────
// Server stores list as { coles: [...], woolworths: [...] } OR as a flat array.
// We use a flat array internally — convert on the way in/out.

export async function getList() {
  if (!_householdCode) return [];
  try {
    const data = await serverGet('/list' + codeParam());
    // Server returns either flat array or { coles: [], woolworths: [] }
    if (Array.isArray(data)) return data;
    if (data && (data.coles || data.woolworths)) {
      const c = (data.coles || []).map(i => ({ ...i, store: 'coles' }));
      const w = (data.woolworths || []).map(i => ({ ...i, store: 'woolworths' }));
      return [...c, ...w];
    }
    return [];
  } catch (e) {
    console.warn('[API] getList error:', e.message);
    return [];
  }
}

export async function saveList(flatList) {
  if (!_householdCode) return;
  // Server's POST /list expects the body to be the list directly
  try {
    await serverPost('/list' + codeParam(), flatList);
  } catch (e) {
    console.warn('[API] saveList error:', e.message);
  }
}

// ── Battles ──────────────────────────────────────────────────────────────────
// Server stores { groups: [...] } — GET returns { groups }, POST takes { groups }

export async function getBattles() {
  if (!_householdCode) return [];
  try {
    const data = await serverGet('/battles' + codeParam());
    return data.groups || [];
  } catch (e) {
    console.warn('[API] getBattles error:', e.message);
    return [];
  }
}

export async function saveBattles(groups) {
  if (!_householdCode) return;
  try {
    await serverPost('/battles' + codeParam(), { groups });
  } catch (e) {
    console.warn('[API] saveBattles error:', e.message);
    throw e; // re-throw so UI can show error
  }
}

// ── History ──────────────────────────────────────────────────────────────────

export async function getHistory() {
  if (!_householdCode) return [];
  try {
    const data = await serverGet('/history' + codeParam());
    return data.history || [];
  } catch (e) {
    return [];
  }
}

export async function addHistoryEntry(entry) {
  if (!_householdCode) return;
  try {
    await serverPost('/history' + codeParam(), { entry });
  } catch (e) {
    console.warn('[API] addHistory error:', e.message);
  }
}

// Legacy compat
export async function saveHistory() {}

// ── Legacy compat aliases ────────────────────────────────────────────────────
export async function verifyHousehold() { return false; }
export async function createHousehold() { return autoInitHousehold(); }
export async function claimBattleRefresh() { return { ok: true }; }

export async function deleteHistoryEntry(entryId) {
  if (!_householdCode) return;
  try {
    const data = await serverGet('/history' + codeParam());
    const all = data.history || [];
    const filtered = all.filter(e => e.id !== entryId);
    // POST with full history array (server stores whatever we send as { history })
    await serverPost('/history/replace' + codeParam(), { history: filtered });
  } catch (e) {
    console.warn('[API] deleteHistory error:', e.message);
    throw e;
  }
}
