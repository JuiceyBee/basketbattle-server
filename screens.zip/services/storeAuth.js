// services/storeAuth.js
// All auth runs on-device via WebView cookie capture.
// No CookieManager native module needed — we inject JS into the WebView
// to read document.cookie, and intercept Set-Cookie from navigation events.
// Tokens stored in SecureStore, never leave the device.

import * as SecureStore from 'expo-secure-store';

export const STORES = {
  woolworths: {
    name: 'Woolworths',
    loginUrl: 'https://www.woolworths.com.au/shop/securelogin',
    baseUrl: 'https://www.woolworths.com.au',
    // We detect login success by checking for these cookies OR URL patterns
    successUrl: /woolworths\.com\.au\/(?!shop\/securelogin)(?!.*securelogin)/,
    authCookies: ['wow-auth-token', 'wowauth'],
    color: '#2e7d32',
    emoji: '🟢',
  },
  coles: {
    name: 'Coles',
    loginUrl: 'https://www.coles.com.au/sign-in',
    baseUrl: 'https://www.coles.com.au',
    successUrl: /coles\.com\.au\/(?!sign-in)/,
    authCookies: ['accessToken', 'coles_token', 'AUTH_TOKEN'],
    color: '#d32f2f',
    emoji: '🔴',
  },
};

// ── Secure storage ────────────────────────────────────────────────────────────

export async function saveCookies(store, cookieString) {
  if (!cookieString) return;
  await SecureStore.setItemAsync(`bb_cookies_${store}`, cookieString);
  await SecureStore.setItemAsync(`bb_cookies_${store}_ts`, String(Date.now()));
}

export async function loadCookies(store) {
  try {
    return await SecureStore.getItemAsync(`bb_cookies_${store}`) || null;
  } catch { return null; }
}

export async function clearCookies(store) {
  await SecureStore.deleteItemAsync(`bb_cookies_${store}`);
  await SecureStore.deleteItemAsync(`bb_cookies_${store}_ts`);
}

export async function isLoggedIn(store) {
  const cookies = await loadCookies(store);
  // Just check we have a saved session of reasonable size
  // Don't require specific cookie names — stores change these constantly
  return !!(cookies && cookies.length > 30);
}

// ── Cookie string builder ─────────────────────────────────────────────────────

export async function getCookieString(store) {
  return await loadCookies(store);
}

// Parse "key=val; key2=val2" into object
export function parseCookieString(str) {
  if (!str) return {};
  return Object.fromEntries(
    str.split(';').map(p => {
      const eq = p.indexOf('=');
      if (eq < 0) return [p.trim(), ''];
      return [p.slice(0, eq).trim(), p.slice(eq + 1).trim()];
    })
  );
}

// Merge new cookie values into existing cookie string
export function mergeCookies(existing, incoming) {
  const base = parseCookieString(existing || '');
  const next = parseCookieString(incoming || '');
  return Object.entries({ ...base, ...next })
    .filter(([k, v]) => k && v)
    .map(([k, v]) => `${k}=${v}`)
    .join('; ');
}

// ── JS to inject into WebView to extract cookies ──────────────────────────────
// Runs after every page load. Posts document.cookie back via ReactNativeWebView.

export const COOKIE_EXTRACTOR_JS = `
(function() {
  function send() {
    if (window.ReactNativeWebView) {
      window.ReactNativeWebView.postMessage(JSON.stringify({
        type: 'cookies',
        url: window.location.href,
        cookies: document.cookie,
      }));
    }
  }
  // Send immediately
  send();
  // Also send after a short delay (some cookies set by JS after load)
  setTimeout(send, 1500);
  setTimeout(send, 4000);
})();
true;
`;

// ── API fetch using stored cookies ────────────────────────────────────────────

const BASE_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1',
  'Accept': 'application/json',
  'Accept-Language': 'en-AU,en;q=0.9',
};

export async function storeApiFetch(store, url, opts = {}) {
  const cookieStr = await getCookieString(store);
  const res = await fetch(url, {
    ...opts,
    headers: {
      ...BASE_HEADERS,
      ...(cookieStr ? { Cookie: cookieStr } : {}),
      ...(opts.headers || {}),
    },
  });
  if (res.status === 401 || res.status === 403) throw new Error('AUTH_EXPIRED');
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

// ── Woolworths token refresh ───────────────────────────────────────────────────
// Woolworths issues a short-lived access token + refresh token.
// We can silently refresh using the refresh token without re-showing the WebView.

export async function refreshWoolworthsToken() {
  const cookieStr = await loadCookies('woolworths');
  if (!cookieStr) return false;
  const cookies = parseCookieString(cookieStr);

  // Woolworths refresh token may be stored under various key names
  // depending on whether it came from cookies or localStorage during login
  const refreshToken = cookies['refresh_token']
    || cookies['wow-refresh-token']
    || cookies['refreshToken']
    || cookies['wowRefreshToken']
    || cookies['RefreshToken'];

  if (!refreshToken) {
    console.log('[Auth] No Woolworths refresh token found in stored cookies — keys:', Object.keys(cookies).join(', '));
    return false;
  }

  // Try multiple refresh endpoints
  const endpoints = [
    'https://www.woolworths.com.au/apis/ui/v2/token/refresh',
    'https://www.woolworths.com.au/apis/ui/v2/session/refresh',
    'https://www.woolworths.com.au/apis/ui/Auth/token/refresh',
  ];

  for (const url of endpoints) {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          ...BASE_HEADERS,
          'Content-Type': 'application/json',
          'Cookie': cookieStr,
          'Origin': 'https://www.woolworths.com.au',
          'Referer': 'https://www.woolworths.com.au/',
          'X-Requested-With': 'OnlineShopping.WebApp',
        },
        body: JSON.stringify({ refreshToken }),
      });
      if (!res.ok) continue;
      const data = await res.json();
      const newToken = data.accessToken || data.token || data.wow_auth_token;
      if (newToken) {
        const merged = mergeCookies(cookieStr,
          `wow-auth-token=${newToken}`
          + (data.refreshToken ? `; refresh_token=${data.refreshToken}` : '')
        );
        await saveCookies('woolworths', merged);
        console.log('[Auth] Woolworths token refreshed via', url);
        return true;
      }
    } catch (e) {
      console.warn('[Auth] Woolworths refresh error at', url, e.message);
    }
  }
  return false;
}

// ── Coles token refresh ───────────────────────────────────────────────────────

export async function refreshColesToken() {
  const cookieStr = await loadCookies('coles');
  if (!cookieStr) return false;
  const cookies = parseCookieString(cookieStr);
  const refreshToken = cookies['refreshToken'] || cookies['refresh_token'];
  if (!refreshToken) return false;
  try {
    const res = await fetch('https://www.coles.com.au/api/bff/auth/token/refresh', {
      method: 'POST',
      headers: {
        ...BASE_HEADERS,
        'Content-Type': 'application/json',
        Cookie: cookieStr,
        Origin: 'https://www.coles.com.au',
        Referer: 'https://www.coles.com.au/',
      },
      body: JSON.stringify({ refreshToken }),
    });
    if (!res.ok) return false;
    const data = await res.json();
    if (data.accessToken) {
      const merged = mergeCookies(cookieStr,
        `accessToken=${data.accessToken}`
        + (data.refreshToken ? `; refreshToken=${data.refreshToken}` : '')
      );
      await saveCookies('coles', merged);
      console.log('[Auth] Coles token refreshed silently');
      return true;
    }
    return false;
  } catch (e) {
    console.warn('[Auth] Coles refresh error:', e.message);
    return false;
  }
}

// ── Cart ──────────────────────────────────────────────────────────────────────

// ── Woolworths cart ───────────────────────────────────────────────────────────
// Mirrors the web app: tries 3 endpoint formats in order until one works.

export async function addToWoolworthsCart(items) {
  const cookieStr = await loadCookies('woolworths');
  if (!cookieStr) return items.map(i => ({ ...i, ok: false, error: 'Not logged in to Woolworths' }));

  const cartHeaders = {
    ...BASE_HEADERS,
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'Origin': 'https://www.woolworths.com.au',
    'Referer': 'https://www.woolworths.com.au/shop/cart',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'X-Requested-With': 'OnlineShopping.WebApp',
    'Cookie': cookieStr,
  };

  const results = [];
  let workingEndpointIdx = null;

  for (const item of items) {
    const stockcode = item.stockcode || item.id;
    if (!stockcode) {
      results.push({ ...item, ok: false, error: 'No stockcode' });
      continue;
    }

    const qty = item.qty || 1;

    // Same 3 attempts as the web app, in the same order
    const attempts = [
      {
        label: 'Trolley/AddItem',
        url: 'https://www.woolworths.com.au/apis/ui/Trolley/AddItem',
        body: JSON.stringify({ stockcode: Number(stockcode), quantity: qty, addoncontents: [] }),
      },
      {
        label: 'Trolley/UpdateItem',
        url: 'https://www.woolworths.com.au/apis/ui/Trolley/UpdateItem',
        body: JSON.stringify({ stockcode: Number(stockcode), quantity: qty, addoncontents: [] }),
      },
      {
        label: 'Basket/update (legacy)',
        url: 'https://www.woolworths.com.au/apis/ui/Basket/update',
        body: JSON.stringify({ Quantity: qty, StockCode: Number(stockcode), IsInCart: false, IsBundle: false }),
      },
    ];

    // If we already know which endpoint works, only try that one
    const toTry = workingEndpointIdx !== null ? [attempts[workingEndpointIdx]] : attempts;
    let added = false;

    for (let i = 0; i < toTry.length; i++) {
      const attempt = toTry[i];
      try {
        const res = await fetch(attempt.url, { method: 'POST', headers: cartHeaders, body: attempt.body });
        if (res.ok) {
          if (workingEndpointIdx === null) {
            workingEndpointIdx = attempts.findIndex(a => a.url === attempt.url);
          }
          added = true;
          break;
        }
        if (res.status === 401 || res.status === 403) {
          // Try silent token refresh then retry this item once
          const refreshed = await refreshWoolworthsToken();
          if (refreshed) {
            const newCookies = await loadCookies('woolworths');
            cartHeaders['Cookie'] = newCookies;
            const retryRes = await fetch(attempt.url, { method: 'POST', headers: cartHeaders, body: attempt.body }).catch(() => null);
            if (retryRes && retryRes.ok) { added = true; break; }
          }
          results.push({ ...item, ok: false, error: 'Session expired — sign in to Woolworths again' });
          added = true;
          break;
        }
      } catch (e) {
        console.warn('[WoolworthsCart]', attempt.label, e.message);
      }
    }

    results.push({ ...item, ok: added && !results.find(r => r.id === item.id && !r.ok) });
    // Small delay between items to avoid rate limiting
    if (items.length > 1) await new Promise(r => setTimeout(r, 800));
  }
  return results;
}

// -- Coles cart via hidden WebView -------------------------------------------
// Queue a job (items + cookies). ColesCartWebView in App.js picks it up,
// loads coles.com.au/cart as a real browser, injects cookies + cart JS,
// posts results back via postMessage.

let _colesCartJob = null; // { items, cookies, resolve }

export function getColesCartJob() { return _colesCartJob; }
export function clearColesCartJob() { _colesCartJob = null; }

export async function addToColesCart(items) {
  const cookieStr = await loadCookies('coles');
  if (!cookieStr) return items.map(i => ({ ...i, ok: false, error: 'Not logged in to Coles' }));

  return new Promise((resolve) => {
    _colesCartJob = { items, cookies: cookieStr, resolve };
    setTimeout(() => {
      if (_colesCartJob) {
        _colesCartJob = null;
        resolve(items.map(i => ({ ...i, ok: false, error: 'WebView cart timed out' })));
      }
    }, 90000);
  });
}

// JS injected into the hidden WebView after coles.com.au/cart loads.
// First plants saved cookies into the page, then calls the trolley API.
// -- Update qty in Woolworths cart (qty=0 removes) ----------------------------
export async function updateWoolworthsCartItem(item, newQty) {
  const stockcode = item.stockcode || item.id;
  if (!stockcode) return { ok: false, error: 'No stockcode' };

  async function attempt(retrying = false) {
    const cookieStr = await loadCookies('woolworths');
    if (!cookieStr) return { ok: false, error: 'Not logged in to Woolworths' };
    const headers = {
      ...BASE_HEADERS,
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json',
      'Origin': 'https://www.woolworths.com.au',
      'Referer': 'https://www.woolworths.com.au/shop/cart',
      'X-Requested-With': 'OnlineShopping.WebApp',
      'Cookie': cookieStr,
    };
    const endpoints = [
      { url: 'https://www.woolworths.com.au/apis/ui/Trolley/UpdateItem',
        body: JSON.stringify({ stockcode: Number(stockcode), quantity: newQty, addoncontents: [] }) },
      { url: 'https://www.woolworths.com.au/apis/ui/Basket/update',
        body: JSON.stringify({ Quantity: newQty, StockCode: Number(stockcode), IsInCart: true, IsBundle: false }) },
    ];
    for (const ep of endpoints) {
      try {
        const res = await fetch(ep.url, { method: 'POST', headers, body: ep.body });
        if (res.ok) return { ok: true };
        if ((res.status === 401 || res.status === 403) && !retrying) {
          // Token expired — try silent refresh then retry once
          const refreshed = await refreshWoolworthsToken();
          if (refreshed) return attempt(true);
          return { ok: false, error: 'Session expired' };
        }
      } catch (e) { console.warn('[WoolworthsUpdate]', e.message); }
    }
    return { ok: false, error: 'Update failed' };
  }

  return attempt();
}

// -- Update qty in Coles cart via WebView -----------------------------------
// Pass delta for qty changes (+1/-1), or qty=0 to fully remove the item.
export async function updateColesCartItem(item, qty) {
  const cookieStr = await loadCookies('coles');
  if (!cookieStr) return { ok: false, error: 'Not logged in to Coles' };
  return new Promise((resolve) => {
    _colesCartJob = {
      items: [{ ...item, qty }],
      cookies: cookieStr,
      resolve: (results) => resolve(results[0] || { ok: false }),
    };
    setTimeout(() => {
      if (_colesCartJob) { _colesCartJob = null; resolve({ ok: false, error: 'WebView timed out' }); }
    }, 90000);
  });
}

export function buildColesCartJS(items, capturedSubKey) {
  return `
(function() {
  var items = ${JSON.stringify(items)};
  // Use pre-captured sub key from fetch interceptor if available
  var _preloadedSubKey = ${JSON.stringify(capturedSubKey || null)};
  var results = [];
  var delay = function(ms) { return new Promise(function(r) { setTimeout(r, ms); }); };

  // Look for subscription key in already-loaded page scripts
  function getSubKeyFromPage() {
    var scripts = document.querySelectorAll('script');
    for (var i = 0; i < scripts.length; i++) {
      var txt = scripts[i].textContent || '';
      var km = txt.match(/"Ocp-Apim-Subscription-Key"\s*[,:]+\s*"([a-f0-9]{32})"/i)
            || txt.match(/subscriptionKey\s*[,:]+\s*"([a-f0-9]{32})"/i);
      if (km) return km[1];
    }
    // Also check window.__NEXT_DATA__ which Next.js puts on the page
    try {
      var nd = window.__NEXT_DATA__;
      if (nd) {
        var s = JSON.stringify(nd);
        var km2 = s.match(/"Ocp-Apim-Subscription-Key"\s*[,:]+\s*"([a-f0-9]{32})"/i)
               || s.match(/subscriptionKey[^"]*"([a-f0-9]{32})"/i);
        if (km2) return km2[1];
      }
    } catch(e) {}
    return null;
  }

  // Fetch a single known config endpoint that returns the key
  async function getSubKeyFromConfig() {
    try {
      var endpoints = [
        'https://www.coles.com.au/api/bff/config',
        'https://www.coles.com.au/api/bff/navigation/v1/header',
      ];
      for (var i = 0; i < endpoints.length; i++) {
        try {
          var r = await fetchWithTimeout(endpoints[i], { credentials: 'include', headers: { Accept: 'application/json' } }, 8000);
          if (!r.ok) continue;
          var txt = await r.text();
          var km = txt.match(/"Ocp-Apim-Subscription-Key"\s*[,:]+\s*"([a-f0-9]{32})"/i)
                || txt.match(/subscriptionKey[^"]*"([a-f0-9]{32})"/i);
          if (km) return km[1];
        } catch(e) {}
      }
    } catch(e) {}
    return null;
  }

  // fetch with timeout helper
  function fetchWithTimeout(url, opts, ms) {
    var controller = new AbortController();
    var timer = setTimeout(function() { controller.abort(); }, ms);
    return fetch(url, Object.assign({}, opts, { signal: controller.signal }))
      .finally(function() { clearTimeout(timer); });
  }

  async function updateItem(item, subKey, storeId) {
    // item.qty is always the absolute final quantity (0 = remove)
    var newAbsQty = item.qty != null ? item.qty : 1;
    var productId = String(item.id);
    var headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json, text/plain, */*',
      'Origin': 'https://www.coles.com.au',
      'Referer': 'https://www.coles.com.au/cart',
    };
    if (subKey) headers['Ocp-Apim-Subscription-Key'] = subKey;

    // Find orderItemId from cached trolley (needed for PATCH)
    var orderItemId = null;
    var trolleyItems = window._colesTrolleyItems || [];
    for (var j = 0; j < trolleyItems.length; j++) {
      var ti = trolleyItems[j];
      var tiId = String(ti.productId != null ? ti.productId : (ti.product && ti.product.id) || '');
      if (tiId === productId) {
        orderItemId = String(ti.orderItemId || ti.id || ti.trolleyItemId || '');
        break;
      }
    }

    // PATCH with absolute qty — works for add, update, and remove (qty=0)
    // Requires orderItemId for existing items; falls back to POST add for new items
    if (orderItemId) {
      try {
        var patchRes = await fetchWithTimeout('https://www.coles.com.au/api/bff/trolley/store/' + storeId, {
          method: 'PATCH',
          credentials: 'include',
          headers: headers,
          body: JSON.stringify({
            ageGateVerified: true,
            swapBehaviour: false,
            items: [{
              actions: [{
                quantity: newAbsQty,
                orderItemId: orderItemId,
                productId: productId,
              }]
            }]
          }),
        }, 15000);
        if (patchRes.ok) {
          // Update cache so subsequent calls have accurate qty
          for (var ci = 0; ci < trolleyItems.length; ci++) {
            if (String(trolleyItems[ci].productId) === productId) {
              trolleyItems[ci].quantity = newAbsQty;
              break;
            }
          }
          return { ok: true };
        }
      } catch(e) { console.warn('[ColesCart] patch error:', e.message); }
    }

    // No orderItemId (new item not yet in trolley cache) — use POST to add
    if (newAbsQty > 0) {
      try {
        var postRes = await fetchWithTimeout('https://www.coles.com.au/api/bff/trolley/store/' + storeId, {
          method: 'POST',
          credentials: 'include',
          headers: headers,
          body: JSON.stringify({
            ageGateVerified: true,
            swapBehaviour: false,
            items: [{ productId: Number(productId), quantity: newAbsQty }],
          }),
        }, 15000);
        if (postRes.ok) return { ok: true };
      } catch(e) { console.warn('[ColesCart] post error:', e.message); }
    }

    return { ok: false, error: 'update_failed' };
  }

  async function run() {
    var storeId = '7674';
    var cm = document.cookie.match(/fulfillmentStoreId=([^;]+)/);
    if (cm) storeId = cm[1].trim();

    // First try the key intercepted from page network requests (most reliable)
    var subKey = _preloadedSubKey || window._colesSubKey || getSubKeyFromPage();
    if (!subKey) subKey = await getSubKeyFromConfig();

    for (var i = 0; i < items.length; i++) {
      var item = items[i];
        if (!item.id) {
        results.push({ id: item.id, name: item.name, ok: false, error: 'no_id' });
        continue;
      }
      var r = await updateItem(item, subKey, storeId);
      results.push({ id: item.id, name: item.name, ok: r.ok, error: r.error || null });
      if (i < items.length - 1) await delay(800);
    }

    window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({
      type: 'colesCartDone',
      results: results,
    }));
  }

  run().catch(function(e) {
    window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({
      type: 'colesCartDone',
      results: items.map(function(i) { return { id: i.id, name: i.name, ok: false, error: e.toString() }; }),
    }));
  });
})();
true;
  `;
}
